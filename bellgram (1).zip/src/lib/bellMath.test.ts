import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {
  MICRO_PER_BELL,
  bellToMicro,
  formatBell,
  computeAccruedMicro,
  resolveLevelForBellgram,
  computeDailyStreakState,
} from './bellMath.ts';
import { verifyTelegramInitData } from '../../server/telegramAuth.ts';
import type { MiningLevel } from '../types.ts';

const DEFAULT_LEVELS: MiningLevel[] = [
  { level: 0, name: 'Free', nameAr: 'مجاني', minBellgram: 0, dailyBell: 500 },
  { level: 1, name: 'Tin', nameAr: 'قصدير', minBellgram: 1000, dailyBell: 700 },
  { level: 2, name: 'Copper', nameAr: 'نحاس', minBellgram: 2000, dailyBell: 800 },
  { level: 3, name: 'Brass', nameAr: 'نحاس أصفر', minBellgram: 3000, dailyBell: 900 },
  { level: 4, name: 'Silver', nameAr: 'فضة', minBellgram: 4000, dailyBell: 1000 },
];

test('micro-BELL integer conversion and formatting avoid floating-point errors', () => {
  assert.equal(bellToMicro(10), 100_000);
  assert.equal(bellToMicro(0.0116), 116);
  assert.equal(formatBell(116), '0.0116');
  assert.equal(formatBell(500 * MICRO_PER_BELL), '500.0000');
  assert.equal(formatBell(12345678), '1,234.5678');
});

test('mining accrual calculates exact elapsed reward, caps at 24h, and prevents double claim', () => {
  const startedAtMs = 1_700_000_000_000;
  // Halfway through 24h session at 500 BELL/day -> 250 BELL
  const halfWay = computeAccruedMicro({
    dailyRateBell: 500,
    multiplierBps: 10_000,
    startedAtMs,
    nowMs: startedAtMs + 12 * 3600 * 1000,
    sessionDurationSec: 86400,
    alreadyClaimedMicro: 0,
    status: 'running',
  });
  assert.equal(halfWay.accruedMicro, 250 * MICRO_PER_BELL);
  assert.equal(halfWay.progressPct, 50);
  assert.equal(halfWay.isExpired, false);

  // Claiming immediately again at the exact same timestamp returns 0 accrued
  const doubleClaimAttempt = computeAccruedMicro({
    dailyRateBell: 500,
    multiplierBps: 10_000,
    startedAtMs,
    nowMs: startedAtMs + 12 * 3600 * 1000,
    sessionDurationSec: 86400,
    alreadyClaimedMicro: 250 * MICRO_PER_BELL,
    status: 'running',
  });
  assert.equal(doubleClaimAttempt.accruedMicro, 0);

  // Past 24h (e.g. 48h elapsed) is strictly capped at 500 BELL
  const overTime = computeAccruedMicro({
    dailyRateBell: 500,
    multiplierBps: 10_000,
    startedAtMs,
    nowMs: startedAtMs + 48 * 3600 * 1000,
    sessionDurationSec: 86400,
    alreadyClaimedMicro: 0,
    status: 'running',
  });
  assert.equal(overTime.accruedMicro, 500 * MICRO_PER_BELL);
  assert.equal(overTime.progressPct, 100);
  assert.equal(overTime.isExpired, true);
  assert.equal(overTime.remainingSec, 0);
});

test('mining level resolution matches BELLGRAM thresholds', () => {
  assert.equal(resolveLevelForBellgram(0, DEFAULT_LEVELS).current.name, 'Free');
  assert.equal(resolveLevelForBellgram(bellToMicro(999.99), DEFAULT_LEVELS).current.name, 'Free');
  assert.equal(resolveLevelForBellgram(bellToMicro(1000), DEFAULT_LEVELS).current.name, 'Tin');
  assert.equal(resolveLevelForBellgram(bellToMicro(2500), DEFAULT_LEVELS).current.name, 'Copper');
  assert.equal(resolveLevelForBellgram(bellToMicro(3000), DEFAULT_LEVELS).current.name, 'Brass');
  const silver = resolveLevelForBellgram(bellToMicro(5000), DEFAULT_LEVELS);
  assert.equal(silver.current.name, 'Silver');
  assert.equal(silver.next, null);
});

test('daily login streak enforces once-per-day, increments consecutively, and resets if day missed', () => {
  const schedule = [10, 15, 20, 30, 45, 65, 100];

  const first = computeDailyStreakState(null, 0, '2026-11-22', schedule);
  assert.equal(first.canClaim, true);
  assert.equal(first.nextDayIndex, 1);
  assert.equal(first.rewardBell, 10);

  const sameDay = computeDailyStreakState('2026-11-22', 1, '2026-11-22', schedule);
  assert.equal(sameDay.canClaim, false);

  const nextDay = computeDailyStreakState('2026-11-22', 1, '2026-11-23', schedule);
  assert.equal(nextDay.canClaim, true);
  assert.equal(nextDay.nextDayIndex, 2);
  assert.equal(nextDay.rewardBell, 15);
  assert.equal(nextDay.streakBroken, false);

  const missedDay = computeDailyStreakState('2026-11-22', 4, '2026-11-24', schedule);
  assert.equal(missedDay.canClaim, true);
  assert.equal(missedDay.nextDayIndex, 1);
  assert.equal(missedDay.rewardBell, 10);
  assert.equal(missedDay.streakBroken, true);
});

test('Telegram initData HMAC-SHA256 verification accepts valid payload and rejects tampered/expired payloads', () => {
  const botToken = '123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11';
  const nowSec = Math.floor(Date.now() / 1000);
  const userJson = JSON.stringify({ id: 987654321, first_name: 'Ahmed', username: 'ahmed_bell' });

  const params = new URLSearchParams({
    auth_date: String(nowSec),
    query_id: 'AAHdF6IQAAAAAN0XohDhrOrc',
    user: userJson,
    start_param: 'ref_111222',
  });

  const dataCheckString = Array.from(params.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join('\n');

  const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const hash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');
  params.set('hash', hash);

  const verified = verifyTelegramInitData(params.toString(), botToken, 86400);
  assert.ok(verified);
  assert.equal(verified.id, 987654321);
  assert.equal(verified.username, 'ahmed_bell');
  assert.equal(verified.startParam, 'ref_111222');

  // Tamper with user id
  const tamperedParams = new URLSearchParams(params.toString());
  tamperedParams.set('user', JSON.stringify({ id: 111111, first_name: 'Hacker' }));
  assert.equal(verifyTelegramInitData(tamperedParams.toString(), botToken, 86400), null);

  // Expired auth_date
  const oldParams = new URLSearchParams({
    auth_date: String(nowSec - 100_000),
    user: userJson,
  });
  const oldCheck = Array.from(oldParams.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join('\n');
  const oldHash = crypto.createHmac('sha256', secretKey).update(oldCheck).digest('hex');
  oldParams.set('hash', oldHash);
  assert.equal(verifyTelegramInitData(oldParams.toString(), botToken, 86400), null);
});
