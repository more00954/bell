import type { BootstrapPayload } from '../types.ts';

declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        initData?: string;
        initDataUnsafe?: {
          user?: { id?: number; first_name?: string; username?: string };
          start_param?: string;
        };
        ready?: () => void;
        expand?: () => void;
        openTelegramLink?: (url: string) => void;
        openLink?: (url: string) => void;
      };
    };
  }
}

export function getTelegramInitData(): string {
  return window.Telegram?.WebApp?.initData || '';
}

async function requestJson<T>(url: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers || {});
  const initData = getTelegramInitData();
  if (initData) {
    headers.set('X-Telegram-Init-Data', initData);
  }
  if (options.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const resp = await fetch(url, { ...options, headers });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) {
    throw new Error((data as { error?: string }).error || `Request failed (${resp.status})`);
  }
  return data as T;
}

export const api = {
  bootstrap: () => requestJson<BootstrapPayload>('/api/bootstrap'),
  joinChannelIntent: (channelId: string) =>
    requestJson<BootstrapPayload>('/api/channels/join-intent', {
      method: 'POST',
      body: JSON.stringify({ channelId }),
    }),
  verifyChannels: () =>
    requestJson<{
      verification: { verified: boolean; message?: string };
      bootstrap: BootstrapPayload;
    }>('/api/channels/verify', { method: 'POST' }),
  claimMining: (idempotencyKey: string) =>
    requestJson<{
      claim: { claimedMicro: number; newBalanceMicro: number };
      bootstrap: BootstrapPayload;
    }>('/api/mining/claim', {
      method: 'POST',
      headers: { 'Idempotency-Key': idempotencyKey },
      body: JSON.stringify({ idempotencyKey }),
    }),
  claimDaily: () =>
    requestJson<{
      claim: { dayNumber: number; rewardMicro: number; newBalanceMicro: number };
      bootstrap: BootstrapPayload;
    }>('/api/daily/claim', { method: 'POST' }),
  claimMission: (missionId: number) =>
    requestJson<{
      claim: { rewardMicro: number; newBalanceMicro: number };
      bootstrap: BootstrapPayload;
    }>(`/api/missions/${missionId}/claim`, { method: 'POST' }),
  connectWallet: (tonAddress: string, walletApp?: string) =>
    requestJson<{
      bootstrap: BootstrapPayload;
    }>('/api/wallet/connect', {
      method: 'POST',
      body: JSON.stringify({ tonAddress, walletApp }),
    }),
  disconnectWallet: () =>
    requestJson<{ bootstrap: BootstrapPayload }>('/api/wallet/disconnect', {
      method: 'POST',
    }),
  refreshWallet: () =>
    requestJson<{ bootstrap: BootstrapPayload }>('/api/wallet/refresh', {
      method: 'POST',
    }),
  confirmWalletVerification: () =>
    requestJson<{
      verification: { verified: boolean; pending?: boolean; txHash?: string; message: string };
      bootstrap: BootstrapPayload;
    }>('/api/wallet/verify/confirm', {
      method: 'POST',
    }),
  requestWithdrawal: (amountBell: number, tonAddress?: string) =>
    requestJson<{
      withdrawal: BootstrapPayload['withdrawals'][number];
      bootstrap: BootstrapPayload;
    }>('/api/withdrawals/request', {
      method: 'POST',
      body: JSON.stringify({ amountBell, tonAddress }),
    }),
};
