import type { MiningLevel } from '../types.ts';

export const MICRO_PER_BELL = 10_000;
export const NANO_PER_TON = 1_000_000_000;

export function bellToMicro(bell: number): number {
  if (!Number.isFinite(bell) || bell < 0) return 0;
  return Math.round(bell * MICRO_PER_BELL);
}

export function microToBell(micro: number): number {
  if (!Number.isFinite(micro)) return 0;
  return micro / MICRO_PER_BELL;
}

export function formatBell(micro: number, decimals = 4): string {
  const safeMicro = Number.isFinite(micro) ? Math.max(0, Math.round(micro)) : 0;
  const whole = Math.floor(safeMicro / MICRO_PER_BELL);
  const frac = safeMicro % MICRO_PER_BELL;
  if (decimals === 0) {
    return whole.toLocaleString('en-US');
  }
  const fracStr = frac.toString().padStart(4, '0').slice(0, decimals);
  return `${whole.toLocaleString('en-US')}.${fracStr}`;
}

export function formatTon(nano: number): string {
  const safe = Number.isFinite(nano) ? Math.max(0, Math.round(nano)) : 0;
  const whole = Math.floor(safe / NANO_PER_TON);
  const frac = Math.floor((safe % NANO_PER_TON) / 100_000); // 4 decimals
  return `${whole.toLocaleString('en-US')}.${frac.toString().padStart(4, '0')}`;
}

export function formatCountdown(totalSec: number): string {
  const clamped = Math.max(0, Math.floor(totalSec));
  const h = Math.floor(clamped / 3600);
  const m = Math.floor((clamped % 3600) / 60);
  const s = clamped % 60;
  return [h, m, s].map((v) => v.toString().padStart(2, '0')).join(':');
}

export interface MiningAccrualResult {
  accruedMicro: number;
  remainingSec: number;
  progressPct: number;
  isExpired: boolean;
}

/**
 * Pure deterministic server-authoritative mining calculation using integer micro-units.
 * Never depends on floating point accumulation.
 */
export function computeAccruedMicro(params: {
  dailyRateBell: number;
  multiplierBps: number; // 10000 = 1.00x
  startedAtMs: number;
  nowMs: number;
  sessionDurationSec: number;
  alreadyClaimedMicro: number;
  status: 'running' | 'paused' | 'claimed' | 'idle';
}): MiningAccrualResult {
  const {
    dailyRateBell,
    multiplierBps,
    startedAtMs,
    nowMs,
    sessionDurationSec,
    alreadyClaimedMicro,
    status,
  } = params;

  if (status === 'idle' || status === 'claimed' || sessionDurationSec <= 0) {
    return {
      accruedMicro: 0,
      remainingSec: 0,
      progressPct: status === 'claimed' ? 100 : 0,
      isExpired: status === 'claimed',
    };
  }

  const durationMs = sessionDurationSec * 1000;
  const rawElapsedMs = Math.max(0, nowMs - startedAtMs);
  const cappedElapsedMs = Math.min(durationMs, rawElapsedMs);
  const remainingSec = Math.max(0, Math.ceil((durationMs - cappedElapsedMs) / 1000));
  const isExpired = rawElapsedMs >= durationMs;

  // Total session reward in micro-BELL = dailyRateBell * (sessionDurationHours / 24) * (multiplierBps / 10000) * MICRO_PER_BELL
  // Using integer-safe BigInt to avoid precision loss
  const totalSessionMicro =
    (BigInt(Math.round(dailyRateBell)) *
      BigInt(MICRO_PER_BELL) *
      BigInt(sessionDurationSec) *
      BigInt(multiplierBps)) /
    (86400n * 10000n);

  const earnedSoFarMicro = Number(
    (totalSessionMicro * BigInt(cappedElapsedMs)) / BigInt(durationMs)
  );

  const accruedMicro = Math.max(0, earnedSoFarMicro - Math.max(0, alreadyClaimedMicro));
  const progressPct = Math.min(100, Math.max(0, (cappedElapsedMs / durationMs) * 100));

  return {
    accruedMicro,
    remainingSec,
    progressPct,
    isExpired,
  };
}

export function resolveLevelForBellgram(
  bellgramMicro: number,
  levels: MiningLevel[]
): { current: MiningLevel; next: MiningLevel | null } {
  const sorted = [...levels].sort((a, b) => a.minBellgram - b.minBellgram);
  const bellgramWhole = microToBell(bellgramMicro);
  let current = sorted[0];
  for (const lvl of sorted) {
    if (bellgramWhole >= lvl.minBellgram) {
      current = lvl;
    }
  }
  const next = sorted.find((lvl) => lvl.level > current.level) ?? null;
  return { current, next };
}

export function getUtcDateString(nowMs: number): string {
  return new Date(nowMs).toISOString().slice(0, 10);
}

export function addUtcDays(dateStr: string, days: number): string {
  const d = new Date(`${dateStr}T00:00:00.000Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export interface DailyStreakComputation {
  canClaim: boolean;
  nextDayIndex: number; // 1..7
  rewardBell: number;
  streakBroken: boolean;
}

/**
 * Computes 7-day daily login streak using authoritative server UTC date.
 * Policy: If user misses a calendar UTC day (lastClaimDateUtc < yesterdayUtc), streak resets to Day 1.
 * After Day 7 is claimed, the next eligible day cycles back to Day 1.
 */
export function computeDailyStreakState(
  lastClaimDateUtc: string | null,
  lastDayNumber: number,
  todayUtc: string,
  rewardsSchedule: number[]
): DailyStreakComputation {
  const schedule = rewardsSchedule.length === 7 ? rewardsSchedule : [10, 15, 20, 30, 45, 65, 100];

  if (!lastClaimDateUtc) {
    return {
      canClaim: true,
      nextDayIndex: 1,
      rewardBell: schedule[0],
      streakBroken: false,
    };
  }

  if (lastClaimDateUtc === todayUtc) {
    const shownDay = Math.min(7, Math.max(1, lastDayNumber));
    return {
      canClaim: false,
      nextDayIndex: shownDay,
      rewardBell: schedule[shownDay - 1],
      streakBroken: false,
    };
  }

  const yesterdayUtc = addUtcDays(todayUtc, -1);
  if (lastClaimDateUtc === yesterdayUtc) {
    const nextDay = lastDayNumber >= 7 ? 1 : lastDayNumber + 1;
    return {
      canClaim: true,
      nextDayIndex: nextDay,
      rewardBell: schedule[nextDay - 1],
      streakBroken: false,
    };
  }

  // Missed at least one UTC day -> reset streak to Day 1
  return {
    canClaim: true,
    nextDayIndex: 1,
    rewardBell: schedule[0],
    streakBroken: true,
  };
}
