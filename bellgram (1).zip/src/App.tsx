import React, { useCallback, useEffect, useState } from 'react';
import { Bell, Globe, Home, Shield, Users, Wallet } from 'lucide-react';
import { api, getTelegramInitData } from './lib/api.ts';
import { t } from './lib/i18n.ts';
import { ChannelGate } from './components/ChannelGate.tsx';
import { HomeView } from './components/HomeView.tsx';
import { MissionCenterView } from './components/MissionCenterView.tsx';
import { FriendsView } from './components/FriendsView.tsx';
import { WalletView } from './components/WalletView.tsx';
import { AdminDashboard } from './components/AdminDashboard.tsx';
import type { BootstrapPayload, Language } from './types.ts';

type ActiveTab = 'home' | 'friends' | 'wallet' | 'missions';

export default function App() {
  const [data, setData] = useState<BootstrapPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<ActiveTab>(() => {
    const param = new URLSearchParams(window.location.search).get('tab');
    if (param === 'wallet' || param === 'friends' || param === 'missions') {
      return param;
    }
    return 'home';
  });
  const [isAdminRoute, setIsAdminRoute] = useState<boolean>(
    () => window.location.pathname === '/admin'
  );
  const [lang, setLang] = useState<Language>('en');

  useEffect(() => {
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    window.Telegram?.WebApp?.ready?.();
    window.Telegram?.WebApp?.expand?.();

    const onPopState = () => {
      setIsAdminRoute(window.location.pathname === '/admin');
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const refreshBootstrap = useCallback(async () => {
    try {
      const payload = await api.bootstrap();
      setData(payload);
      setLoadError(null);
    } catch (err) {
      setLoadError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshBootstrap();
  }, [refreshBootstrap]);

  const openAdmin = () => {
    window.history.pushState({}, '', '/admin');
    setIsAdminRoute(true);
  };

  const exitAdmin = () => {
    window.history.pushState({}, '', '/');
    setIsAdminRoute(false);
    refreshBootstrap();
  };

  if (isAdminRoute) {
    const insideTelegram = Boolean(getTelegramInitData());
    if (insideTelegram) {
      if (loading) {
        return (
          <div className="min-h-screen flex items-center justify-center p-6">
            <div className="text-xs text-emerald-100/60">Verifying permissions...</div>
          </div>
        );
      }
      if (!data?.user.isAdmin) {
        return (
          <div className="min-h-screen flex items-center justify-center p-6">
            <div className="max-w-md w-full bell-card rounded-3xl p-6 text-center space-y-4">
              <div className="font-display text-2xl font-bold text-white">BELLGRAM</div>
              <p className="text-sm text-rose-200">
                {lang === 'ar'
                  ? 'لوحة الإدارة غير متاحة لهذا الحساب.'
                  : 'Admin access is restricted to authorized administrators.'}
              </p>
              <button
                type="button"
                onClick={exitAdmin}
                className="min-h-[44px] px-6 rounded-xl bell-cta-emerald text-sm font-semibold cursor-pointer"
              >
                {t(lang, 'backToHome')}
              </button>
            </div>
          </div>
        );
      }
    }
    return <AdminDashboard onExitAdmin={exitAdmin} onRefreshApp={refreshBootstrap} />;
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="flex flex-col items-center gap-3 text-center">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 border border-emerald-400/30 flex items-center justify-center animate-pulse">
            <Bell className="w-6 h-6 text-emerald-400" />
          </div>
          <div className="font-display text-xl font-bold text-white">BELLGRAM</div>
          <div className="text-xs text-emerald-100/60">Loading mining session...</div>
        </div>
      </div>
    );
  }

  if (loadError || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="max-w-md w-full bell-card rounded-3xl p-6 text-center space-y-4">
          <div className="font-display text-2xl font-bold text-white">BELLGRAM</div>
          <p className="text-sm text-rose-200">{loadError || 'Unable to load session.'}</p>
          <button
            type="button"
            onClick={refreshBootstrap}
            className="min-h-[44px] px-6 rounded-xl bell-cta-emerald text-sm font-semibold cursor-pointer"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  const showChannelGate = !data.user.channelsVerified;
  const userInitial = data.user.firstName.slice(0, 1).toUpperCase();

  return (
    <div className="min-h-screen flex flex-col pb-24">
      {/* Top Bar */}
      <header className="sticky top-0 z-30 backdrop-blur-md bg-[#04100a]/80 border-b border-emerald-400/10">
        <div className="max-w-5xl mx-auto px-3 sm:px-4 h-[60px] flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-1.5 sm:gap-2 text-white cursor-pointer shrink-0"
          >
            <Bell className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-400 fill-emerald-400 shrink-0" />
            <span className="font-display text-lg sm:text-xl font-bold tracking-wide">BELLGRAM</span>
          </button>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setLang((prev) => (prev === 'en' ? 'ar' : 'en'))}
              aria-label="Toggle language"
              className="min-h-[36px] px-2 sm:px-2.5 rounded-xl bg-emerald-950/70 border border-emerald-400/20 text-[11px] sm:text-xs font-semibold text-emerald-100 hover:border-emerald-400/40 inline-flex items-center gap-1 cursor-pointer whitespace-nowrap"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>{lang === 'en' ? 'عربي' : 'EN'}</span>
            </button>

            {data.user.isAdmin && (
              <button
                type="button"
                onClick={openAdmin}
                aria-label="Open Admin Dashboard"
                className="min-h-[36px] min-w-[36px] px-2 sm:px-2.5 rounded-xl bg-emerald-950/70 border border-emerald-400/20 text-xs font-semibold text-emerald-100 hover:border-emerald-400/40 inline-flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap"
              >
                <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="hidden sm:inline">{t(lang, 'admin')}</span>
              </button>
            )}

            <div className="flex items-center gap-1.5 sm:gap-2 pl-1 pr-2 py-1 rounded-full bg-emerald-950/70 border border-emerald-400/20">
              <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-emerald-400 text-[#031a0f] font-bold text-[11px] sm:text-xs flex items-center justify-center shrink-0">
                {userInitial}
              </div>
              <div className="leading-tight text-start">
                <div className="text-[11px] sm:text-xs font-semibold text-white truncate max-w-[54px] sm:max-w-[90px]">
                  {data.user.firstName}
                </div>
                <div className="text-[10px] text-emerald-100/60 font-num whitespace-nowrap">
                  {t(lang, 'level')} {data.user.level.level}
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-5xl mx-auto px-4 pt-4">
        {showChannelGate ? (
          <ChannelGate
            channels={data.channels}
            lang={lang}
            onJoinChannel={async (channelId) => {
              const updated = await api.joinChannelIntent(channelId);
              setData(updated);
            }}
            onVerifyChannels={async () => {
              const res = await api.verifyChannels();
              setData(res.bootstrap);
              if (!res.verification.verified) {
                return res.verification.message || 'Verification incomplete.';
              }
              return null;
            }}
          />
        ) : activeTab === 'home' ? (
          <HomeView
            data={data}
            lang={lang}
            onClaimMining={async () => {
              const key = crypto.randomUUID();
              const res = await api.claimMining(key);
              setData(res.bootstrap);
            }}
            onClaimDaily={async () => {
              const res = await api.claimDaily();
              setData(res.bootstrap);
            }}
            onNavigateWallet={() => setActiveTab('wallet')}
            onNavigateMissions={() => setActiveTab('missions')}
          />
        ) : activeTab === 'missions' ? (
          <MissionCenterView
            missions={data.missions}
            lang={lang}
            onClaimMission={async (missionId) => {
              const res = await api.claimMission(missionId);
              setData(res.bootstrap);
            }}
            onBack={() => setActiveTab('home')}
          />
        ) : activeTab === 'friends' ? (
          <FriendsView friends={data.friends} lang={lang} />
        ) : (
          <WalletView
            data={data}
            lang={lang}
            onConnectWalletAddress={async (address, walletApp) => {
              const res = await api.connectWallet(address, walletApp);
              setData(res.bootstrap);
            }}
            onRefreshWallet={async () => {
              const res = await api.refreshWallet();
              setData(res.bootstrap);
            }}
            onDisconnectWallet={async () => {
              const res = await api.disconnectWallet();
              setData(res.bootstrap);
            }}
            onVerifyWalletPayment={async () => {
              const res = await api.confirmWalletVerification();
              setData(res.bootstrap);
              return res.verification;
            }}
            onRequestWithdrawal={async (amountBell, tonAddress) => {
              const res = await api.requestWithdrawal(amountBell, tonAddress);
              setData(res.bootstrap);
              return res.withdrawal;
            }}
          />
        )}
      </main>

      {/* Fixed Bottom Navigation Bar (Home, Friends, Wallet) */}
      {!showChannelGate && (
        <nav
          aria-label="Primary Navigation"
          className="fixed bottom-3 left-4 right-4 z-40 max-w-md mx-auto rounded-2xl bg-[#06180f]/92 backdrop-blur-lg border border-emerald-400/20 p-1.5 shadow-2xl"
        >
          <div className="grid grid-cols-3 gap-1">
            {(
              [
                { id: 'home', label: t(lang, 'home'), icon: Home },
                { id: 'friends', label: t(lang, 'friends'), icon: Users },
                { id: 'wallet', label: t(lang, 'wallet'), icon: Wallet },
              ] as const
            ).map(({ id, label, icon: Icon }) => {
              const isActive = activeTab === id || (id === 'home' && activeTab === 'missions');
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => setActiveTab(id)}
                  className={`min-h-[48px] rounded-xl flex flex-col items-center justify-center gap-0.5 transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-emerald-500/18 border border-emerald-400/35 text-emerald-300'
                      : 'text-emerald-100/55 hover:text-white border border-transparent'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-[11px] font-semibold">{label}</span>
                </button>
              );
            })}
          </div>
        </nav>
      )}
    </div>
  );
}
