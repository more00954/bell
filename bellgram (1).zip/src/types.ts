export type Language = 'en' | 'ar';

export interface MiningLevel {
  level: number;
  name: string;
  nameAr: string;
  minBellgram: number;
  dailyBell: number;
}

export interface ChannelConfig {
  id: string;
  title: string;
  titleAr: string;
  username: string;
  url: string;
  isRequired: boolean;
}

export interface MiningSessionState {
  id: number | null;
  status: 'running' | 'paused' | 'idle';
  dailyRateBell: number;
  hourlyRateBell: number;
  multiplierBps: number;
  startedAtMs: number;
  endsAtMs: number;
  serverNowMs: number;
  accruedMicro: number;
  claimedMicro: number;
  remainingSec: number;
  progressPct: number;
  isExpired: boolean;
  minClaimBell: number;
}

export interface DailyLoginState {
  canClaim: boolean;
  currentDayIndex: number; // 1..7
  todayRewardBell: number;
  rewardsSchedule: number[];
  lastClaimDateUtc: string | null;
  streakBroken: boolean;
}

export interface WalletState {
  connected: boolean;
  tonAddress: string | null;
  walletApp: string | null;
  tonBalanceNano: number;
  bellgramBalanceMicro: number;
  isVerifiedSource: boolean;
  contractConfigured: boolean;
  disclosureNote: string;
  walletVerified: boolean;
  walletVerifiedAt: string | null;
  walletVerifiedTxHash: string | null;
  verificationRecipientAddress: string;
  verificationAmountNano: number;
}

export interface ChannelStatus extends ChannelConfig {
  joined: boolean;
}

export interface MissionItem {
  id: number;
  code: string;
  titleEn: string;
  titleAr: string;
  descriptionEn: string;
  descriptionAr: string;
  missionType: 'channel' | 'referral_count' | 'daily_login' | 'custom';
  targetValue: number;
  channelUsername: string | null;
  channelUrl: string | null;
  rewardBell: number;
  status: 'Available' | 'Pending' | 'Completed';
  progressCurrent: number;
  progressTarget: number;
  canClaim: boolean;
}

export interface FriendItem {
  id: number;
  telegramId: string;
  username: string | null;
  firstName: string;
  joinedAt: string;
  bonusBell: number;
  walletVerified: boolean;
}

export interface FriendsSummary {
  inviteLink: string;
  botUsername: string;
  referralBonusBell: number;
  friendsCount: number;
  friendsOfFriendsCount: number;
  friends: FriendItem[];
}

export interface TransactionItem {
  id: number;
  txType: string;
  amountMicro: number;
  balanceAfterMicro: number;
  description: string;
  createdAt: string;
}

export interface UserProfile {
  id: number;
  telegramId: string;
  username: string | null;
  firstName: string;
  lastName: string | null;
  balanceMicro: number;
  totalMinedMicro: number;
  level: MiningLevel;
  nextLevel: MiningLevel | null;
  boostBps: number;
  channelsVerified: boolean;
  isBanned: boolean;
  isPreviewMode: boolean;
  isAdmin: boolean;
}

export type WithdrawalStatus = 'pending' | 'completed' | 'rejected';

export interface WithdrawalItem {
  id: number;
  amountMicro: number;
  tonAddress: string;
  status: WithdrawalStatus;
  rejectionReason: string | null;
  txHash: string | null;
  reviewedAt: string | null;
  createdAt: string;
}

export interface BootstrapPayload {
  user: UserProfile;
  mining: MiningSessionState;
  daily: DailyLoginState;
  wallet: WalletState;
  levels: MiningLevel[];
  channels: ChannelStatus[];
  missions: MissionItem[];
  friends: FriendsSummary;
  transactions: TransactionItem[];
  withdrawals: WithdrawalItem[];
  settings: {
    botUsername: string;
    sessionDurationHours: number;
    minClaimBell: number;
    minWithdrawBell: number;
    referralBonusBell: number;
  };
}
