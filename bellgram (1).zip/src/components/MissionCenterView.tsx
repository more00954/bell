import React, { useState } from 'react';
import { ArrowLeft, Calendar, CheckCircle2, Clock, ExternalLink, Send, Sparkles, Users } from 'lucide-react';
import { t } from '../lib/i18n.ts';
import type { Language, MissionItem } from '../types.ts';

interface MissionCenterViewProps {
  missions: MissionItem[];
  lang: Language;
  onClaimMission: (missionId: number) => Promise<void>;
  onBack: () => void;
}

export function MissionCenterView({
  missions,
  lang,
  onClaimMission,
  onBack,
}: MissionCenterViewProps) {
  const [filter, setFilter] = useState<'all' | 'available' | 'completed'>('all');
  const [busyId, setBusyId] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const filtered = missions.filter((m) => {
    if (filter === 'available') return m.status !== 'Completed';
    if (filter === 'completed') return m.status === 'Completed';
    return true;
  });

  const handleClaim = async (m: MissionItem) => {
    setFeedback(null);
    setBusyId(m.id);
    try {
      await onClaimMission(m.id);
      const isVerifiedType = m.missionType !== 'custom';
      setFeedback({
        type: 'ok',
        text:
          lang === 'ar'
            ? isVerifiedType
              ? `تم التحقق وإضافة +${m.rewardBell} BELL!`
              : `تم استلام المهمة وإضافة +${m.rewardBell} BELL!`
            : isVerifiedType
            ? `Mission verified! +${m.rewardBell} BELL added to your balance.`
            : `Reward claimed! +${m.rewardBell} BELL added to your balance.`,
      });
    } catch (err) {
      setFeedback({ type: 'err', text: (err as Error).message });
    } finally {
      setBusyId(null);
    }
  };

  const handleOpenMissionLink = (e: React.MouseEvent<HTMLAnchorElement>, m: MissionItem, safeUrl: string) => {
    const tg = window.Telegram?.WebApp;
    if (tg?.initData) {
      if (m.missionType === 'channel' && safeUrl.includes('t.me/') && tg.openTelegramLink) {
        e.preventDefault();
        tg.openTelegramLink(safeUrl);
        return;
      }
      if (tg.openLink) {
        e.preventDefault();
        tg.openLink(safeUrl);
      }
    }
  };

  const renderIcon = (m: MissionItem) => {
    if (m.missionType === 'channel') return <Send className="w-5 h-5" />;
    if (m.missionType === 'referral_count') return <Users className="w-5 h-5" />;
    if (m.missionType === 'daily_login') return <Calendar className="w-5 h-5" />;
    if (m.channelUrl) return <ExternalLink className="w-5 h-5" />;
    return <Sparkles className="w-5 h-5" />;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBack}
          className="min-h-[44px] inline-flex items-center gap-2 px-3 rounded-xl bg-emerald-950/70 border border-emerald-400/20 text-sm text-emerald-100 hover:border-emerald-400/40 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
          <span>{t(lang, 'backToHome')}</span>
        </button>

        <div className="flex items-center gap-1 p-1 rounded-xl bg-emerald-950/70 border border-emerald-400/20">
          {(['all', 'available', 'completed'] as const).map((tab) => (
            <button
              key={tab}
              type="button"
              onClick={() => setFilter(tab)}
              className={`min-h-[36px] px-3 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                filter === tab
                  ? 'bg-emerald-400 text-[#031a0f]'
                  : 'text-emerald-100/70 hover:text-white'
              }`}
            >
              {tab === 'all'
                ? lang === 'ar'
                  ? 'الكل'
                  : 'All'
                : tab === 'available'
                ? t(lang, 'available')
                : t(lang, 'completed')}
            </button>
          ))}
        </div>
      </div>

      <div className="bell-card rounded-3xl p-5 space-y-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">{t(lang, 'missionCenter')}</h1>
          <p className="text-xs text-emerald-100/60 mt-1">{t(lang, 'dailyTasksRewards')}</p>
        </div>

        {feedback && (
          <div
            role="status"
            className={`rounded-xl px-4 py-3 text-xs font-medium border ${
              feedback.type === 'ok'
                ? 'bg-emerald-500/15 border-emerald-400/35 text-emerald-100'
                : 'bg-rose-500/15 border-rose-400/35 text-rose-100'
            }`}
          >
            {feedback.text}
          </div>
        )}

        <div className="space-y-3">
          {filtered.map((m) => {
            const title = (lang === 'ar' ? m.titleAr : m.titleEn) || m.titleEn || m.titleAr;
            const desc = (lang === 'ar' ? m.descriptionAr : m.descriptionEn) || m.descriptionEn || m.descriptionAr;
            const pct = Math.min(100, Math.round((m.progressCurrent / Math.max(1, m.progressTarget)) * 100));
            const safeUrl = m.channelUrl && /^https?:\/\//i.test(m.channelUrl) ? m.channelUrl : null;
            const isTelegramMission = m.missionType === 'channel';
            const isExternalMission = m.missionType === 'custom';

            return (
              <div
                key={m.id}
                className={`rounded-2xl p-4 border transition-colors ${
                  m.status === 'Completed'
                    ? 'bg-emerald-950/40 border-emerald-400/15 opacity-80'
                    : 'bg-emerald-950/70 border-emerald-400/25'
                }`}
              >
                <div className="flex items-start justify-between gap-3 flex-wrap sm:flex-nowrap">
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <div className="w-11 h-11 rounded-xl bg-emerald-500/12 border border-emerald-400/25 flex items-center justify-center text-emerald-400 shrink-0">
                      {renderIcon(m)}
                    </div>
                    <div className="min-w-0">
                      <div className="font-semibold text-sm text-white">{title}</div>
                      {desc && <p className="text-xs text-emerald-100/60 mt-0.5 leading-relaxed">{desc}</p>}
                      <div className="flex flex-wrap items-center gap-2 text-xs mt-2 font-num">
                        <span className="font-semibold text-amber-300">+{m.rewardBell} BELL</span>
                        <span aria-hidden="true" className="text-emerald-100/30">
                          ·
                        </span>
                        {isTelegramMission ? (
                          <span className="text-sky-300/90 font-medium">{t(lang, 'telegramVerifiedTag')}</span>
                        ) : isExternalMission && safeUrl ? (
                          <span className="text-emerald-200/75 font-medium">{t(lang, 'externalTaskTag')}</span>
                        ) : (
                          <span className="text-emerald-100/60">
                            {m.progressCurrent}/{m.progressTarget}
                          </span>
                        )}
                        <span aria-hidden="true" className="text-emerald-100/30">
                          ·
                        </span>
                        <span
                          className={
                            m.status === 'Completed'
                              ? 'text-emerald-400 font-semibold'
                              : m.status === 'Pending'
                              ? 'text-amber-300 font-semibold'
                              : 'text-emerald-100/75'
                          }
                        >
                          {m.status === 'Completed'
                            ? t(lang, 'completed')
                            : m.status === 'Pending'
                            ? t(lang, 'pending')
                            : t(lang, 'available')}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="shrink-0 flex flex-col items-end gap-2">
                    {m.status === 'Completed' ? (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-400">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{t(lang, 'completed')}</span>
                      </span>
                    ) : m.status === 'Pending' ? (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-300">
                        <Clock className="w-4 h-4" />
                        <span>{t(lang, 'pending')}</span>
                      </span>
                    ) : (
                      <div className="flex items-center gap-2">
                        {safeUrl && (
                          <a
                            href={safeUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => handleOpenMissionLink(e, m, safeUrl)}
                            className="min-h-[40px] px-3 rounded-xl border border-emerald-400/30 text-xs font-semibold text-emerald-100 inline-flex items-center gap-1.5 hover:bg-emerald-900/50"
                          >
                            <span>{isTelegramMission ? t(lang, 'joinBtn') : t(lang, 'openLinkBtn')}</span>
                            {!isTelegramMission && <ExternalLink className="w-3.5 h-3.5" />}
                          </a>
                        )}
                        <button
                          type="button"
                          onClick={() => handleClaim(m)}
                          disabled={!m.canClaim || busyId === m.id}
                          className={`min-h-[40px] px-4 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer ${
                            m.canClaim
                              ? 'bell-cta-emerald'
                              : 'bg-emerald-950 border border-emerald-400/15 text-emerald-100/45 cursor-not-allowed'
                          }`}
                        >
                          {busyId === m.id
                            ? '...'
                            : isExternalMission
                            ? t(lang, 'claimBtn')
                            : t(lang, 'verifyClaim')}
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {!isTelegramMission && !isExternalMission && (
                  <div className="w-full h-1.5 rounded-full bg-black/40 mt-3 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-emerald-400 transition-all"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

