import React, { useState } from 'react';
import { Check, Send, AlertCircle } from 'lucide-react';
import { GoldenBellIcon } from './BellArtwork.tsx';
import { t } from '../lib/i18n.ts';
import type { ChannelStatus, Language } from '../types.ts';

interface ChannelGateProps {
  channels: ChannelStatus[];
  lang: Language;
  onJoinChannel: (channelId: string, url: string) => Promise<void>;
  onVerifyChannels: () => Promise<string | null>;
}

export function ChannelGate({
  channels,
  lang,
  onJoinChannel,
  onVerifyChannels,
}: ChannelGateProps) {
  const [busyId, setBusyId] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleJoin = async (ch: ChannelStatus) => {
    setErrorMsg(null);
    setBusyId(ch.id);
    try {
      if (window.Telegram?.WebApp?.initData && window.Telegram.WebApp.openTelegramLink && ch.url.includes('t.me/')) {
        window.Telegram.WebApp.openTelegramLink(ch.url);
      }
      await onJoinChannel(ch.id, ch.url);
    } catch (err) {
      setErrorMsg((err as Error).message);
    } finally {
      setBusyId(null);
    }
  };

  const handleCheck = async () => {
    setErrorMsg(null);
    setChecking(true);
    try {
      const errText = await onVerifyChannels();
      if (errText) {
        setErrorMsg(errText);
      }
    } catch (err) {
      setErrorMsg((err as Error).message);
    } finally {
      setChecking(false);
    }
  };

  const pendingChannels = channels.filter((ch) => ch.isRequired && !ch.joined);

  return (
    <div className="min-h-[calc(100dvh-5rem)] flex flex-col items-center justify-center px-4 py-8">
      <div className="w-full max-w-md flex flex-col items-center text-center">
        <GoldenBellIcon className="w-20 h-20 mb-5" />

        <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white mb-3">
          {t(lang, 'joinTitle')}
        </h1>

        <p className="text-sm text-emerald-100/70 leading-relaxed max-w-sm mb-7">
          {t(lang, 'joinSubtitle')}
        </p>

        <div className="w-full space-y-3 mb-6">
          {pendingChannels.length === 0 ? (
            <div className="bell-card rounded-2xl px-4 py-3.5 flex items-center justify-center gap-2 text-xs text-emerald-300">
              <Check className="w-4 h-4 shrink-0" />
              <span>
                {lang === 'ar'
                  ? 'تم التحقق من القنوات، اضغط على زر التحقق بالأسفل.'
                  : 'All required channels checked — tap the button below.'}
              </span>
            </div>
          ) : (
            pendingChannels.map((ch) => {
              const displayTitle = lang === 'ar' ? ch.titleAr : ch.title;
              return (
                <div
                  key={ch.id}
                  className="bell-card rounded-2xl px-4 py-3.5 flex items-center justify-between gap-3 text-start"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="w-11 h-11 rounded-xl bg-emerald-500/10 border border-emerald-400/25 flex items-center justify-center shrink-0 text-emerald-400">
                      <Send className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="font-semibold text-[15px] text-white truncate">
                        {displayTitle}
                      </div>
                      <div className="text-xs text-emerald-100/55 mt-0.5">
                        {t(lang, 'notJoinedYet')}
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleJoin(ch)}
                    disabled={busyId === ch.id}
                    className="min-h-[40px] px-5 rounded-xl bg-emerald-950/90 border border-emerald-400/30 text-sm font-semibold text-emerald-100 hover:bg-emerald-900/70 hover:border-emerald-400/50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    {busyId === ch.id ? '...' : t(lang, 'joinBtn')}
                  </button>
                </div>
              );
            })
          )}
        </div>

        {errorMsg && (
          <div
            role="alert"
            className="w-full mb-4 rounded-xl bg-amber-500/10 border border-amber-400/30 px-4 py-3 text-xs text-amber-200 flex items-center gap-2 text-start"
          >
            <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        <button
          type="button"
          onClick={handleCheck}
          disabled={checking}
          className="w-full min-h-[52px] rounded-2xl bell-cta-emerald font-semibold text-base transition-all cursor-pointer disabled:opacity-60"
        >
          {checking ? t(lang, 'checking') : t(lang, 'iveJoinedCheck')}
        </button>
      </div>
    </div>
  );
}
