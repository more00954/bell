import React, { useEffect, useRef, useState } from 'react';
import { TonConnectUI } from '@tonconnect/ui';
import {
  ArrowUpRight,
  CheckCircle2,
  Clock,
  History,
  Lock,
  RefreshCw,
  Send,
  ShieldAlert,
  ShieldCheck,
  Unlock,
  Unplug,
  Wallet,
  XCircle,
} from 'lucide-react';
import { formatBell, formatTon } from '../lib/bellMath.ts';
import { t } from '../lib/i18n.ts';
import type { BootstrapPayload, Language } from '../types.ts';

interface WalletViewProps {
  data: BootstrapPayload;
  lang: Language;
  onConnectWalletAddress: (address: string, walletApp?: string) => Promise<void>;
  onRefreshWallet: () => Promise<void>;
  onDisconnectWallet: () => Promise<void>;
  onVerifyWalletPayment: () => Promise<{
    verified: boolean;
    pending?: boolean;
    txHash?: string;
    message: string;
  }>;
  onRequestWithdrawal: (amountBell: number, tonAddress?: string) => Promise<{ id: number }>;
}

export function WalletView({
  data,
  lang,
  onConnectWalletAddress,
  onRefreshWallet,
  onDisconnectWallet,
  onVerifyWalletPayment,
  onRequestWithdrawal,
}: WalletViewProps) {
  const tonConnectRef = useRef<TonConnectUI | null>(null);
  const mountedRef = useRef(true);
  const pendingAutoPayRef = useRef(false);
  const verifyParamsRef = useRef({
    address: data.wallet.verificationRecipientAddress,
    amountNano: data.wallet.verificationAmountNano,
  });
  const currentAddressRef = useRef<string | null>(data.wallet.tonAddress);
  const onConnectRef = useRef(onConnectWalletAddress);
  const onVerifyRef = useRef(onVerifyWalletPayment);
  const langRef = useRef<Language>(lang);
  const [busy, setBusy] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [verifyBusy, setVerifyBusy] = useState(false);
  const [verifyFeedback, setVerifyFeedback] = useState<{
    type: 'ok' | 'info' | 'err';
    text: string;
  } | null>(null);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawAddress, setWithdrawAddress] = useState(() => data.wallet.tonAddress || '');
  const [withdrawBusy, setWithdrawBusy] = useState(false);
  const [withdrawFeedback, setWithdrawFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(
    null
  );

  useEffect(() => {
    if (data.wallet.tonAddress && !withdrawAddress) {
      setWithdrawAddress(data.wallet.tonAddress);
    }
  }, [data.wallet.tonAddress, withdrawAddress]);

  currentAddressRef.current = data.wallet.tonAddress;
  onConnectRef.current = onConnectWalletAddress;
  onVerifyRef.current = onVerifyWalletPayment;
  langRef.current = lang;
  verifyParamsRef.current = {
    address: data.wallet.verificationRecipientAddress,
    amountNano: data.wallet.verificationAmountNano,
  };

  const sendVerificationTransaction = async (tc: TonConnectUI) => {
    setVerifyFeedback(null);
    setVerifyBusy(true);
    try {
      await tc.sendTransaction({
        validUntil: Math.floor(Date.now() / 1000) + 600,
        messages: [
          {
            address: verifyParamsRef.current.address,
            amount: String(verifyParamsRef.current.amountNano),
          },
        ],
      });

      const activeLang = langRef.current;
      if (!mountedRef.current) return;
      setVerifyFeedback({ type: 'info', text: t(activeLang, 'paymentSentConfirming') });

      for (let attempt = 0; attempt < 8; attempt++) {
        await new Promise((r) => setTimeout(r, 4000));
        if (!mountedRef.current) return;
        const res = await onVerifyRef.current();
        if (res.verified) {
          if (mountedRef.current) {
            setVerifyFeedback({ type: 'ok', text: t(langRef.current, 'walletVerifiedSuccessMsg') });
          }
          return;
        }
      }

      if (mountedRef.current) {
        setVerifyFeedback({
          type: 'info',
          text:
            langRef.current === 'ar'
              ? 'تم إرسال المعاملة وجارٍ انتظار تأكيد الشبكة. اضغط "لقد دفعت — تحقق الآن" بعد ثوانٍ.'
              : 'Transaction broadcast! Waiting for TON block finality — tap "I Paid — Verify Now" in a few seconds.',
        });
      }
    } catch (err) {
      if (mountedRef.current) {
        setVerifyFeedback({ type: 'err', text: (err as Error).message });
      }
    } finally {
      if (mountedRef.current) setVerifyBusy(false);
    }
  };


  useEffect(() => {
    let mounted = true;
    try {
      const ui = new TonConnectUI({
        manifestUrl: `${window.location.origin}/tonconnect-manifest.json`,
      });
      tonConnectRef.current = ui;

      const unsubscribe = ui.onStatusChange(async (wallet) => {
        if (!mounted) return;
        if (wallet?.account?.address) {
          if (wallet.account.address !== currentAddressRef.current) {
            setBusy(true);
            try {
              await onConnectRef.current(
                wallet.account.address,
                wallet.device?.appName || 'TON Connect'
              );
            } catch (err) {
              setErrorMsg((err as Error).message);
              pendingAutoPayRef.current = false;
              setBusy(false);
              return;
            } finally {
              setBusy(false);
            }
          }

          if (pendingAutoPayRef.current) {
            pendingAutoPayRef.current = false;
            await sendVerificationTransaction(ui);
          }
        }
      });

      return () => {
        mounted = false;
        mountedRef.current = false;
        unsubscribe();
      };
    } catch {
      return undefined;
    }
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const handleOpenTonConnect = async () => {
    setErrorMsg(null);
    if (!tonConnectRef.current) {
      setErrorMsg(
        lang === 'ar'
          ? 'تعذر تهيئة TON Connect في هذا المتصفح.'
          : 'TON Connect could not initialize in this browser context.'
      );
      return;
    }
    try {
      await tonConnectRef.current.openModal();
    } catch (err) {
      setErrorMsg((err as Error).message);
    }
  };

  const handleDisconnect = async () => {
    setBusy(true);
    setErrorMsg(null);
    try {
      if (tonConnectRef.current?.connected) {
        await tonConnectRef.current.disconnect().catch(() => {});
      }
      await onDisconnectWallet();
    } catch (err) {
      setErrorMsg((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const handleCheckVerification = async () => {
    setVerifyFeedback(null);
    setVerifyBusy(true);
    try {
      const res = await onVerifyWalletPayment();
      if (!mountedRef.current) return;
      if (res.verified) {
        setVerifyFeedback({ type: 'ok', text: t(lang, 'walletVerifiedSuccessMsg') });
      } else {
        setVerifyFeedback({ type: 'info', text: res.message });
      }
    } catch (err) {
      if (mountedRef.current) {
        setVerifyFeedback({ type: 'err', text: (err as Error).message });
      }
    } finally {
      if (mountedRef.current) setVerifyBusy(false);
    }
  };

  const handlePayAndVerify = async () => {
    setVerifyFeedback(null);
    const tc = tonConnectRef.current;
    if (!tc) {
      setVerifyFeedback({
        type: 'err',
        text:
          lang === 'ar'
            ? 'تعذر تهيئة TON Connect في هذا المتصفح.'
            : 'TON Connect could not initialize in this browser context.',
      });
      return;
    }

    try {
      await tc.connectionRestored;
    } catch {
      // ignore connection restore error
    }

    if (!tc.connected) {
      pendingAutoPayRef.current = true;
      try {
        await tc.openModal();
      } catch (err) {
        pendingAutoPayRef.current = false;
        setVerifyFeedback({ type: 'err', text: (err as Error).message });
      }
      return;
    }

    await sendVerificationTransaction(tc);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
      <div className="lg:col-span-6 space-y-4">
        {/* App Balance Card */}
        <section className="bell-card rounded-3xl p-5 space-y-2">
          <div className="text-xs text-emerald-100/60 font-medium">{t(lang, 'appBalance')}</div>
          <div className="flex items-baseline gap-2">
            <span
              data-testid="wallet-app-balance"
              className="font-num text-3xl font-bold text-white"
            >
              {formatBell(data.user.balanceMicro)}
            </span>
            <span className="font-display text-lg font-bold text-emerald-400">BELL</span>
          </div>
          <div className="text-xs text-emerald-100/55 font-num">
            {t(lang, 'totalMined')}: {formatBell(data.user.totalMinedMicro)} BELL
          </div>
        </section>

        {/* Withdraw BELL Card */}
        <section className="bell-card rounded-3xl p-5 space-y-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-display text-2xl font-bold text-white">
                  {t(lang, 'withdrawBell')}
                </h2>
                <span
                  data-testid="withdraw-lock-badge"
                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-[11px] font-semibold border ${
                    data.wallet.walletVerified
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-400/30'
                      : 'bg-amber-500/15 text-amber-200 border-amber-400/30'
                  }`}
                >
                  {data.wallet.walletVerified ? (
                    <>
                      <Unlock className="w-3 h-3" />
                      <span>{t(lang, 'withdrawUnlockedBadge')}</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-3 h-3" />
                      <span>{t(lang, 'withdrawLockedBadge')}</span>
                    </>
                  )}
                </span>
              </div>
              <p className="text-xs text-emerald-100/60 mt-1">{t(lang, 'withdrawSubtitle')}</p>
            </div>
            <ArrowUpRight className="w-5 h-5 text-emerald-400 shrink-0 mt-1" />
          </div>

          {!data.wallet.walletVerified ? (
            <div
              data-testid="withdraw-locked-panel"
              className="rounded-2xl bg-black/40 border border-amber-400/25 p-4 space-y-3"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-400/30 flex items-center justify-center text-amber-300 shrink-0">
                  <Lock className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-white">
                    {t(lang, 'withdrawLockedTitle')}
                  </div>
                  <p className="text-xs text-emerald-100/65 mt-1 leading-relaxed">
                    {t(lang, 'withdrawLockedDesc')}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handlePayAndVerify}
                disabled={verifyBusy || busy}
                className="w-full min-h-[44px] rounded-xl bell-cta-gold text-xs font-bold inline-flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{verifyBusy ? t(lang, 'checkingPaymentBtn') : t(lang, 'payAndVerifyBtn')}</span>
              </button>
            </div>
          ) : (
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                setWithdrawFeedback(null);
                setWithdrawBusy(true);
                try {
                  const res = await onRequestWithdrawal(
                    Number(withdrawAmount),
                    withdrawAddress.trim() || undefined
                  );
                  setWithdrawAmount('');
                  setWithdrawFeedback({
                    type: 'ok',
                    text: t(lang, 'withdrawSubmitted', { id: res.id }),
                  });
                } catch (err) {
                  setWithdrawFeedback({ type: 'err', text: (err as Error).message });
                } finally {
                  setWithdrawBusy(false);
                }
              }}
              className="space-y-3"
            >
              <div>
                <div className="flex items-center justify-between text-xs text-emerald-100/75 mb-1.5">
                  <label htmlFor="withdraw-amount">{t(lang, 'withdrawAmount')}</label>
                  <button
                    type="button"
                    onClick={() =>
                      setWithdrawAmount((data.user.balanceMicro / 10_000).toFixed(4))
                    }
                    className="text-emerald-400 hover:text-emerald-300 font-semibold cursor-pointer"
                  >
                    {t(lang, 'maxBtn')} ({formatBell(data.user.balanceMicro)})
                  </button>
                </div>
                <input
                  id="withdraw-amount"
                  type="number"
                  step="0.0001"
                  min={data.settings.minWithdrawBell}
                  required
                  dir="ltr"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  placeholder={String(data.settings.minWithdrawBell)}
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-black/45 border border-emerald-400/25 text-sm font-num text-white focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div>
                <label
                  htmlFor="withdraw-ton-address"
                  className="block text-xs text-emerald-100/75 mb-1.5"
                >
                  {t(lang, 'destinationAddress')}
                </label>
                <input
                  id="withdraw-ton-address"
                  type="text"
                  required
                  dir="ltr"
                  value={withdrawAddress}
                  onChange={(e) => setWithdrawAddress(e.target.value)}
                  placeholder="EQ... / UQ..."
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-black/45 border border-emerald-400/25 text-xs font-mono text-white focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div className="text-[11px] text-emerald-100/55 font-num">
                {t(lang, 'minWithdrawNote', { min: data.settings.minWithdrawBell })}
              </div>

              {withdrawFeedback && (
                <div
                  role="status"
                  className={`rounded-xl px-3 py-2 text-xs font-medium border ${
                    withdrawFeedback.type === 'ok'
                      ? 'bg-emerald-500/15 border-emerald-400/35 text-emerald-100'
                      : 'bg-rose-500/15 border-rose-400/35 text-rose-200'
                  }`}
                >
                  {withdrawFeedback.text}
                </div>
              )}

              <button
                type="submit"
                disabled={withdrawBusy}
                className="w-full min-h-[48px] rounded-2xl bell-cta-emerald text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              >
                <ArrowUpRight className="w-4 h-4" />
                <span>
                  {withdrawBusy ? t(lang, 'submittingWithdraw') : t(lang, 'requestWithdrawal')}
                </span>
              </button>
            </form>
          )}
        </section>

        {/* Wallet Verification Card (0.05 TON) */}
        <section className="bell-card rounded-3xl p-5 space-y-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-display text-xl font-bold text-white">
                  {t(lang, 'walletVerificationTitle')}
                </h2>
                <span
                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-[11px] font-semibold border ${
                    data.wallet.walletVerified
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-400/30'
                      : 'bg-amber-500/15 text-amber-200 border-amber-400/30'
                  }`}
                >
                  {data.wallet.walletVerified
                    ? t(lang, 'walletVerifiedBadge')
                    : t(lang, 'walletUnverifiedBadge')}
                </span>
              </div>
              <p className="text-xs text-emerald-100/60 mt-1">
                {t(lang, 'walletVerificationSubtitle')}
              </p>
            </div>
            <ShieldCheck
              className={`w-5 h-5 shrink-0 mt-1 ${
                data.wallet.walletVerified ? 'text-emerald-400' : 'text-amber-300'
              }`}
            />
          </div>

          <div className="rounded-2xl bg-black/40 border border-emerald-400/15 px-3.5 py-3 flex items-center justify-between gap-2 text-xs">
            <span className="text-emerald-100/65">{t(lang, 'verifyFeeLabel')}</span>
            <span className="font-num font-bold text-amber-300">0.05 TON</span>
          </div>

          {verifyFeedback && (
            <div
              role="status"
              className={`rounded-xl px-3 py-2.5 text-xs font-medium border ${
                verifyFeedback.type === 'ok'
                  ? 'bg-emerald-500/15 border-emerald-400/35 text-emerald-100'
                  : verifyFeedback.type === 'info'
                  ? 'bg-sky-500/15 border-sky-400/35 text-sky-100'
                  : 'bg-rose-500/15 border-rose-400/35 text-rose-200'
              }`}
            >
              {verifyFeedback.text}
            </div>
          )}

          {data.wallet.walletVerified ? (
            <div className="rounded-2xl bg-emerald-500/12 border border-emerald-400/30 p-3.5 text-xs space-y-1">
              <div className="flex items-center gap-2 font-semibold text-emerald-300">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{t(lang, 'walletVerifiedSuccessMsg')}</span>
              </div>
              {data.wallet.walletVerifiedTxHash && (
                <div dir="ltr" className="font-mono text-[11px] text-emerald-100/70 break-all">
                  TX: {data.wallet.walletVerifiedTxHash}
                </div>
              )}
            </div>
          ) : (
            <div className={data.wallet.connected ? 'grid grid-cols-1 sm:grid-cols-2 gap-2' : ''}>
              <button
                type="button"
                onClick={handlePayAndVerify}
                disabled={verifyBusy || busy}
                className="w-full min-h-[44px] px-3 rounded-xl bell-cta-gold text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
              >
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>
                  {verifyBusy ? t(lang, 'checkingPaymentBtn') : t(lang, 'payAndVerifyBtn')}
                </span>
              </button>
              {data.wallet.connected && (
                <button
                  type="button"
                  onClick={handleCheckVerification}
                  disabled={verifyBusy}
                  className="min-h-[44px] px-3 rounded-xl bg-emerald-500/15 border border-emerald-400/35 hover:bg-emerald-500/25 text-xs font-semibold text-emerald-100 inline-flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
                >
                  <RefreshCw className={`w-3.5 h-3.5 shrink-0 ${verifyBusy ? 'animate-spin' : ''}`} />
                  <span>{t(lang, 'checkPaymentNowBtn')}</span>
                </button>
              )}
            </div>
          )}
        </section>

        {/* TON Wallet Card */}
        <section className="bell-card rounded-3xl p-5 space-y-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="font-display text-2xl font-bold text-white">{t(lang, 'tonWallet')}</h2>
              <p className="text-xs text-emerald-100/60 mt-1">
                {data.wallet.connected && data.wallet.tonAddress
                  ? `${data.wallet.walletApp || 'TON Wallet'}: ${data.wallet.tonAddress.slice(0, 8)}...${data.wallet.tonAddress.slice(-6)}`
                  : t(lang, 'connectWalletPrompt')}
              </p>
            </div>
            {data.wallet.connected && (
              <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-400 shrink-0">
                <CheckCircle2 className="w-4 h-4" />
                <span>{lang === 'ar' ? 'متصل' : 'Connected'}</span>
              </span>
            )}
          </div>

          <div className="space-y-2">
            <div className="flex items-baseline gap-2">
              <span className="font-num text-3xl font-bold text-white">
                {formatTon(data.wallet.tonBalanceNano)}
              </span>
              <span className="font-display text-base font-bold text-emerald-400">TON</span>
            </div>

            <div className="flex items-baseline gap-2">
              <span className="font-num text-3xl font-bold text-white">
                {formatBell(data.wallet.bellgramBalanceMicro)}
              </span>
              <span className="font-display text-base font-bold text-emerald-400">BELLGRAM</span>
            </div>
          </div>

          <div className="rounded-xl bg-black/35 border border-emerald-400/15 p-3 flex items-start gap-2.5 text-xs text-emerald-100/65 leading-relaxed">
            <ShieldAlert className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
            <span>{data.wallet.disclosureNote}</span>
          </div>


          {errorMsg && (
            <div role="alert" className="text-xs text-rose-300 bg-rose-500/10 border border-rose-400/30 rounded-xl px-3 py-2">
              {errorMsg}
            </div>
          )}

          {data.wallet.connected ? (
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={async () => {
                  setBusy(true);
                  setErrorMsg(null);
                  try {
                    await onRefreshWallet();
                  } catch (err) {
                    setErrorMsg((err as Error).message);
                  } finally {
                    setBusy(false);
                  }
                }}
                disabled={busy}
                className="min-h-[48px] rounded-2xl bg-emerald-500/15 border border-emerald-400/35 hover:bg-emerald-500/25 text-sm font-semibold text-emerald-100 inline-flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              >
                <RefreshCw className={`w-4 h-4 ${busy ? 'animate-spin' : ''}`} />
                <span>{lang === 'ar' ? 'تحديث الرصيد' : 'Refresh'}</span>
              </button>
              <button
                type="button"
                onClick={handleDisconnect}
                disabled={busy}
                className="min-h-[48px] rounded-2xl bg-emerald-950/80 border border-emerald-400/25 hover:border-rose-400/40 text-sm font-semibold text-emerald-50 inline-flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              >
                <Unplug className="w-4 h-4" />
                <span>{t(lang, 'disconnectWallet')}</span>
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={handleOpenTonConnect}
              disabled={busy}
              className="w-full min-h-[48px] rounded-2xl bell-cta-emerald text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <Wallet className="w-4 h-4" />
              <span>{t(lang, 'connectTonWallet')}</span>
            </button>
          )}
        </section>
      </div>

      <div className="lg:col-span-6 space-y-4">
        {/* Mining Levels Card */}
        <section className="bell-card rounded-3xl p-5 space-y-3">
          <div>
            <h2 className="font-display text-2xl font-bold text-white">
              {t(lang, 'miningLevels')}
            </h2>
            <p className="text-xs text-emerald-100/60 mt-1">{t(lang, 'miningLevelsSubtitle')}</p>
          </div>

          <div className="space-y-2 pt-1">
            {data.levels.map((lvl) => {
              const isCurrent = lvl.level === data.user.level.level;
              const name = lang === 'ar' ? lvl.nameAr : lvl.name;
              return (
                <div
                  key={lvl.level}
                  className={`rounded-2xl px-4 py-3 flex items-center justify-between gap-3 transition-colors ${
                    isCurrent ? 'bell-card-active' : 'bg-transparent border border-transparent'
                  }`}
                >
                  <div>
                    <div className="font-semibold text-[15px] text-white">
                      <span className="font-num">{lvl.level}</span> · {name}
                    </div>
                    <div className="text-xs text-emerald-100/55 mt-0.5">
                      {lvl.minBellgram === 0
                        ? t(lang, 'noBellgramNeeded')
                        : t(lang, 'holdPlusBellgram', {
                            amount: lvl.minBellgram.toLocaleString('en-US'),
                          })}
                    </div>
                  </div>
                  <div className="font-num text-sm font-semibold text-white shrink-0">
                    {t(lang, 'bellPerDay', { amount: lvl.dailyBell.toLocaleString('en-US') })}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Withdrawal Requests Status */}
        <section className="bell-card rounded-3xl p-5 space-y-3">
          <div className="flex items-center gap-2">
            <ArrowUpRight className="w-4 h-4 text-emerald-400" />
            <h2 className="font-display text-xl font-bold text-white">
              {t(lang, 'withdrawalRequests')}
            </h2>
          </div>

          {data.withdrawals.length === 0 ? (
            <p className="text-xs text-emerald-100/55 py-2">{t(lang, 'noWithdrawalsYet')}</p>
          ) : (
            <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
              {data.withdrawals.map((w) => {
                const badge =
                  w.status === 'completed'
                    ? {
                        label: t(lang, 'statusCompleted'),
                        cls: 'bg-emerald-500/15 text-emerald-300 border-emerald-400/30',
                        Icon: CheckCircle2,
                      }
                    : w.status === 'rejected'
                    ? {
                        label: t(lang, 'statusRejected'),
                        cls: 'bg-rose-500/15 text-rose-300 border-rose-400/30',
                        Icon: XCircle,
                      }
                    : {
                        label: t(lang, 'statusPending'),
                        cls: 'bg-amber-500/15 text-amber-200 border-amber-400/30',
                        Icon: Clock,
                      };
                const StatusIcon = badge.Icon;

                return (
                  <div
                    key={w.id}
                    className="rounded-2xl bg-black/35 border border-emerald-400/15 p-3.5 space-y-1.5 text-xs"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="font-num font-bold text-white">
                        #{w.id} · {formatBell(w.amountMicro)} BELL
                      </div>
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-[11px] font-semibold ${badge.cls}`}
                      >
                        <StatusIcon className="w-3 h-3" />
                        <span>{badge.label}</span>
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-2 text-[11px] text-emerald-100/55 font-mono">
                      <span dir="ltr">
                        {w.tonAddress.slice(0, 8)}...{w.tonAddress.slice(-6)}
                      </span>
                      <span className="font-num">{new Date(w.createdAt).toLocaleString()}</span>
                    </div>

                    {w.status === 'completed' && w.txHash && (
                      <div className="text-[11px] text-emerald-300/90 font-mono break-all pt-0.5">
                        TX: {w.txHash}
                      </div>
                    )}

                    {w.status === 'rejected' && w.rejectionReason && (
                      <div className="rounded-xl bg-rose-500/10 border border-rose-400/25 px-2.5 py-1.5 text-[11px] text-rose-200 space-y-0.5">
                        <div>
                          <span className="font-semibold">{t(lang, 'rejectionReasonLabel')} </span>
                          <span>{w.rejectionReason}</span>
                        </div>
                        <div className="text-emerald-300/85">{t(lang, 'refundedNote')}</div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* Transaction History */}
        <section className="bell-card rounded-3xl p-5 space-y-3">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-emerald-400" />
            <h2 className="font-display text-xl font-bold text-white">
              {t(lang, 'transactionsHistory')}
            </h2>
          </div>

          {data.transactions.length === 0 ? (
            <p className="text-xs text-emerald-100/55 py-3">{t(lang, 'noTransactionsYet')}</p>
          ) : (
            <div className="divide-y divide-emerald-400/10 max-h-72 overflow-y-auto pr-1">
              {data.transactions.map((tx) => (
                <div key={tx.id} className="py-2.5 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-white truncate">{tx.description}</div>
                    <div className="text-[11px] text-emerald-100/45 font-num">
                      {new Date(tx.createdAt).toLocaleString()}
                    </div>
                  </div>
                  <div
                    dir="ltr"
                    className={`font-num text-xs font-bold shrink-0 ${
                      tx.amountMicro >= 0 ? 'text-emerald-400' : 'text-amber-300'
                    }`}
                  >
                    {tx.amountMicro >= 0 ? '+' : ''}
                    {formatBell(tx.amountMicro)} BELL
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Compact Developer Link */}
      <div className="lg:col-span-12 flex justify-center pt-1">
        <a
          href="https://t.me/ex_zain"
          target="_blank"
          rel="noopener noreferrer"
          data-testid="wallet-developer-link"
          onClick={(e) => {
            if (window.Telegram?.WebApp?.initData && window.Telegram.WebApp.openTelegramLink) {
              e.preventDefault();
              window.Telegram.WebApp.openTelegramLink('https://t.me/ex_zain');
            }
          }}
          className="min-h-[40px] px-4 rounded-xl bg-emerald-950/70 border border-emerald-400/20 hover:border-emerald-400/45 text-xs font-semibold text-emerald-100/85 hover:text-white inline-flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
        >
          <Send className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>{t(lang, 'developerButton')}</span>
        </a>
      </div>
    </div>
  );
}
