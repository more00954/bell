import React, { useCallback, useEffect, useState } from 'react';
import {
  ArrowLeft,
  ArrowUpRight,
  Ban,
  CheckCircle2,
  Coins,
  Copy,
  Download,
  KeyRound,
  LogOut,
  Network,
  Pencil,
  Plus,
  Search,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  X,
  XCircle,
} from 'lucide-react';
import { bellToMicro, formatBell, microToBell } from '../lib/bellMath.ts';
import { getTelegramInitData } from '../lib/api.ts';
import type { ChannelConfig, MiningLevel, WithdrawalStatus } from '../types.ts';

interface AdminUserSummary {
  id: number;
  telegram_id: string;
  username: string | null;
  first_name: string;
  balance_micro: number;
  total_mined_micro: number;
  level_id: number;
  is_banned: number;
  last_ip?: string | null;
}

interface SimilarIpAccount extends AdminUserSummary {
  matched_ip: string;
  hit_count: number;
  first_seen_at: number;
  last_seen_at: number;
}

interface SimilarIpGroup {
  key: string;
  matchType: 'exact' | 'subnet';
  userCount: number;
  bannedCount: number;
  totalBalanceMicro: number;
  lastSeenAt: number;
  accounts: SimilarIpAccount[];
}

interface AdminDashboardData {
  stats: {
    totalUsers: number;
    activeUsers24h: number;
    totalBellDistributed: number;
    totalMiningRewards: number;
    totalReferrals: number;
    pendingWithdrawalsCount: number;
    similarIpGroupsCount: number;
  };
  users: Array<
    AdminUserSummary & {
      channels_verified: number;
      is_preview: number;
      last_ip: string | null;
      last_active_at: number;
    }
  >;
  similarIps: SimilarIpGroup[];
  recentTransactions: Array<{
    id: number;
    telegram_id: string;
    first_name: string;
    tx_type: string;
    amount_micro: number;
    description: string;
    created_at: number;
  }>;
  auditLogs: Array<{
    id: number;
    admin_actor: string;
    action: string;
    target_type: string;
    target_id: string | null;
    details_json: string;
    created_at: number;
  }>;
  missions: Array<{
    id: number;
    code: string;
    title_en: string;
    title_ar: string;
    description_en: string;
    description_ar: string;
    mission_type: string;
    target_value: number;
    channel_username: string | null;
    channel_url: string | null;
    reward_bell: number;
    is_active: number;
  }>;
  withdrawals: Array<{
    id: number;
    user_id: number;
    telegram_id: string;
    username: string | null;
    first_name: string;
    amount_micro: number;
    ton_address: string;
    status: WithdrawalStatus;
    rejection_reason: string | null;
    tx_hash: string | null;
    reviewed_by: string | null;
    reviewed_at: number | null;
    created_at: number;
  }>;
  settings: {
    miningLevels: MiningLevel[];
    dailyBonusSchedule: number[];
    requiredChannels: ChannelConfig[];
    referralBonusBell: number;
    sessionDurationHours: number;
    minClaimBell: number;
    minWithdrawBell: number;
    botUsername: string;
  };
}

interface AdminDashboardProps {
  onExitAdmin: () => void;
  onRefreshApp: () => Promise<void>;
}

export function AdminDashboard({ onExitAdmin, onRefreshApp }: AdminDashboardProps) {
  // Bearer token held strictly in React memory (never localStorage/sessionStorage)
  const [token, setToken] = useState<string | null>(null);
  const [authStatus, setAuthStatus] = useState<{
    needsSetup: boolean;
    envOverrideActive: boolean;
  } | null>(null);
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authBusy, setAuthBusy] = useState(false);

  const [tab, setTab] = useState<'users' | 'similarIps' | 'withdrawals' | 'mining' | 'channels' | 'logs'>('users');
  const [ipMatchFilter, setIpMatchFilter] = useState<'all' | 'exact' | 'subnet'>('all');
  const [ipSearchQuery, setIpSearchQuery] = useState('');
  const [editingUser, setEditingUser] = useState<AdminUserSummary | null>(null);
  const [balanceMode, setBalanceMode] = useState<'set' | 'add' | 'subtract'>('set');
  const [balanceAmount, setBalanceAmount] = useState('');
  const [balanceReason, setBalanceReason] = useState('');
  const [balanceBusy, setBalanceBusy] = useState(false);

  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [currentPasswordInput, setCurrentPasswordInput] = useState('');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
  const [passwordBusy, setPasswordBusy] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);

  const [withdrawFilter, setWithdrawFilter] = useState<'all' | 'pending' | 'completed' | 'rejected'>('pending');
  const [rejectingId, setRejectingId] = useState<number | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [txHashes, setTxHashes] = useState<Record<number, string>>({});
  const [reviewBusyId, setReviewBusyId] = useState<number | null>(null);
  const [data, setData] = useState<AdminDashboardData | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [banner, setBanner] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Editable state forms
  const [levelsForm, setLevelsForm] = useState<MiningLevel[]>([]);
  const [dailyForm, setDailyForm] = useState<number[]>([]);
  const [channelsForm, setChannelsForm] = useState<ChannelConfig[]>([]);
  const [generalForm, setGeneralForm] = useState({
    referralBonusBell: 50,
    sessionDurationHours: 24,
    minClaimBell: 0.0001,
    minWithdrawBell: 50,
    botUsername: 'bellgrammbot',
  });
  const [newMission, setNewMission] = useState({
    code: '',
    titleEn: '',
    titleAr: '',
    descriptionEn: '',
    descriptionAr: '',
    missionType: 'channel' as 'channel' | 'referral_count' | 'daily_login' | 'custom',
    targetValue: 1,
    channelUsername: '',
    channelUrl: '',
    rewardBell: 25,
  });

  useEffect(() => {
    const initData = getTelegramInitData();
    const headers: Record<string, string> = {};
    if (initData) headers['X-Telegram-Init-Data'] = initData;
    fetch('/api/admin/status', { headers })
      .then((r) => {
        if (!r.ok) throw new Error('Forbidden');
        return r.json();
      })
      .then((s) => setAuthStatus(s))
      .catch(() => setAuthStatus({ needsSetup: false, envOverrideActive: false }));
  }, []);

  const adminFetch = useCallback(
    async <T,>(url: string, options: RequestInit = {}): Promise<T> => {
      const headers = new Headers(options.headers || {});
      const initData = getTelegramInitData();
      if (initData) {
        headers.set('X-Telegram-Init-Data', initData);
      }
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      if (options.method && options.method !== 'GET') {
        headers.set('X-Requested-With', 'bellgram-admin');
      }
      if (options.body && !headers.has('Content-Type')) {
        headers.set('Content-Type', 'application/json');
      }
      const resp = await fetch(url, { ...options, headers });
      const json = await resp.json().catch(() => ({}));
      if (!resp.ok) {
        if (resp.status === 401) {
          setToken(null);
        }
        throw new Error((json as { error?: string }).error || `Request failed (${resp.status})`);
      }
      return json as T;
    },
    [token]
  );

  const syncForms = (d: AdminDashboardData) => {
    setData(d);
    setLevelsForm(d.settings.miningLevels);
    setDailyForm(d.settings.dailyBonusSchedule);
    setChannelsForm(d.settings.requiredChannels);
    setGeneralForm({
      referralBonusBell: d.settings.referralBonusBell,
      sessionDurationHours: d.settings.sessionDurationHours,
      minClaimBell: d.settings.minClaimBell,
      minWithdrawBell: d.settings.minWithdrawBell,
      botUsername: d.settings.botUsername,
    });
  };

  const loadDashboard = useCallback(
    async (q = '') => {
      const url = q
        ? `/api/admin/dashboard?q=${encodeURIComponent(q)}`
        : '/api/admin/dashboard';
      const d = await adminFetch<AdminDashboardData>(url);
      syncForms(d);
    },
    [adminFetch]
  );

  useEffect(() => {
    if (token) {
      loadDashboard(searchQuery).catch((err) =>
        setBanner({ type: 'err', text: (err as Error).message })
      );
    }
  }, [token, loadDashboard, searchQuery]);

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthBusy(true);
    try {
      const endpoint = authStatus?.needsSetup ? '/api/admin/bootstrap' : '/api/admin/login';
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'X-Requested-With': 'bellgram-admin',
      };
      const initData = getTelegramInitData();
      if (initData) {
        headers['X-Telegram-Init-Data'] = initData;
      }
      const resp = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({ password }),
      });
      const json = await resp.json().catch(() => ({}));
      if (!resp.ok) {
        throw new Error((json as { error?: string }).error || 'Authentication failed');
      }
      setToken((json as { token: string }).token);
      setPassword('');
      setAuthStatus((prev) => (prev ? { ...prev, needsSetup: false } : prev));
    } catch (err) {
      setAuthError((err as Error).message);
    } finally {
      setAuthBusy(false);
    }
  };

  const openBalanceModal = (u: AdminUserSummary) => {
    setEditingUser(u);
    setBalanceMode('set');
    setBalanceAmount(microToBell(u.balance_micro).toFixed(4));
    setBalanceReason('');
  };

  const handleBalanceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setBalanceBusy(true);
    try {
      const qParam = searchQuery.trim() ? `?q=${encodeURIComponent(searchQuery.trim())}` : '';
      const updated = await adminFetch<AdminDashboardData>(
        `/api/admin/users/${editingUser.id}/balance${qParam}`,
        {
          method: 'POST',
          body: JSON.stringify({
            mode: balanceMode,
            amountBell: Number(balanceAmount),
            reason: balanceReason.trim() || undefined,
          }),
        }
      );
      syncForms(updated);
      await onRefreshApp();
      setBanner({
        type: 'ok',
        text: `Updated balance for ${editingUser.first_name} (${editingUser.telegram_id}).`,
      });
      setEditingUser(null);
    } catch (err) {
      setBanner({ type: 'err', text: (err as Error).message });
    } finally {
      setBalanceBusy(false);
    }
  };

  const toggleUserBan = async (u: AdminUserSummary) => {
    try {
      const qParam = searchQuery.trim() ? `?q=${encodeURIComponent(searchQuery.trim())}` : '';
      const updated = await adminFetch<AdminDashboardData>(
        `/api/admin/users/${u.id}/ban${qParam}`,
        {
          method: 'POST',
          body: JSON.stringify({ isBanned: !u.is_banned }),
        }
      );
      syncForms(updated);
      setBanner({
        type: 'ok',
        text: `User ${u.telegram_id} ${u.is_banned ? 're-enabled' : 'disabled'}.`,
      });
    } catch (err) {
      setBanner({ type: 'err', text: (err as Error).message });
    }
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);
    if (newPasswordInput.trim().length < 8) {
      setPasswordError('New password must be at least 8 characters.');
      return;
    }
    if (newPasswordInput !== confirmPasswordInput) {
      setPasswordError('New password and confirmation do not match.');
      return;
    }
    setPasswordBusy(true);
    try {
      await adminFetch<{ ok: boolean }>('/api/admin/password', {
        method: 'POST',
        body: JSON.stringify({
          currentPassword: currentPasswordInput,
          newPassword: newPasswordInput,
        }),
      });
      setShowPasswordModal(false);
      setCurrentPasswordInput('');
      setNewPasswordInput('');
      setConfirmPasswordInput('');
      setBanner({ type: 'ok', text: 'Admin password updated successfully.' });
    } catch (err) {
      setPasswordError((err as Error).message);
    } finally {
      setPasswordBusy(false);
    }
  };

  const handleExportFile = async (
    endpoint: string,
    defaultFilename: string,
    successMessage: string
  ) => {
    if (!token) return;
    try {
      const headers: Record<string, string> = { Authorization: `Bearer ${token}` };
      const initData = getTelegramInitData();
      if (initData) headers['X-Telegram-Init-Data'] = initData;
      const resp = await fetch(endpoint, { headers });
      if (!resp.ok) throw new Error('Export failed');
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = defaultFilename;
      a.click();
      URL.revokeObjectURL(url);
      setBanner({ type: 'ok', text: successMessage });
    } catch (err) {
      setBanner({ type: 'err', text: (err as Error).message });
    }
  };

  const handleExportCsv = () =>
    handleExportFile('/api/admin/export/csv', 'bellgram-users-report.csv', 'Users CSV report exported.');

  const handleExportFullJson = () =>
    handleExportFile(
      '/api/admin/export/json',
      `bellgram-full-backup-${new Date().toISOString().slice(0, 10)}.json`,
      'Full database JSON backup exported (users, missions, referrals, wallets, withdrawals, transactions).'
    );

  const handleExportSqlite = () =>
    handleExportFile(
      '/api/admin/export/sqlite',
      `bellgram-backup-${new Date().toISOString().slice(0, 10)}.db`,
      'SQLite database (.db) snapshot downloaded.'
    );

  if (!token) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4 py-10">
        <div className="w-full max-w-md bell-card rounded-3xl p-6 space-y-5">
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={onExitAdmin}
              className="min-h-[40px] inline-flex items-center gap-1.5 text-xs text-emerald-200/80 hover:text-white cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
              <span>Back to Mini App</span>
            </button>
            <ShieldCheck className="w-6 h-6 text-emerald-400" />
          </div>

          <div>
            <h1 className="font-display text-2xl font-bold text-white">
              {authStatus?.needsSetup ? 'Claim Admin Access' : 'BELLGRAM Admin Console'}
            </h1>
            <p className="text-xs text-emerald-100/65 mt-1 leading-relaxed">
              {authStatus?.needsSetup
                ? 'First-run setup: create a strong admin password (min 8 chars) to lock and protect this console.'
                : authStatus?.envOverrideActive
                ? 'Enter the ADMIN_PASSCODE configured in your server environment.'
                : 'Enter your administrator password to manage mining parameters, users, and audit logs.'}
            </p>
          </div>

          <form onSubmit={handleAuthSubmit} className="space-y-4">
            <div>
              <label htmlFor="admin-password" className="block text-xs font-medium text-emerald-100/80 mb-1.5">
                {authStatus?.needsSetup ? 'New Admin Password' : 'Admin Password'}
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-emerald-400/70 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="admin-password"
                  type="password"
                  required
                  minLength={authStatus?.needsSetup ? 8 : 1}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full min-h-[46px] pl-10 pr-4 rounded-xl bg-black/50 border border-emerald-400/25 text-sm text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
            </div>

            {authError && (
              <div role="alert" className="text-xs text-rose-300 bg-rose-500/10 border border-rose-400/30 rounded-xl px-3 py-2">
                {authError}
              </div>
            )}

            <button
              type="submit"
              disabled={authBusy}
              className="w-full min-h-[48px] rounded-2xl bell-cta-emerald font-semibold text-sm cursor-pointer disabled:opacity-60"
            >
              {authBusy
                ? 'Authenticating...'
                : authStatus?.needsSetup
                ? 'Claim & Sign In'
                : 'Sign In to Admin'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div dir="ltr" className="min-h-screen max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Admin Header */}
      <header className="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-400/15 pb-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onExitAdmin}
            className="min-h-[40px] px-3 rounded-xl bg-emerald-950/80 border border-emerald-400/20 text-xs font-medium text-emerald-100 hover:border-emerald-400/40 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Mini App</span>
          </button>
          <h1 className="font-display text-2xl font-bold text-white">BELLGRAM Admin</h1>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleExportFullJson}
            data-testid="admin-export-json"
            className="min-h-[40px] px-3.5 rounded-xl bell-cta-emerald text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <Download className="w-4 h-4 shrink-0" />
            <span>Full DB (JSON)</span>
          </button>
          <button
            type="button"
            onClick={handleExportSqlite}
            data-testid="admin-export-sqlite"
            className="min-h-[40px] px-3.5 rounded-xl bg-emerald-950/80 border border-emerald-400/25 text-xs font-semibold text-emerald-100 hover:border-emerald-400/45 inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <Download className="w-4 h-4 shrink-0" />
            <span>SQLite (.db)</span>
          </button>
          <button
            type="button"
            onClick={handleExportCsv}
            data-testid="admin-export-csv"
            className="min-h-[40px] px-3.5 rounded-xl bg-emerald-950/80 border border-emerald-400/20 text-xs font-semibold text-emerald-100 hover:border-emerald-400/45 inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <Download className="w-4 h-4 shrink-0" />
            <span>Users CSV</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setPasswordError(null);
              setCurrentPasswordInput('');
              setNewPasswordInput('');
              setConfirmPasswordInput('');
              setShowPasswordModal(true);
            }}
            className="min-h-[40px] px-3 rounded-xl bg-emerald-950/80 border border-emerald-400/20 text-xs font-medium text-emerald-100 hover:border-emerald-400/40 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <KeyRound className="w-4 h-4 text-emerald-300" />
            <span>Password</span>
          </button>
          <button
            type="button"
            onClick={() => setToken(null)}
            className="min-h-[40px] px-3 rounded-xl bg-emerald-950/80 border border-emerald-400/20 text-xs font-medium text-emerald-100 hover:border-rose-400/40 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Lock</span>
          </button>
        </div>
      </header>

      {banner && (
        <div
          role="status"
          className={`rounded-2xl px-4 py-3 text-xs font-medium border ${
            banner.type === 'ok'
              ? 'bg-emerald-500/15 border-emerald-400/35 text-emerald-100'
              : 'bg-rose-500/15 border-rose-400/35 text-rose-100'
          }`}
        >
          {banner.text}
        </div>
      )}

      {/* KPI Cards */}
      {data && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { label: 'Total Users', val: data.stats.totalUsers.toLocaleString('en-US') },
            { label: 'Active (24h)', val: data.stats.activeUsers24h.toLocaleString('en-US') },
            { label: 'Total BELL', val: data.stats.totalBellDistributed.toFixed(2) },
            { label: 'Total Mined', val: data.stats.totalMiningRewards.toFixed(2) },
            { label: 'Referrals', val: data.stats.totalReferrals.toLocaleString('en-US') },
            { label: 'Similar IPs', val: String(data.stats.similarIpGroupsCount ?? 0) },
          ].map((kpi) => (
            <div key={kpi.label} className="bell-card rounded-2xl p-4">
              <div className="text-xs text-emerald-100/60">{kpi.label}</div>
              <div className="font-num text-2xl font-bold text-white mt-1">{kpi.val}</div>
            </div>
          ))}
        </div>
      )}

      {/* Admin Navigation Tabs */}
      <nav className="flex flex-wrap items-center gap-2">
        {(
          [
            ['users', 'Users & Search'],
            [
              'similarIps',
              `Similar IPs${
                data?.stats.similarIpGroupsCount
                  ? ` (${data.stats.similarIpGroupsCount})`
                  : ''
              }`,
            ],
            [
              'withdrawals',
              `Withdrawals${
                data?.stats.pendingWithdrawalsCount
                  ? ` (${data.stats.pendingWithdrawalsCount})`
                  : ''
              }`,
            ],
            ['mining', 'Mining, Levels & Daily'],
            ['channels', 'Channels & Missions'],
            ['logs', 'Transactions & Audit'],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`min-h-[42px] px-4 rounded-xl text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              tab === id
                ? 'bg-emerald-400 text-[#031a0f]'
                : 'bg-emerald-950/70 border border-emerald-400/20 text-emerald-100/80 hover:text-white'
            }`}
          >
            {label}
          </button>
        ))}
      </nav>

      {/* Tab 1: Users */}
      {tab === 'users' && data && (() => {
        const exactDuplicateIps = new Set(
          (data.similarIps || [])
            .filter((g) => g.matchType === 'exact')
            .map((g) => g.key)
        );
        return (
          <section className="bell-card rounded-3xl p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="font-display text-xl font-bold text-white">Users Directory</h2>
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 text-emerald-300/60 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="search"
                  aria-label="Search users"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search ID, username, name, or IP..."
                  className="w-full min-h-[40px] pl-9 pr-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-emerald-400/15 text-emerald-100/60">
                  <tr>
                    <th className="py-2.5 pr-3">Telegram ID</th>
                    <th className="py-2.5 pr-3">User</th>
                    <th className="py-2.5 pr-3 text-right">Balance</th>
                    <th className="py-2.5 pr-3 text-right">Mined</th>
                    <th className="py-2.5 pr-3">Level</th>
                    <th className="py-2.5 pr-3">IP Address</th>
                    <th className="py-2.5 pr-3">Status</th>
                    <th className="py-2.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-emerald-400/10">
                  {data.users.map((u) => {
                    const isSharedIp = Boolean(u.last_ip && exactDuplicateIps.has(u.last_ip));
                    return (
                      <tr key={u.id} className="hover:bg-emerald-950/40">
                        <td className="py-2.5 pr-3 font-num text-emerald-200">{u.telegram_id}</td>
                        <td className="py-2.5 pr-3">
                          <span className="font-medium text-white">{u.first_name}</span>
                          {u.username && <span className="text-emerald-100/50 ml-1">@{u.username}</span>}
                        </td>
                        <td className="py-2.5 pr-3 text-right font-num text-white">
                          {formatBell(u.balance_micro)}
                        </td>
                        <td className="py-2.5 pr-3 text-right font-num text-emerald-300">
                          {formatBell(u.total_mined_micro)}
                        </td>
                        <td className="py-2.5 pr-3 font-num">Lv.{u.level_id}</td>
                        <td className="py-2.5 pr-3">
                          {u.last_ip ? (
                            <div className="inline-flex items-center gap-1.5">
                              <span className="font-mono text-[11px] text-emerald-100/85">
                                {u.last_ip}
                              </span>
                              {isSharedIp && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setIpMatchFilter('exact');
                                    setIpSearchQuery(u.last_ip || '');
                                    setTab('similarIps');
                                  }}
                                  className="px-1.5 py-0.5 rounded bg-amber-500/20 border border-amber-400/35 text-[10px] font-semibold text-amber-200 hover:bg-amber-500/30 cursor-pointer"
                                >
                                  Shared
                                </button>
                              )}
                            </div>
                          ) : (
                            <span className="text-emerald-100/35">—</span>
                          )}
                        </td>
                        <td className="py-2.5 pr-3">
                          {u.is_banned ? (
                            <span className="text-rose-400 font-semibold">Disabled</span>
                          ) : (
                            <span className="text-emerald-400 font-semibold">Active</span>
                          )}
                        </td>
                        <td className="py-2.5 text-right">
                          <div className="inline-flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              aria-label={`Edit balance for ${u.first_name}`}
                              onClick={() => openBalanceModal(u)}
                              className="min-h-[34px] px-2.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1 bg-amber-500/15 text-amber-200 border border-amber-400/30 hover:bg-amber-500/25 cursor-pointer"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                              <span>Balance</span>
                            </button>
                            <button
                              type="button"
                              aria-label={`${u.is_banned ? 'Enable' : 'Disable'} ${u.first_name}`}
                              onClick={() => toggleUserBan(u)}
                              className={`min-h-[34px] px-2.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1 cursor-pointer ${
                                u.is_banned
                                  ? 'bg-emerald-500/20 text-emerald-200 border border-emerald-400/30'
                                  : 'bg-rose-500/15 text-rose-200 border border-rose-400/30'
                              }`}
                            >
                              {u.is_banned ? (
                                <CheckCircle2 className="w-3.5 h-3.5" />
                              ) : (
                                <Ban className="w-3.5 h-3.5" />
                              )}
                              <span>{u.is_banned ? 'Enable' : 'Disable'}</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>
        );
      })()}

      {/* Tab 1.2: Similar & Duplicate IPs */}
      {tab === 'similarIps' && data && (() => {
        const q = ipSearchQuery.trim().toLowerCase();
        const filteredGroups = (data.similarIps || []).filter((g) => {
          if (ipMatchFilter !== 'all' && g.matchType !== ipMatchFilter) return false;
          if (!q) return true;
          if (g.key.toLowerCase().includes(q)) return true;
          return g.accounts.some(
            (a) =>
              a.telegram_id.toLowerCase().includes(q) ||
              (a.username || '').toLowerCase().includes(q) ||
              a.first_name.toLowerCase().includes(q) ||
              a.matched_ip.toLowerCase().includes(q)
          );
        });

        return (
          <section className="bell-card rounded-3xl p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Network className="w-5 h-5 text-amber-300" />
                <div>
                  <h2 className="font-display text-xl font-bold text-white">Similar & Shared IPs</h2>
                  <p className="text-[11px] text-emerald-100/60">
                    Accounts sharing an identical IP address or the same /24 (/64) network subnet.
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1.5">
                  {(
                    [
                      ['all', 'All'],
                      ['exact', 'Exact IP'],
                      ['subnet', 'Same Subnet'],
                    ] as const
                  ).map(([id, label]) => (
                    <button
                      key={id}
                      type="button"
                      onClick={() => setIpMatchFilter(id)}
                      className={`min-h-[34px] px-3 rounded-lg text-xs font-semibold cursor-pointer ${
                        ipMatchFilter === id
                          ? 'bg-emerald-400 text-[#031a0f]'
                          : 'bg-black/45 border border-emerald-400/20 text-emerald-100/75 hover:text-white'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>

                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 text-emerald-300/60 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="search"
                    aria-label="Filter similar IPs"
                    value={ipSearchQuery}
                    onChange={(e) => setIpSearchQuery(e.target.value)}
                    placeholder="Filter IP, subnet, or user..."
                    className="w-full min-h-[36px] pl-9 pr-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white focus:outline-none focus:border-emerald-400"
                  />
                </div>
              </div>
            </div>

            {filteredGroups.length === 0 ? (
              <div className="rounded-2xl bg-black/35 border border-emerald-400/15 p-6 text-center text-xs text-emerald-100/60">
                No matching or similar IP clusters detected for this filter.
              </div>
            ) : (
              <div className="space-y-4">
                {filteredGroups.map((group) => (
                  <div
                    key={`${group.matchType}:${group.key}`}
                    className="rounded-2xl bg-black/40 border border-emerald-400/15 p-4 space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-400/10 pb-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <ShieldAlert
                          className={`w-4 h-4 ${
                            group.matchType === 'exact' ? 'text-rose-400' : 'text-amber-300'
                          }`}
                        />
                        <span className="font-mono text-sm font-bold text-white">{group.key}</span>
                        <span
                          className={`px-2 py-0.5 rounded-md text-[11px] font-semibold border ${
                            group.matchType === 'exact'
                              ? 'bg-rose-500/15 text-rose-200 border-rose-400/30'
                              : 'bg-amber-500/15 text-amber-200 border-amber-400/30'
                          }`}
                        >
                          {group.matchType === 'exact' ? 'Exact IP Match' : 'Same Subnet'}
                        </span>
                        <button
                          type="button"
                          aria-label={`Copy IP ${group.key}`}
                          onClick={() => {
                            navigator.clipboard?.writeText(group.key).catch(() => {});
                            setBanner({ type: 'ok', text: `Copied ${group.key}.` });
                          }}
                          className="min-h-[28px] px-2 rounded-lg bg-emerald-950/80 border border-emerald-400/20 text-[11px] text-emerald-200 hover:text-white inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </button>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-[11px] text-emerald-100/70 font-num">
                        <span>{group.userCount} accounts</span>
                        {group.bannedCount > 0 && (
                          <span className="text-rose-300">{group.bannedCount} disabled</span>
                        )}
                        <span>Combined: {formatBell(group.totalBalanceMicro)} BELL</span>
                      </div>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="text-emerald-100/55 border-b border-emerald-400/10">
                          <tr>
                            <th className="py-2 pr-3">Telegram ID</th>
                            <th className="py-2 pr-3">User</th>
                            <th className="py-2 pr-3">Matched IP</th>
                            <th className="py-2 pr-3 text-right">Hits</th>
                            <th className="py-2 pr-3 text-right">Balance</th>
                            <th className="py-2 pr-3">Last Seen</th>
                            <th className="py-2 pr-3">Status</th>
                            <th className="py-2 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-emerald-400/10">
                          {group.accounts.map((acc) => (
                            <tr key={`${group.key}-${acc.id}-${acc.matched_ip}`} className="hover:bg-emerald-950/35">
                              <td className="py-2 pr-3 font-num text-emerald-200">
                                {acc.telegram_id}
                              </td>
                              <td className="py-2 pr-3">
                                <span className="font-medium text-white">{acc.first_name}</span>
                                {acc.username && (
                                  <span className="text-emerald-100/50 ml-1">@{acc.username}</span>
                                )}
                              </td>
                              <td className="py-2 pr-3 font-mono text-[11px] text-emerald-100/85">
                                {acc.matched_ip}
                              </td>
                              <td className="py-2 pr-3 text-right font-num text-emerald-100/75">
                                {acc.hit_count}
                              </td>
                              <td className="py-2 pr-3 text-right font-num text-white">
                                {formatBell(acc.balance_micro)}
                              </td>
                              <td className="py-2 pr-3 font-num text-[11px] text-emerald-100/60">
                                {new Date(acc.last_seen_at).toLocaleString()}
                              </td>
                              <td className="py-2 pr-3">
                                {acc.is_banned ? (
                                  <span className="text-rose-400 font-semibold">Disabled</span>
                                ) : (
                                  <span className="text-emerald-400 font-semibold">Active</span>
                                )}
                              </td>
                              <td className="py-2 text-right">
                                <div className="inline-flex items-center justify-end gap-1.5">
                                  <button
                                    type="button"
                                    aria-label={`Edit balance for ${acc.first_name} (${acc.telegram_id})`}
                                    onClick={() => openBalanceModal(acc)}
                                    className="min-h-[32px] px-2.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1 bg-amber-500/15 text-amber-200 border border-amber-400/30 hover:bg-amber-500/25 cursor-pointer"
                                  >
                                    <Pencil className="w-3 h-3" />
                                    <span>Balance</span>
                                  </button>
                                  <button
                                    type="button"
                                    aria-label={`${acc.is_banned ? 'Enable' : 'Disable'} ${acc.first_name} (${acc.telegram_id})`}
                                    onClick={() => toggleUserBan(acc)}
                                    className={`min-h-[32px] px-2.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1 cursor-pointer ${
                                      acc.is_banned
                                        ? 'bg-emerald-500/20 text-emerald-200 border border-emerald-400/30'
                                        : 'bg-rose-500/15 text-rose-200 border border-rose-400/30'
                                    }`}
                                  >
                                    {acc.is_banned ? (
                                      <CheckCircle2 className="w-3 h-3" />
                                    ) : (
                                      <Ban className="w-3 h-3" />
                                    )}
                                    <span>{acc.is_banned ? 'Enable' : 'Disable'}</span>
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        );
      })()}

      {/* Tab 1.5: Withdrawals */}
      {tab === 'withdrawals' && data && (
        <section className="bell-card rounded-3xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <ArrowUpRight className="w-5 h-5 text-emerald-400" />
              <h2 className="font-display text-xl font-bold text-white">Withdrawal Requests</h2>
            </div>
            <div className="flex items-center gap-1.5">
              {(['pending', 'completed', 'rejected', 'all'] as const).map((filter) => (
                <button
                  key={filter}
                  type="button"
                  onClick={() => setWithdrawFilter(filter)}
                  className={`min-h-[34px] px-3 rounded-lg text-xs font-semibold capitalize cursor-pointer ${
                    withdrawFilter === filter
                      ? 'bg-emerald-400 text-[#031a0f]'
                      : 'bg-black/45 border border-emerald-400/20 text-emerald-100/75 hover:text-white'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          {data.withdrawals.filter((w) => withdrawFilter === 'all' || w.status === withdrawFilter).length ===
          0 ? (
            <p className="text-xs text-emerald-100/55 py-4">
              No withdrawal requests matching "{withdrawFilter}".
            </p>
          ) : (
            <div className="space-y-3">
              {data.withdrawals
                .filter((w) => withdrawFilter === 'all' || w.status === withdrawFilter)
                .map((w) => (
                  <div
                    key={w.id}
                    className="rounded-2xl bg-black/40 border border-emerald-400/15 p-4 space-y-3 text-xs"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="space-y-0.5">
                        <div className="font-semibold text-white">
                          #{w.id} · {w.first_name}{' '}
                          {w.username ? (
                            <span className="text-emerald-300">@{w.username}</span>
                          ) : null}{' '}
                          <span className="font-num text-emerald-100/55">({w.telegram_id})</span>
                        </div>
                        <div className="text-[11px] text-emerald-100/50 font-num">
                          Requested: {new Date(w.created_at).toLocaleString()}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="font-num text-base font-bold text-white">
                          {formatBell(w.amount_micro)} BELL
                        </span>
                        <span
                          className={`px-2.5 py-1 rounded-full text-[11px] font-semibold capitalize border ${
                            w.status === 'completed'
                              ? 'bg-emerald-500/15 text-emerald-300 border-emerald-400/30'
                              : w.status === 'rejected'
                              ? 'bg-rose-500/15 text-rose-300 border-rose-400/30'
                              : 'bg-amber-500/15 text-amber-200 border-amber-400/30'
                          }`}
                        >
                          {w.status}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-black/40 border border-emerald-400/10 px-3 py-2">
                      <span className="font-mono text-[11px] text-emerald-100 break-all">
                        {w.ton_address}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard?.writeText(w.ton_address).catch(() => {});
                          setBanner({ type: 'ok', text: `Copied TON address for #${w.id}.` });
                        }}
                        className="min-h-[30px] px-2.5 rounded-lg bg-emerald-950 border border-emerald-400/20 text-emerald-200 hover:text-white inline-flex items-center gap-1 cursor-pointer shrink-0"
                      >
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </button>
                    </div>

                    {w.status === 'pending' && (
                      <div className="space-y-2.5 pt-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <input
                            type="text"
                            placeholder="Optional TX Hash / Note (for Completed)"
                            value={txHashes[w.id] || ''}
                            onChange={(e) =>
                              setTxHashes({ ...txHashes, [w.id]: e.target.value })
                            }
                            className="flex-1 min-w-[200px] min-h-[38px] px-3 rounded-xl bg-black/50 border border-emerald-400/20 text-xs font-mono text-white"
                          />
                          <button
                            type="button"
                            disabled={reviewBusyId === w.id}
                            onClick={async () => {
                              setReviewBusyId(w.id);
                              try {
                                const resp = await adminFetch<{
                                  review: { notifiedTelegram: boolean };
                                  dashboard: AdminDashboardData;
                                }>(`/api/admin/withdrawals/${w.id}/review`, {
                                  method: 'POST',
                                  body: JSON.stringify({
                                    decision: 'completed',
                                    txHash: txHashes[w.id] || undefined,
                                  }),
                                });
                                syncForms(resp.dashboard);
                                await onRefreshApp();
                                setBanner({
                                  type: 'ok',
                                  text: `Withdrawal #${w.id} marked Completed.${
                                    resp.review.notifiedTelegram
                                      ? ' User notified on Telegram.'
                                      : ' User sees update in Mini App.'
                                  }`,
                                });
                              } catch (err) {
                                setBanner({ type: 'err', text: (err as Error).message });
                              } finally {
                                setReviewBusyId(null);
                              }
                            }}
                            className="min-h-[38px] px-4 rounded-xl bell-cta-emerald text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-60"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Mark Completed</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setRejectingId(rejectingId === w.id ? null : w.id);
                              setRejectReason('');
                            }}
                            className="min-h-[38px] px-4 rounded-xl bg-rose-500/15 border border-rose-400/35 text-rose-200 hover:bg-rose-500/25 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>

                        {rejectingId === w.id && (
                          <form
                            onSubmit={async (e) => {
                              e.preventDefault();
                              setReviewBusyId(w.id);
                              try {
                                const resp = await adminFetch<{
                                  review: { notifiedTelegram: boolean };
                                  dashboard: AdminDashboardData;
                                }>(`/api/admin/withdrawals/${w.id}/review`, {
                                  method: 'POST',
                                  body: JSON.stringify({
                                    decision: 'rejected',
                                    reason: rejectReason,
                                  }),
                                });
                                syncForms(resp.dashboard);
                                setRejectingId(null);
                                setRejectReason('');
                                await onRefreshApp();
                                setBanner({
                                  type: 'ok',
                                  text: `Withdrawal #${w.id} rejected with reason & refunded.${
                                    resp.review.notifiedTelegram
                                      ? ' User notified on Telegram.'
                                      : ' User sees reason in Mini App.'
                                  }`,
                                });
                              } catch (err) {
                                setBanner({ type: 'err', text: (err as Error).message });
                              } finally {
                                setReviewBusyId(null);
                              }
                            }}
                            className="flex flex-wrap items-center gap-2 rounded-xl bg-rose-950/30 border border-rose-400/25 p-2.5"
                          >
                            <input
                              type="text"
                              required
                              minLength={2}
                              placeholder="Enter rejection reason (sent to user)..."
                              value={rejectReason}
                              onChange={(e) => setRejectReason(e.target.value)}
                              className="flex-1 min-w-[220px] min-h-[36px] px-3 rounded-lg bg-black/50 border border-rose-400/30 text-xs text-white"
                            />
                            <button
                              type="submit"
                              disabled={reviewBusyId === w.id}
                              className="min-h-[36px] px-4 rounded-lg bg-rose-500 text-white text-xs font-semibold cursor-pointer disabled:opacity-60"
                            >
                              Confirm Reject & Refund
                            </button>
                          </form>
                        )}
                      </div>
                    )}

                    {w.status === 'rejected' && w.rejection_reason && (
                      <div className="text-[11px] text-rose-200">
                        <span className="font-semibold">Rejection reason:</span> {w.rejection_reason}
                      </div>
                    )}
                    {w.status === 'completed' && w.tx_hash && (
                      <div className="text-[11px] text-emerald-300 font-mono break-all">
                        TX: {w.tx_hash}
                      </div>
                    )}
                  </div>
                ))}
            </div>
          )}
        </section>
      )}

      {/* Tab 2: Mining, Levels & Daily Rewards */}
      {tab === 'mining' && data && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <section className="bell-card rounded-3xl p-5 space-y-4">
            <h2 className="font-display text-xl font-bold text-white">Mining Levels</h2>
            <div className="space-y-2.5">
              {levelsForm.map((lvl, idx) => (
                <div key={lvl.level} className="grid grid-cols-3 gap-2 items-center">
                  <input
                    type="text"
                    value={lvl.name}
                    aria-label={`Level ${lvl.level} name`}
                    onChange={(e) => {
                      const next = [...levelsForm];
                      next[idx] = { ...lvl, name: e.target.value };
                      setLevelsForm(next);
                    }}
                    className="min-h-[40px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                  />
                  <input
                    type="number"
                    min={0}
                    value={lvl.minBellgram}
                    aria-label={`Level ${lvl.level} min BELLGRAM`}
                    onChange={(e) => {
                      const next = [...levelsForm];
                      next[idx] = { ...lvl, minBellgram: Number(e.target.value) };
                      setLevelsForm(next);
                    }}
                    className="min-h-[40px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs font-num text-white"
                  />
                  <input
                    type="number"
                    min={1}
                    value={lvl.dailyBell}
                    aria-label={`Level ${lvl.level} daily BELL`}
                    onChange={(e) => {
                      const next = [...levelsForm];
                      next[idx] = { ...lvl, dailyBell: Number(e.target.value) };
                      setLevelsForm(next);
                    }}
                    className="min-h-[40px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs font-num text-white"
                  />
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={async () => {
                try {
                  const updated = await adminFetch<AdminDashboardData>('/api/admin/levels', {
                    method: 'PUT',
                    body: JSON.stringify({ levels: levelsForm }),
                  });
                  syncForms(updated);
                  await onRefreshApp();
                  setBanner({ type: 'ok', text: 'Mining levels saved.' });
                } catch (err) {
                  setBanner({ type: 'err', text: (err as Error).message });
                }
              }}
              className="min-h-[44px] px-5 rounded-xl bell-cta-emerald text-xs font-semibold cursor-pointer"
            >
              Save Levels
            </button>
          </section>

          <section className="bell-card rounded-3xl p-5 space-y-5">
            <div>
              <h2 className="font-display text-xl font-bold text-white mb-3">
                Daily Login Schedule (Days 1–7)
              </h2>
              <div className="grid grid-cols-7 gap-2">
                {dailyForm.map((val, idx) => (
                  <div key={idx}>
                    <label className="block text-[10px] text-emerald-100/60 mb-1">
                      D{idx + 1}
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={val}
                      onChange={(e) => {
                        const next = [...dailyForm];
                        next[idx] = Number(e.target.value);
                        setDailyForm(next);
                      }}
                      className="w-full min-h-[40px] px-2 rounded-xl bg-black/45 border border-emerald-400/20 text-xs font-num text-white text-center"
                    />
                  </div>
                ))}
              </div>
              <button
                type="button"
                onClick={async () => {
                  try {
                    const updated = await adminFetch<AdminDashboardData>(
                      '/api/admin/daily-rewards',
                      {
                        method: 'PUT',
                        body: JSON.stringify({ schedule: dailyForm }),
                      }
                    );
                    syncForms(updated);
                    await onRefreshApp();
                    setBanner({ type: 'ok', text: 'Daily login rewards updated.' });
                  } catch (err) {
                    setBanner({ type: 'err', text: (err as Error).message });
                  }
                }}
                className="mt-3 min-h-[42px] px-4 rounded-xl bell-cta-gold text-xs font-semibold cursor-pointer"
              >
                Save Daily Rewards
              </button>
            </div>

            <div className="border-t border-emerald-400/15 pt-4 space-y-3">
              <h3 className="font-semibold text-sm text-white">Mining & Referral Rules</h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-emerald-100/60 mb-1">
                    Referral Bonus (BELL)
                  </label>
                  <input
                    type="number"
                    value={generalForm.referralBonusBell}
                    onChange={(e) =>
                      setGeneralForm({ ...generalForm, referralBonusBell: Number(e.target.value) })
                    }
                    className="w-full min-h-[40px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs font-num text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-emerald-100/60 mb-1">
                    Session Duration (Hours)
                  </label>
                  <input
                    type="number"
                    value={generalForm.sessionDurationHours}
                    onChange={(e) =>
                      setGeneralForm({
                        ...generalForm,
                        sessionDurationHours: Number(e.target.value),
                      })
                    }
                    className="w-full min-h-[40px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs font-num text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-emerald-100/60 mb-1">
                    Min Claim (BELL)
                  </label>
                  <input
                    type="number"
                    step="0.0001"
                    value={generalForm.minClaimBell}
                    onChange={(e) =>
                      setGeneralForm({ ...generalForm, minClaimBell: Number(e.target.value) })
                    }
                    className="w-full min-h-[40px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs font-num text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-emerald-100/60 mb-1">
                    Min Withdraw (BELL)
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={generalForm.minWithdrawBell}
                    onChange={(e) =>
                      setGeneralForm({ ...generalForm, minWithdrawBell: Number(e.target.value) })
                    }
                    className="w-full min-h-[40px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs font-num text-white"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-[11px] text-emerald-100/60 mb-1">
                    Bot Username
                  </label>
                  <input
                    type="text"
                    value={generalForm.botUsername}
                    onChange={(e) =>
                      setGeneralForm({ ...generalForm, botUsername: e.target.value })
                    }
                    className="w-full min-h-[40px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                  />
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      const updated = await adminFetch<AdminDashboardData>('/api/admin/settings', {
                        method: 'PUT',
                        body: JSON.stringify(generalForm),
                      });
                      syncForms(updated);
                      await onRefreshApp();
                      setBanner({ type: 'ok', text: 'General settings updated.' });
                    } catch (err) {
                      setBanner({ type: 'err', text: (err as Error).message });
                    }
                  }}
                  className="min-h-[42px] px-4 rounded-xl bell-cta-emerald text-xs font-semibold cursor-pointer"
                >
                  Save General Settings
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      const sync = await adminFetch<{ ok: boolean; message: string }>(
                        '/api/admin/telegram/sync',
                        {
                          method: 'POST',
                          body: JSON.stringify({ appUrl: window.location.origin }),
                        }
                      );
                      setBanner({ type: 'ok', text: sync.message });
                    } catch (err) {
                      setBanner({ type: 'err', text: (err as Error).message });
                    }
                  }}
                  className="min-h-[42px] px-4 rounded-xl bg-emerald-950/80 border border-emerald-400/25 hover:border-emerald-400/50 text-xs font-semibold text-emerald-100 cursor-pointer"
                >
                  Sync Bot Menu & Webhook
                </button>
              </div>
            </div>
          </section>
        </div>
      )}

      {/* Tab 3: Channels & Missions */}
      {tab === 'channels' && data && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <section className="bell-card rounded-3xl p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-display text-xl font-bold text-white">Required Telegram Channels</h2>
              <button
                type="button"
                onClick={() =>
                  setChannelsForm([
                    ...channelsForm,
                    {
                      id: `ch_${Date.now()}`,
                      title: 'New Channel',
                      titleAr: 'قناة جديدة',
                      username: '',
                      url: '',
                      isRequired: true,
                    },
                  ])
                }
                className="min-h-[34px] px-3 rounded-xl bg-emerald-500/15 border border-emerald-400/30 text-xs font-semibold text-emerald-200 inline-flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Channel</span>
              </button>
            </div>
            <p className="text-[11px] text-emerald-100/60 leading-relaxed">
              Add @bellgrammbot as Admin inside each channel below so Telegram allows verifying members. Use @username (or numeric -100... chat ID for private channels).
            </p>
            <div className="space-y-3">
              {channelsForm.map((ch, idx) => (
                <div key={ch.id} className="rounded-2xl bg-black/35 border border-emerald-400/15 p-3 space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={ch.title}
                      placeholder="English Title"
                      onChange={(e) => {
                        const next = [...channelsForm];
                        next[idx] = { ...ch, title: e.target.value };
                        setChannelsForm(next);
                      }}
                      className="min-h-[38px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                    />
                    <input
                      type="text"
                      value={ch.titleAr}
                      placeholder="Arabic Title"
                      onChange={(e) => {
                        const next = [...channelsForm];
                        next[idx] = { ...ch, titleAr: e.target.value };
                        setChannelsForm(next);
                      }}
                      className="min-h-[38px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={ch.username}
                      placeholder="@channel_username or -100..."
                      onChange={(e) => {
                        const val = e.target.value;
                        const cleanNew = val
                          .trim()
                          .replace(/^(?:https?:\/\/)?t\.me\/(?:s\/)?/i, '')
                          .replace(/^@/, '');
                        const cleanOld = ch.username.trim().replace(/^@/, '');
                        const prevAuto = cleanOld ? `https://t.me/${cleanOld}` : '';
                        const shouldAutoSyncUrl =
                          !ch.url.trim() ||
                          ch.url.trim() === 'https://t.me/' ||
                          (prevAuto && ch.url.trim() === prevAuto);
                        const next = [...channelsForm];
                        next[idx] = {
                          ...ch,
                          username: val,
                          url:
                            shouldAutoSyncUrl && cleanNew && !cleanNew.startsWith('-')
                              ? `https://t.me/${cleanNew}`
                              : shouldAutoSyncUrl && !cleanNew
                              ? ''
                              : ch.url,
                        };
                        setChannelsForm(next);
                      }}
                      className="min-h-[38px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                    />
                    <input
                      type="url"
                      value={ch.url}
                      placeholder="https://t.me/channel (auto-filled)"
                      onChange={(e) => {
                        const next = [...channelsForm];
                        next[idx] = { ...ch, url: e.target.value };
                        setChannelsForm(next);
                      }}
                      className="min-h-[38px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                    />
                  </div>
                  <div className="flex items-center justify-between pt-1 text-xs">
                    <label className="inline-flex items-center gap-2 text-emerald-100/80 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={ch.isRequired}
                        onChange={(e) => {
                          const next = [...channelsForm];
                          next[idx] = { ...ch, isRequired: e.target.checked };
                          setChannelsForm(next);
                        }}
                      />
                      <span>Required to mine</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => setChannelsForm(channelsForm.filter((_, i) => i !== idx))}
                      className="text-rose-300 hover:text-rose-200 font-semibold cursor-pointer"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={async () => {
                try {
                  const updated = await adminFetch<AdminDashboardData>('/api/admin/channels', {
                    method: 'PUT',
                    body: JSON.stringify({ channels: channelsForm }),
                  });
                  syncForms(updated);
                  await onRefreshApp();
                  setBanner({ type: 'ok', text: 'Channels updated.' });
                } catch (err) {
                  setBanner({ type: 'err', text: (err as Error).message });
                }
              }}
              className="min-h-[42px] px-4 rounded-xl bell-cta-emerald text-xs font-semibold cursor-pointer"
            >
              Save Channels
            </button>
          </section>

          <section className="bell-card rounded-3xl p-5 space-y-4">
            <h2 className="font-display text-xl font-bold text-white">Missions Management</h2>
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {data.missions.map((m) => (
                <div
                  key={m.id}
                  className="rounded-xl bg-black/35 border border-emerald-400/15 px-3 py-2.5 flex items-center justify-between gap-2 text-xs"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-white truncate">{m.title_en}</span>
                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-semibold ${
                          m.mission_type === 'channel'
                            ? 'bg-sky-500/15 text-sky-300 border border-sky-400/25'
                            : m.mission_type === 'custom'
                            ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-400/25'
                            : 'bg-amber-500/15 text-amber-300 border border-amber-400/25'
                        }`}
                      >
                        {m.mission_type === 'channel'
                          ? 'Telegram Verified'
                          : m.mission_type === 'custom'
                          ? 'External (No Check)'
                          : 'System'}
                      </span>
                    </div>
                    {m.description_en && (
                      <div className="text-[11px] text-emerald-100/60 truncate mt-0.5">
                        {m.description_en}
                      </div>
                    )}
                    <div className="text-emerald-100/55 font-num mt-0.5 truncate">
                      +{m.reward_bell} BELL
                      {m.channel_username ? ` · @${m.channel_username.replace(/^@/, '')}` : ''}
                      {m.channel_url ? ` · ${m.channel_url}` : ''}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          const updated = await adminFetch<AdminDashboardData>(
                            `/api/admin/missions/${m.id}/toggle`,
                            {
                              method: 'POST',
                              body: JSON.stringify({ isActive: !m.is_active }),
                            }
                          );
                          syncForms(updated);
                          await onRefreshApp();
                        } catch (err) {
                          setBanner({ type: 'err', text: (err as Error).message });
                        }
                      }}
                      className={`min-h-[34px] px-3 rounded-lg font-semibold cursor-pointer ${
                        m.is_active
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
                          : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                      }`}
                    >
                      {m.is_active ? 'Active' : 'Disabled'}
                    </button>
                    <button
                      type="button"
                      aria-label={`Delete mission ${m.title_en}`}
                      onClick={async () => {
                        try {
                          const updated = await adminFetch<AdminDashboardData>(
                            `/api/admin/missions/${m.id}`,
                            { method: 'DELETE' }
                          );
                          syncForms(updated);
                          await onRefreshApp();
                          setBanner({ type: 'ok', text: `Deleted mission "${m.title_en}".` });
                        } catch (err) {
                          setBanner({ type: 'err', text: (err as Error).message });
                        }
                      }}
                      className="min-h-[34px] min-w-[34px] px-2 rounded-lg bg-rose-500/15 text-rose-300 border border-rose-400/25 hover:bg-rose-500/25 inline-flex items-center justify-center cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <form
              onSubmit={async (e) => {
                e.preventDefault();
                try {
                  const updated = await adminFetch<AdminDashboardData>('/api/admin/missions', {
                    method: 'POST',
                    body: JSON.stringify(newMission),
                  });
                  syncForms(updated);
                  await onRefreshApp();
                  setNewMission({
                    code: '',
                    titleEn: '',
                    titleAr: '',
                    descriptionEn: '',
                    descriptionAr: '',
                    missionType: newMission.missionType,
                    targetValue: 1,
                    channelUsername: '',
                    channelUrl: '',
                    rewardBell: 25,
                  });
                  setBanner({ type: 'ok', text: 'New mission created.' });
                } catch (err) {
                  setBanner({ type: 'err', text: (err as Error).message });
                }
              }}
              className="border-t border-emerald-400/15 pt-4 space-y-2.5"
            >
              <div className="text-xs font-semibold text-white">Add New Mission</div>

              <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-black/40 border border-emerald-400/20">
                <button
                  type="button"
                  onClick={() =>
                    setNewMission({ ...newMission, missionType: 'channel', channelUsername: '' })
                  }
                  className={`min-h-[36px] px-3 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                    newMission.missionType === 'channel'
                      ? 'bg-sky-400 text-[#031a0f]'
                      : 'text-emerald-100/70 hover:text-white'
                  }`}
                >
                  Telegram Channel (Verified)
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setNewMission({ ...newMission, missionType: 'custom', channelUsername: '' })
                  }
                  className={`min-h-[36px] px-3 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                    newMission.missionType === 'custom'
                      ? 'bg-emerald-400 text-[#031a0f]'
                      : 'text-emerald-100/70 hover:text-white'
                  }`}
                >
                  External Link (No Check)
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  required={!newMission.titleAr.trim()}
                  placeholder="Mission Name (e.g. Join Partner Channel)"
                  value={newMission.titleEn}
                  onChange={(e) => setNewMission({ ...newMission, titleEn: e.target.value })}
                  className="min-h-[38px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                />
                <input
                  type="text"
                  placeholder="Arabic Name (optional, mirrors if empty)"
                  value={newMission.titleAr}
                  onChange={(e) => setNewMission({ ...newMission, titleAr: e.target.value })}
                  className="min-h-[38px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  required={!newMission.descriptionAr.trim()}
                  placeholder="Mission Description"
                  value={newMission.descriptionEn}
                  onChange={(e) => setNewMission({ ...newMission, descriptionEn: e.target.value })}
                  className="min-h-[38px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                />
                <input
                  type="text"
                  placeholder="Arabic Description (optional)"
                  value={newMission.descriptionAr}
                  onChange={(e) => setNewMission({ ...newMission, descriptionAr: e.target.value })}
                  className="min-h-[38px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                />
              </div>

              {newMission.missionType === 'channel' ? (
                <div className="space-y-1.5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="url"
                      required={!newMission.channelUsername.trim()}
                      placeholder="Telegram Channel Link (https://t.me/channel)"
                      value={newMission.channelUrl}
                      onChange={(e) => {
                        const urlVal = e.target.value;
                        const match = urlVal.match(/t\.me\/(?:s\/)?([^/?#+]+)/i);
                        setNewMission({
                          ...newMission,
                          channelUrl: urlVal,
                          channelUsername: match ? match[1] : newMission.channelUsername,
                        });
                      }}
                      className="min-h-[38px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                    />
                    <input
                      type="text"
                      placeholder="@username or -100... Chat ID (auto-filled)"
                      value={newMission.channelUsername}
                      onChange={(e) => {
                        const raw = e.target.value;
                        const clean = raw.trim().replace(/^@/, '');
                        const shouldFillUrl =
                          !newMission.channelUrl.trim() ||
                          newMission.channelUrl.startsWith('https://t.me/');
                        setNewMission({
                          ...newMission,
                          channelUsername: raw,
                          channelUrl:
                            shouldFillUrl && clean && !clean.startsWith('-')
                              ? `https://t.me/${clean}`
                              : newMission.channelUrl,
                        });
                      }}
                      className="min-h-[38px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                    />
                  </div>
                  <p className="text-[11px] text-sky-300/80">
                    Live Telegram verification checks membership via getChatMember. Make @{generalForm.botUsername || 'bellgrammbot'} Admin in the channel.
                  </p>
                </div>
              ) : (
                <div className="space-y-1.5">
                  <input
                    type="url"
                    required
                    placeholder="External Link (https://youtube.com/... or https://x.com/...)"
                    value={newMission.channelUrl}
                    onChange={(e) => setNewMission({ ...newMission, channelUrl: e.target.value })}
                    className="w-full min-h-[38px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                  />
                  <p className="text-[11px] text-emerald-100/55">
                    External tasks open the link and let users claim the BELL reward without Telegram verification.
                  </p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  required
                  min={1}
                  placeholder="Reward BELL"
                  value={newMission.rewardBell}
                  onChange={(e) =>
                    setNewMission({ ...newMission, rewardBell: Number(e.target.value) })
                  }
                  className="min-h-[38px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs font-num text-white"
                />
                <input
                  type="text"
                  placeholder="Code (optional, auto-generated)"
                  value={newMission.code}
                  onChange={(e) => setNewMission({ ...newMission, code: e.target.value })}
                  className="min-h-[38px] px-3 rounded-xl bg-black/45 border border-emerald-400/20 text-xs text-white"
                />
              </div>

              <button
                type="submit"
                className="min-h-[40px] px-4 rounded-xl bell-cta-emerald text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Create Mission</span>
              </button>
            </form>
          </section>
        </div>
      )}

      {/* Tab 4: Transactions & Audit Logs */}
      {tab === 'logs' && data && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <section className="bell-card rounded-3xl p-5 space-y-3">
            <h2 className="font-display text-xl font-bold text-white">Recent Transactions</h2>
            <div className="divide-y divide-emerald-400/10 max-h-96 overflow-y-auto text-xs">
              {data.recentTransactions.map((tx) => (
                <div key={tx.id} className="py-2.5 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="font-medium text-white truncate">
                      {tx.first_name} ({tx.telegram_id}) · {tx.description}
                    </div>
                    <div className="text-[11px] text-emerald-100/50 font-num">
                      {new Date(tx.created_at).toLocaleString()}
                    </div>
                  </div>
                  <div
                    className={`font-num font-semibold shrink-0 ${
                      tx.amount_micro >= 0 ? 'text-emerald-400' : 'text-amber-300'
                    }`}
                  >
                    {tx.amount_micro >= 0 ? '+' : ''}
                    {formatBell(tx.amount_micro)}
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="bell-card rounded-3xl p-5 space-y-3">
            <h2 className="font-display text-xl font-bold text-white">Admin Audit Logs</h2>
            <div className="divide-y divide-emerald-400/10 max-h-96 overflow-y-auto text-xs">
              {data.auditLogs.map((log) => (
                <div key={log.id} className="py-2.5 space-y-0.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-amber-300">{log.action}</span>
                    <span className="font-num text-[11px] text-emerald-100/50">
                      {new Date(log.created_at).toLocaleString()}
                    </span>
                  </div>
                  <div className="text-emerald-100/70">
                    Actor: {log.admin_actor} · Target: {log.target_type}
                    {log.target_id ? ` (${log.target_id})` : ''}
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      )}

      {/* Balance Adjustment Modal */}
      {editingUser && (() => {
        const parsedAmount = Number(balanceAmount);
        const validAmount = Number.isFinite(parsedAmount) && parsedAmount >= 0;
        const deltaMicro = validAmount ? bellToMicro(parsedAmount) : 0;
        const previewMicro =
          balanceMode === 'add'
            ? editingUser.balance_micro + deltaMicro
            : balanceMode === 'subtract'
            ? Math.max(0, editingUser.balance_micro - deltaMicro)
            : deltaMicro;

        return (
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="edit-balance-title"
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
          >
            <div className="w-full max-w-md bell-card rounded-3xl p-6 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-400/30 flex items-center justify-center">
                    <Coins className="w-4 h-4 text-amber-300" />
                  </div>
                  <div>
                    <h3 id="edit-balance-title" className="font-display text-lg font-bold text-white">
                      Edit User Balance
                    </h3>
                    <p className="text-xs text-emerald-100/65">
                      {editingUser.first_name}
                      {editingUser.username ? ` (@${editingUser.username})` : ''} ·{' '}
                      <span className="font-num">{editingUser.telegram_id}</span>
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  aria-label="Close balance editor"
                  onClick={() => setEditingUser(null)}
                  className="min-h-[34px] min-w-[34px] rounded-xl bg-black/40 border border-emerald-400/20 text-emerald-100/70 hover:text-white flex items-center justify-center cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="rounded-2xl bg-black/40 border border-emerald-400/15 px-4 py-3 flex items-center justify-between text-xs">
                <span className="text-emerald-100/65">Current Balance</span>
                <span className="font-num text-sm font-bold text-white">
                  {formatBell(editingUser.balance_micro)} BELL
                </span>
              </div>

              <form onSubmit={handleBalanceSubmit} className="space-y-3.5">
                <div>
                  <span className="block text-[11px] font-medium text-emerald-100/75 mb-1.5">
                    Adjustment Mode
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    {(
                      [
                        ['set', 'Set Exact'],
                        ['add', 'Add (+)'],
                        ['subtract', 'Subtract (-)'],
                      ] as const
                    ).map(([modeId, label]) => (
                      <button
                        key={modeId}
                        type="button"
                        onClick={() => {
                          setBalanceMode(modeId);
                          if (modeId === 'set') {
                            setBalanceAmount(microToBell(editingUser.balance_micro).toFixed(4));
                          } else {
                            setBalanceAmount('');
                          }
                        }}
                        className={`min-h-[38px] rounded-xl text-xs font-semibold cursor-pointer border ${
                          balanceMode === modeId
                            ? 'bg-emerald-400 text-[#031a0f] border-emerald-300'
                            : 'bg-black/45 border-emerald-400/20 text-emerald-100/80 hover:text-white'
                        }`}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="balance-amount-input"
                    className="block text-[11px] font-medium text-emerald-100/75 mb-1"
                  >
                    {balanceMode === 'set'
                      ? 'New Balance (BELL)'
                      : balanceMode === 'add'
                      ? 'Amount to Add (BELL)'
                      : 'Amount to Subtract (BELL)'}
                  </label>
                  <input
                    id="balance-amount-input"
                    type="number"
                    required
                    min={0}
                    step="0.0001"
                    value={balanceAmount}
                    onChange={(e) => setBalanceAmount(e.target.value)}
                    placeholder="e.g. 250.0000"
                    className="w-full min-h-[42px] px-3 rounded-xl bg-black/50 border border-emerald-400/25 text-sm font-num text-white focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div>
                  <label
                    htmlFor="balance-reason-input"
                    className="block text-[11px] font-medium text-emerald-100/75 mb-1"
                  >
                    Reason / Note (Optional)
                  </label>
                  <input
                    id="balance-reason-input"
                    type="text"
                    maxLength={160}
                    value={balanceReason}
                    onChange={(e) => setBalanceReason(e.target.value)}
                    placeholder="e.g. Bonus reward or balance correction"
                    className="w-full min-h-[40px] px-3 rounded-xl bg-black/50 border border-emerald-400/20 text-xs text-white focus:outline-none focus:border-emerald-400"
                  />
                </div>

                <div className="rounded-xl bg-emerald-950/50 border border-emerald-400/20 px-3.5 py-2.5 flex items-center justify-between text-xs">
                  <span className="text-emerald-100/70">Resulting Balance</span>
                  <span className="font-num font-bold text-emerald-300">
                    {formatBell(previewMicro)} BELL
                  </span>
                </div>

                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setEditingUser(null)}
                    className="min-h-[40px] px-4 rounded-xl bg-black/45 border border-emerald-400/20 text-xs font-semibold text-emerald-100/80 hover:text-white cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={balanceBusy}
                    className="min-h-[40px] px-5 rounded-xl bell-cta-emerald text-xs font-semibold cursor-pointer disabled:opacity-60"
                  >
                    {balanceBusy ? 'Saving...' : 'Save Balance'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        );
      })()}

      {/* Change Admin Password Modal */}
      {showPasswordModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="change-password-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
        >
          <div className="w-full max-w-md bell-card rounded-3xl p-6 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-400/30 flex items-center justify-center">
                  <KeyRound className="w-4 h-4 text-emerald-300" />
                </div>
                <div>
                  <h3 id="change-password-title" className="font-display text-lg font-bold text-white">
                    Change Admin Password
                  </h3>
                  <p className="text-xs text-emerald-100/65">
                    Update your console password (minimum 8 characters).
                  </p>
                </div>
              </div>
              <button
                type="button"
                aria-label="Close password modal"
                onClick={() => setShowPasswordModal(false)}
                className="min-h-[34px] min-w-[34px] rounded-xl bg-black/40 border border-emerald-400/20 text-emerald-100/70 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {authStatus?.envOverrideActive ? (
              <div className="rounded-2xl bg-amber-500/10 border border-amber-400/30 p-4 text-xs text-amber-100 leading-relaxed">
                Admin password is currently managed by the{' '}
                <code className="font-mono text-amber-300">ADMIN_PASSCODE</code> environment
                secret. Update it in AI Studio Settings &rarr; Secrets and redeploy.
              </div>
            ) : (
              <form onSubmit={handlePasswordSubmit} className="space-y-3.5">
                <div>
                  <label
                    htmlFor="current-admin-password"
                    className="block text-[11px] font-medium text-emerald-100/75 mb-1"
                  >
                    Current Password
                  </label>
                  <input
                    id="current-admin-password"
                    type="password"
                    required
                    value={currentPasswordInput}
                    onChange={(e) => setCurrentPasswordInput(e.target.value)}
                    className="w-full min-h-[40px] px-3 rounded-xl bg-black/50 border border-emerald-400/25 text-sm text-white focus:outline-none focus:border-emerald-400"
                  />
                </div>
                <div>
                  <label
                    htmlFor="new-admin-password"
                    className="block text-[11px] font-medium text-emerald-100/75 mb-1"
                  >
                    New Password (min 8 chars)
                  </label>
                  <input
                    id="new-admin-password"
                    type="password"
                    required
                    minLength={8}
                    value={newPasswordInput}
                    onChange={(e) => setNewPasswordInput(e.target.value)}
                    className="w-full min-h-[40px] px-3 rounded-xl bg-black/50 border border-emerald-400/25 text-sm text-white focus:outline-none focus:border-emerald-400"
                  />
                </div>
                <div>
                  <label
                    htmlFor="confirm-admin-password"
                    className="block text-[11px] font-medium text-emerald-100/75 mb-1"
                  >
                    Confirm New Password
                  </label>
                  <input
                    id="confirm-admin-password"
                    type="password"
                    required
                    minLength={8}
                    value={confirmPasswordInput}
                    onChange={(e) => setConfirmPasswordInput(e.target.value)}
                    className="w-full min-h-[40px] px-3 rounded-xl bg-black/50 border border-emerald-400/25 text-sm text-white focus:outline-none focus:border-emerald-400"
                  />
                </div>

                {passwordError && (
                  <div
                    role="alert"
                    className="text-xs text-rose-300 bg-rose-500/10 border border-rose-400/30 rounded-xl px-3 py-2"
                  >
                    {passwordError}
                  </div>
                )}

                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowPasswordModal(false)}
                    className="min-h-[40px] px-4 rounded-xl bg-black/45 border border-emerald-400/20 text-xs font-semibold text-emerald-100/80 hover:text-white cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={passwordBusy}
                    className="min-h-[40px] px-5 rounded-xl bell-cta-emerald text-xs font-semibold cursor-pointer disabled:opacity-60"
                  >
                    {passwordBusy ? 'Updating...' : 'Update Password'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
