import React, { useEffect, useMemo, useState } from 'react';
import {
  Box,
  Calendar,
  CheckSquare,
  ChevronRight,
  Database,
  Shield,
  TrendingUp,
  Zap,
} from 'lucide-react';
import { GoldenBellIcon, HeroBannerArtwork } from './BellArtwork.tsx';
import { computeAccruedMicro, formatBell, formatCountdown } from '../lib/bellMath.ts';
import { t } from '../lib/i18n.ts';
import type { BootstrapPayload, Language } from '../types.ts';

interface HomeViewProps {
  data: BootstrapPayload;
  lang: Language;
  onClaimMining: () => Promise<void>;
  onClaimDaily: () => Promise<void>;
  onNavigateWallet: () => void;
  onNavigateMissions: () => void;
}

export function HomeView({
  data,
  lang,
  onClaimMining,
  onClaimDaily,
  onNavigateWallet,
  onNavigateMissions,
}: HomeViewProps) {
  const [nowMs, setNowMs] = useState<number>(() => Date.now());
  const [claimingMining, setClaimingMining] = useState(false);
  const [claimingDaily, setClaimingDaily] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Sync live ticker against server clock offset (never trusts client clock drift)
  const serverOffsetMs = useMemo(
    () => data.mining.serverNowMs - Date.now(),
    [data.mining.serverNowMs]
  );

  useEffect(() => {
    const id = window.setInterval(() => {
      setNowMs(Date.now());
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  const liveMining = useMemo(() => {
    const sessionDurationSec = Math.max(60, Math.round(data.settings.sessionDurationHours * 3600));
    return computeAccruedMicro({
      dailyRateBell: data.mining.dailyRateBell,
      multiplierBps: data.mining.multiplierBps,
      startedAtMs: data.mining.startedAtMs,
      nowMs: nowMs + serverOffsetMs,
      sessionDurationSec,
      alreadyClaimedMicro: data.mining.claimedMicro,
      status: data.mining.status,
    });
  }, [data.mining, data.settings.sessionDurationHours, nowMs, serverOffsetMs]);

  const minClaimMicro = Math.round(data.settings.minClaimBell * 10_000);
  const canClaimMining = liveMining.accruedMicro >= minClaimMicro && !claimingMining;

  const handleClaimMining = async () => {
    setFeedback(null);
    setClaimingMining(true);
    try {
      await onClaimMining();
      setFeedback({
        type: 'ok',
        text:
          lang === 'ar'
            ? 'تمت إضافة مكافأة التعدين إلى رصيدك وبدء جلسة جديدة!'
            : 'Mining reward claimed and new 24h session started!',
      });
    } catch (err) {
      setFeedback({ type: 'err', text: (err as Error).message });
    } finally {
      setClaimingMining(false);
    }
  };

  const handleClaimDaily = async () => {
    setFeedback(null);
    setClaimingDaily(true);
    try {
      await onClaimDaily();
      setFeedback({
        type: 'ok',
        text:
          lang === 'ar'
            ? 'تم استلام المكافأة اليومية بنجاح!'
            : 'Daily login bonus added to your App Balance!',
      });
    } catch (err) {
      setFeedback({ type: 'err', text: (err as Error).message });
    } finally {
      setClaimingDaily(false);
    }
  };

  const availableMissionsCount = data.missions.filter((m) => m.status !== 'Completed').length;
  const bellgramHeldWhole = data.wallet.bellgramBalanceMicro / 10_000;
  const nextLvl = data.user.nextLevel;
  const nextLvlProgress = nextLvl
    ? Math.min(100, (bellgramHeldWhole / Math.max(1, nextLvl.minBellgram)) * 100)
    : 100;

  const latestReviewedWithdrawal = data.withdrawals.find(
    (w) => w.status === 'completed' || w.status === 'rejected'
  );

  return (
    <div className="space-y-4">
      {feedback && (
        <div
          role="status"
          className={`rounded-2xl px-4 py-3 text-xs font-medium border ${
            feedback.type === 'ok'
              ? 'bg-emerald-500/15 border-emerald-400/35 text-emerald-100'
              : 'bg-rose-500/15 border-rose-400/35 text-rose-100'
          }`}
        >
          {feedback.text}
        </div>
      )}

      {latestReviewedWithdrawal && (
        <button
          type="button"
          onClick={onNavigateWallet}
          className={`w-full rounded-2xl px-4 py-3 text-xs font-medium border text-start flex items-center justify-between gap-3 cursor-pointer ${
            latestReviewedWithdrawal.status === 'completed'
              ? 'bg-emerald-500/12 border-emerald-400/30 text-emerald-100'
              : 'bg-rose-500/12 border-rose-400/30 text-rose-100'
          }`}
        >
          <span className="min-w-0">
            {latestReviewedWithdrawal.status === 'completed'
              ? lang === 'ar'
                ? `تم تنفيذ طلب السحب #${latestReviewedWithdrawal.id} (${formatBell(latestReviewedWithdrawal.amountMicro)} BELL) — مكتمل`
                : `Withdrawal #${latestReviewedWithdrawal.id} (${formatBell(latestReviewedWithdrawal.amountMicro)} BELL) — Completed`
              : lang === 'ar'
              ? `تم رفض طلب السحب #${latestReviewedWithdrawal.id} (${formatBell(latestReviewedWithdrawal.amountMicro)} BELL) — السبب: ${latestReviewedWithdrawal.rejectionReason || '-'}`
              : `Withdrawal #${latestReviewedWithdrawal.id} rejected — Reason: ${latestReviewedWithdrawal.rejectionReason || '-'}`}
          </span>
          <ChevronRight className="w-4 h-4 shrink-0 rtl:rotate-180" />
        </button>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Primary Column (Hero + Balance + Mining + Stats) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Hero Banner Card */}
          <div className="relative overflow-hidden rounded-3xl border border-emerald-400/20 h-[152px] flex items-center px-5 sm:px-6 shadow-xl">
            <HeroBannerArtwork />
            <div className="relative z-10 max-w-[66%]">
              <h1 className="font-display text-3xl sm:text-4xl font-bold text-white tracking-tight leading-tight">
                {t(lang, 'heroTitle')}
              </h1>
              <div className="mt-2 inline-flex items-center px-3 py-1 rounded-full bg-black/45 border border-emerald-400/25 text-xs text-emerald-100/90 backdrop-blur-sm">
                {t(lang, 'heroSubtitle')}
              </div>
            </div>
          </div>

          {/* App Balance Summary Bar */}
          <button
            type="button"
            onClick={onNavigateWallet}
            className="w-full bell-card rounded-2xl p-4 flex items-center justify-between gap-4 hover:border-emerald-400/35 transition-colors text-start cursor-pointer min-h-[76px]"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="w-11 h-11 rounded-xl bg-emerald-500/12 border border-emerald-400/25 flex items-center justify-center shrink-0 text-emerald-400">
                <Database className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <div className="text-xs text-emerald-100/60 font-medium">
                  {t(lang, 'appBalance')}
                </div>
                <div className="flex items-baseline gap-2 mt-0.5">
                  <span
                    data-testid="home-app-balance"
                    className="font-num text-2xl font-bold text-white tracking-tight"
                  >
                    {formatBell(data.user.balanceMicro)}
                  </span>
                  <span className="font-display text-sm font-bold text-emerald-400">BELL</span>
                </div>
                <div className="text-xs text-emerald-100/50 font-num mt-0.5">
                  {t(lang, 'totalMined')}: {formatBell(data.user.totalMinedMicro)} BELL
                </div>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-emerald-100/45 shrink-0 rtl:rotate-180" />
          </button>

          {/* Main Mining Card */}
          <section
            aria-label={t(lang, 'mining')}
            className="bell-card rounded-3xl p-5 space-y-4"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/12 border border-emerald-400/25 flex items-center justify-center text-emerald-400">
                  <Box className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-semibold text-[15px] text-white leading-tight">
                    {t(lang, 'mining')}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs mt-0.5">
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        data.mining.status === 'running' && !liveMining.isExpired
                          ? 'bg-emerald-400'
                          : 'bg-amber-400'
                      }`}
                      aria-hidden="true"
                    />
                    <span
                      className={
                        data.mining.status === 'running' && !liveMining.isExpired
                          ? 'text-emerald-400 font-medium'
                          : 'text-amber-300 font-medium'
                      }
                    >
                      {data.mining.status === 'running' && !liveMining.isExpired
                        ? t(lang, 'running')
                        : data.mining.status === 'paused' || liveMining.isExpired
                        ? t(lang, 'paused')
                        : t(lang, 'idle')}
                    </span>
                  </div>
                </div>
              </div>

              <div dir="ltr" className="px-3 py-1 rounded-full border border-amber-400/40 bg-amber-500/10 text-amber-300 font-num text-xs font-semibold">
                ×{(data.mining.multiplierBps / 10000).toFixed(2)}
              </div>
            </div>

            <div className="flex items-center justify-between gap-4">
              <div className="min-w-0 flex-1 space-y-2.5">
                <div className="flex items-baseline gap-2 flex-wrap">
                  <span
                    dir="ltr"
                    data-testid="mining-accrued"
                    className="font-num text-3xl sm:text-4xl font-bold text-white tracking-tight"
                  >
                    +{formatBell(liveMining.accruedMicro)}
                  </span>
                  <span className="font-display text-lg font-bold text-emerald-400">BELL</span>
                </div>

                <div className="text-xs text-emerald-100/60 font-num">
                  {liveMining.isExpired
                    ? t(lang, 'sessionEnded')
                    : `${t(lang, 'miningPausesIn')} ${formatCountdown(liveMining.remainingSec)}`}
                </div>

                {/* Progress Bar */}
                <div className="w-full h-2 rounded-full bg-emerald-950/90 border border-emerald-400/15 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.max(4, liveMining.progressPct)}%`,
                      background: 'linear-gradient(90deg, #10b981 0%, #84cc16 100%)',
                    }}
                  />
                </div>
              </div>

              <GoldenBellIcon className="w-20 h-20 shrink-0" />
            </div>

            <button
              type="button"
              onClick={handleClaimMining}
              disabled={!canClaimMining}
              className={`w-full min-h-[50px] rounded-2xl font-semibold text-[15px] transition-all cursor-pointer ${
                canClaimMining
                  ? 'bell-cta-emerald'
                  : 'bg-emerald-950/70 border border-emerald-400/15 text-emerald-100/45 cursor-not-allowed'
              }`}
            >
              {claimingMining ? t(lang, 'claiming') : t(lang, 'claimBell')}
            </button>
          </section>

          {/* 4-Column Stat Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="bell-card rounded-2xl p-3 text-center flex flex-col items-center justify-center min-h-[108px]">
              <Zap className="w-4 h-4 text-emerald-400 mb-1.5" />
              <div className="text-[11px] text-emerald-100/60">{t(lang, 'hourly')}</div>
              <div className="font-num text-base font-bold text-white mt-0.5">
                {data.mining.hourlyRateBell.toFixed(2)}
              </div>
              <div className="text-[11px] text-emerald-100/45">BELL/h</div>
            </div>

            <div className="bell-card rounded-2xl p-3 text-center flex flex-col items-center justify-center min-h-[108px]">
              <Calendar className="w-4 h-4 text-emerald-400 mb-1.5" />
              <div className="text-[11px] text-emerald-100/60">{t(lang, 'daily')}</div>
              <div className="font-num text-base font-bold text-white mt-0.5">
                {data.mining.dailyRateBell.toLocaleString('en-US')}
              </div>
              <div className="text-[11px] text-emerald-100/45">BELL/day</div>
            </div>

            <div className="bell-card rounded-2xl p-3 text-center flex flex-col items-center justify-center min-h-[108px]">
              <TrendingUp className="w-4 h-4 text-emerald-400 mb-1.5" />
              <div className="text-[11px] text-emerald-100/60">{t(lang, 'boost')}</div>
              <div className="font-num text-base font-bold text-white mt-0.5">
                ×{(data.mining.multiplierBps / 10000).toFixed(2)}
              </div>
              <div className="text-[11px] text-emerald-100/45">{t(lang, 'multiplier')}</div>
            </div>

            <div className="bell-card rounded-2xl p-3 text-center flex flex-col items-center justify-center min-h-[108px]">
              <Shield className="w-4 h-4 text-emerald-400 mb-1.5" />
              <div className="text-[11px] text-emerald-100/60">{t(lang, 'league')}</div>
              <div className="text-base font-bold text-white mt-0.5 truncate max-w-full">
                {lang === 'ar' ? data.user.level.nameAr : data.user.level.name}
              </div>
              <div className="text-[11px] text-emerald-100/45 font-num">
                Lv.{data.user.level.level}
              </div>
            </div>
          </div>
        </div>

        {/* Secondary Column (Next Level + Daily Login + Mission Center) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Next Level Card */}
          <div className="bell-card rounded-3xl p-4 flex items-center gap-4">
            <div className="relative w-14 h-14 shrink-0 flex items-center justify-center">
              <svg viewBox="0 0 64 64" className="w-full h-full">
                <defs>
                  <linearGradient id="hexLvl" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#6ee7b7" />
                    <stop offset="100%" stopColor="#10b981" />
                  </linearGradient>
                </defs>
                <polygon
                  points="32,4 58,18 58,46 32,60 6,46 6,18"
                  fill="url(#hexLvl)"
                />
              </svg>
              <span className="absolute font-num text-xl font-bold text-[#031a0f]">
                {data.user.level.level}
              </span>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="font-semibold text-white">
                  {nextLvl
                    ? `${t(lang, 'nextLevel')}: ${nextLvl.level}`
                    : t(lang, 'maxLevelReached')}
                </span>
                {nextLvl && (
                  <span className="font-num text-emerald-100/60">
                    {Math.floor(bellgramHeldWhole).toLocaleString('en-US')} /{' '}
                    {nextLvl.minBellgram.toLocaleString('en-US')} BELLGRAM
                  </span>
                )}
              </div>

              <div className="w-full h-2 rounded-full bg-emerald-950/90 border border-emerald-400/15 overflow-hidden my-2">
                <div
                  className="h-full rounded-full bg-emerald-400 transition-all"
                  style={{ width: `${Math.max(2, nextLvlProgress)}%` }}
                />
              </div>

              {nextLvl && (
                <p className="text-xs text-emerald-100/60 leading-snug">
                  {t(lang, 'holdToReach', {
                    amount: nextLvl.minBellgram.toLocaleString('en-US'),
                    name: lang === 'ar' ? nextLvl.nameAr : nextLvl.name,
                    daily: nextLvl.dailyBell.toLocaleString('en-US'),
                  })}
                </p>
              )}
            </div>
          </div>

          {/* Daily Login Streak Card */}
          <section aria-label={t(lang, 'dailyLogin')} className="bell-card rounded-3xl p-4 space-y-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/12 border border-emerald-400/25 flex items-center justify-center text-emerald-400 shrink-0">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-semibold text-[15px] text-white">
                    {t(lang, 'dailyLogin')}
                  </div>
                  <div className="text-xs text-emerald-100/60 mt-0.5">
                    {data.daily.canClaim
                      ? t(lang, 'claimTodayBonus', { amount: data.daily.todayRewardBell })
                      : t(lang, 'dailyClaimedToday')}
                  </div>
                </div>
              </div>

              <span
                data-testid="daily-streak-badge"
                className="px-3 py-1 rounded-full border border-amber-400/40 bg-amber-500/10 text-amber-300 font-num text-xs font-semibold shrink-0"
              >
                {t(lang, 'dayOfSeven', { day: data.daily.currentDayIndex })}
              </span>
            </div>

            <button
              type="button"
              onClick={handleClaimDaily}
              disabled={!data.daily.canClaim || claimingDaily}
              className={`w-full min-h-[48px] rounded-2xl font-semibold text-[15px] transition-all cursor-pointer ${
                data.daily.canClaim
                  ? 'bell-cta-gold'
                  : 'bg-amber-950/35 border border-amber-400/20 text-amber-200/45 cursor-not-allowed'
              }`}
            >
              {claimingDaily
                ? t(lang, 'claiming')
                : data.daily.canClaim
                ? t(lang, 'claimDailyBonus')
                : t(lang, 'dailyBonusClaimed')}
            </button>
          </section>

          {/* Mission Center Card */}
          <button
            type="button"
            onClick={onNavigateMissions}
            className="w-full bell-card rounded-3xl p-4 flex items-center justify-between gap-3 hover:border-emerald-400/40 transition-colors text-start cursor-pointer min-h-[76px]"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/12 border border-emerald-400/25 flex items-center justify-center text-emerald-400 shrink-0">
                <CheckSquare className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-[15px] text-white">
                  {t(lang, 'missionCenter')}
                </div>
                <div className="text-xs text-emerald-100/60 mt-0.5">
                  {t(lang, 'dailyTasksRewards')}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="px-3 py-1 rounded-full border border-emerald-400/35 bg-emerald-500/10 text-emerald-300 font-num text-xs font-semibold">
                {availableMissionsCount} {t(lang, 'openMissions')}
              </span>
              <ChevronRight className="w-4 h-4 text-emerald-100/45 rtl:rotate-180" />
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
