import React, { useState } from 'react';
import { Check, Copy, Info, Share2, User, Users } from 'lucide-react';
import { t } from '../lib/i18n.ts';
import type { FriendsSummary, Language } from '../types.ts';

interface FriendsViewProps {
  friends: FriendsSummary;
  lang: Language;
}

export function FriendsView({ friends, lang }: FriendsViewProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(friends.inviteLink);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  const handleShare = () => {
    const shareText = encodeURIComponent(
      lang === 'ar'
        ? `انضم معي إلى تعدين BELLGRAM واحصل على ${friends.referralBonusBell} BELL مكافأة ترحيب!`
        : `Join me on BELLGRAM Mining and get ${friends.referralBonusBell} BELL welcome bonus!`
    );
    const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(friends.inviteLink)}&text=${shareText}`;

    if (window.Telegram?.WebApp?.initData && window.Telegram.WebApp.openTelegramLink) {
      window.Telegram.WebApp.openTelegramLink(shareUrl);
      return;
    }
    if (navigator.share) {
      navigator
        .share({
          title: 'BELLGRAM',
          text: decodeURIComponent(shareText),
          url: friends.inviteLink,
        })
        .catch(() => {});
      return;
    }
    handleCopy();
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
      <div className="lg:col-span-6 space-y-4">
        {/* Invite Friends Card */}
        <section className="bell-card rounded-3xl p-5 space-y-4">
          <div>
            <h1 className="font-display text-2xl font-bold text-white">
              {t(lang, 'inviteFriends')}
            </h1>
            <p className="text-sm text-emerald-100/65 mt-1.5">
              {t(lang, 'inviteSubtitle', { bonus: friends.referralBonusBell })}
            </p>
          </div>

          <div
            data-testid="referral-condition-notice"
            className="rounded-xl bg-amber-500/10 border border-amber-400/20 px-3.5 py-2.5 flex items-start gap-2.5 text-xs text-amber-100/90 leading-relaxed"
          >
            <Info className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
            <span>{t(lang, 'referralConditionNotice', { bonus: friends.referralBonusBell })}</span>
          </div>

          <div
            dir="ltr"
            data-testid="referral-link-box"
            className="w-full rounded-xl bg-black/45 border border-emerald-400/15 px-3.5 py-3 text-xs font-mono text-emerald-100/80 truncate select-all"
          >
            {friends.inviteLink}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={handleShare}
              className="min-h-[48px] rounded-2xl bell-cta-emerald font-semibold text-sm inline-flex items-center justify-center gap-2 px-3 cursor-pointer"
            >
              <Share2 className="w-4 h-4 shrink-0" />
              <span className="truncate">{t(lang, 'shareInviteLink')}</span>
            </button>

            <button
              type="button"
              onClick={handleCopy}
              className="min-h-[48px] rounded-2xl bg-emerald-950/75 border border-emerald-400/25 hover:border-emerald-400/45 font-semibold text-sm text-emerald-50 inline-flex items-center justify-center gap-2 px-3 transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400 shrink-0" /> : <Copy className="w-4 h-4 shrink-0" />}
              <span>{copied ? t(lang, 'copied') : t(lang, 'copyLink')}</span>
            </button>
          </div>
        </section>

        {/* Stats Pair */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bell-card rounded-3xl p-5 text-center flex flex-col items-center justify-center">
            <User className="w-5 h-5 text-emerald-400 mb-2" />
            <div className="text-xs text-emerald-100/60">{t(lang, 'friendsLabel')}</div>
            <div
              data-testid="friends-count"
              className="font-num text-3xl font-bold text-emerald-400 mt-1"
            >
              {friends.friendsCount}
            </div>
            <div className="text-xs text-emerald-100/50 mt-0.5">{t(lang, 'joinedCount')}</div>
          </div>

          <div className="bell-card rounded-3xl p-5 text-center flex flex-col items-center justify-center">
            <Users className="w-5 h-5 text-emerald-400 mb-2" />
            <div className="text-xs text-emerald-100/60">{t(lang, 'friendsOfFriends')}</div>
            <div className="font-num text-3xl font-bold text-emerald-400 mt-1">
              {friends.friendsOfFriendsCount}
            </div>
            <div className="text-xs text-emerald-100/50 mt-0.5">{t(lang, 'people')}</div>
          </div>
        </div>
      </div>

      {/* All Friends List */}
      <section className="lg:col-span-6 bell-card rounded-3xl p-5 space-y-3">
        <h2 className="font-display text-2xl font-bold text-white">{t(lang, 'allFriends')}</h2>

        {friends.friends.length === 0 ? (
          <p className="text-sm text-emerald-100/60 py-4">{t(lang, 'noFriendsYet')}</p>
        ) : (
          <div className="divide-y divide-emerald-400/10">
            {friends.friends.map((f) => (
              <div key={f.id} className="py-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-full font-bold text-sm flex items-center justify-center shrink-0 ${
                      f.walletVerified
                        ? 'bg-emerald-400 text-[#031a0f]'
                        : 'bg-amber-400/15 text-amber-200 border border-amber-400/25'
                    }`}
                  >
                    {f.firstName.slice(0, 1).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-white truncate">
                      {f.firstName} {f.username ? `(@${f.username})` : ''}
                    </div>
                    <div className="text-xs text-emerald-100/50 font-num">
                      {new Date(f.joinedAt).toLocaleDateString()}
                    </div>
                  </div>
                </div>
                {f.walletVerified ? (
                  <div className="font-num text-sm font-semibold text-emerald-400 shrink-0 whitespace-nowrap">
                    +{f.bonusBell} BELL
                  </div>
                ) : (
                  <div
                    data-testid={`friend-unverified-${f.id}`}
                    className="text-xs font-semibold text-amber-300 shrink-0 whitespace-nowrap"
                  >
                    {t(lang, 'friendNotVerified')}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
