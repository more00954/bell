import React from 'react';

export function GoldenBellIcon({ className = 'w-16 h-16' }: { className?: string }) {
  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      <div
        className="absolute inset-0 rounded-full blur-2xl opacity-55 pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(245, 183, 49, 0.55) 0%, transparent 70%)' }}
      />
      <svg viewBox="0 0 80 80" fill="none" className="relative w-full h-full drop-shadow-[0_6px_14px_rgba(245,158,11,0.35)]">
        <defs>
          <linearGradient id="bellGoldGrad" x1="20" y1="12" x2="60" y2="66" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FDE68A" />
            <stop offset="45%" stopColor="#F5B731" />
            <stop offset="100%" stopColor="#D97706" />
          </linearGradient>
        </defs>
        <path
          d="M40 10C37.5 10 35.5 11.7 35.1 14.1C24.5 16.4 18 25.5 18 37.5V48.5L13.2 54.4C12.3 55.5 13.1 57.2 14.6 57.2H65.4C66.9 57.2 67.7 55.5 66.8 54.4L62 48.5V37.5C62 25.5 55.5 16.4 44.9 14.1C44.5 11.7 42.5 10 40 10Z"
          fill="url(#bellGoldGrad)"
        />
        <path
          d="M25.5 35.5C25.5 27.5 29.8 21.6 35.8 19.6"
          stroke="#FEF3C7"
          strokeWidth="3.2"
          strokeLinecap="round"
          opacity="0.85"
        />
        <circle cx="40" cy="65" r="5" fill="url(#bellGoldGrad)" />
      </svg>
    </div>
  );
}

export function HeroBannerArtwork() {
  return (
    <svg
      viewBox="0 0 420 152"
      preserveAspectRatio="xMidYMid slice"
      className="absolute inset-0 w-full h-full pointer-events-none select-none rtl:-scale-x-100"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="auroraBg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#041910" />
          <stop offset="50%" stopColor="#093822" />
          <stop offset="100%" stopColor="#051c12" />
        </linearGradient>
        <radialGradient id="auroraGlow" cx="76%" cy="42%" r="52%">
          <stop offset="0%" stopColor="#34f5a8" stopOpacity="0.45" />
          <stop offset="45%" stopColor="#10b981" stopOpacity="0.18" />
          <stop offset="100%" stopColor="#041910" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="crystalBell" x1="250" y1="10" x2="310" y2="120" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#bef264" />
          <stop offset="40%" stopColor="#34f5a8" />
          <stop offset="85%" stopColor="#059669" />
          <stop offset="100%" stopColor="#f59e0b" />
        </linearGradient>
        <linearGradient id="bellRim" x1="230" y1="85" x2="335" y2="105" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#fcd34d" />
          <stop offset="50%" stopColor="#f59e0b" />
          <stop offset="100%" stopColor="#d97706" />
        </linearGradient>
      </defs>

      <rect width="420" height="152" fill="url(#auroraBg)" />
      <rect width="420" height="152" fill="url(#auroraGlow)" />

      {/* Aurora ribbons */}
      <path
        d="M-10 45 Q 70 5, 160 40 T 300 20 T 430 40 L 430 0 L -10 0 Z"
        fill="#34f5a8"
        opacity="0.12"
      />
      {/* Mountain silhouettes */}
      <path d="M0 152 L60 92 L120 135 L185 82 L250 152 Z" fill="#03130c" opacity="0.88" />
      <path d="M220 152 L290 95 L360 132 L420 100 L420 152 Z" fill="#03130c" opacity="0.72" />

      {/* Glowing Crystalline Emerald & Gold Bell */}
      <g transform="translate(86, 16) scale(0.84)">
        <ellipse cx="278" cy="108" rx="44" ry="11" fill="#34f5a8" opacity="0.24" />
        <path
          d="M278 14 C252 14, 240 36, 236 74 L224 94 C222 98, 225 102, 230 102 H326 C331 102, 334 98, 332 94 L320 74 C316 36, 304 14, 278 14 Z"
          fill="url(#crystalBell)"
          opacity="0.94"
        />
        <path
          d="M225 96 Q 278 112 331 96"
          stroke="url(#bellRim)"
          strokeWidth="5"
          strokeLinecap="round"
          fill="none"
        />
        <circle cx="278" cy="116" r="7.5" fill="#a7f3d0" opacity="0.95" />
        <path d="M254 34 Q 249 54 246 72" stroke="#ecfccb" strokeWidth="2.5" strokeLinecap="round" opacity="0.65" />
      </g>
    </svg>
  );
}
