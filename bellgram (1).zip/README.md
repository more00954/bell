# BELLGRAM — Telegram Mining Bot + Mini App 🔔

مشروع متكامل لبوت وتطبيق تيليجرام مصغر (**Telegram Mini App**) باسم **BELLGRAM**، مبني بواجهة Mobile-first مطابقة للتصميم الأخضر الزمردي والذهبي مع دعم كامل للغة العربية (**RTL**) والإنجليزية، وخادم آمن، وقاعدة بيانات علائقية، ولوحة إدارة مستقلة، وبوت تيليجرام بـ Python `aiogram 3`.

---

## المميزات الرئيسية

- **شاشة التحقق من القنوات (`ChannelGate`)**: التحقق الفعلي من اشتراك المستخدم عبر Telegram Bot API (`getChatMember`) قبل بدء التعدين.
- **نظام التعدين الخادمي (`Server-Authoritative Mining`)**:
  - جلسة تعدين لمدة 24 ساعة تُحسب بالمللي ثانية على الخادم باستخدام أعداد صحيحة دقيقة (`1 BELL = 10,000 micro-BELL`) لتجنب أخطاء الفواصل العشرية.
  - منع تكرار المطالبة باستخدام معاملات ذرية (`BEGIN IMMEDIATE`) ومفتاح عدم التكرار (`Idempotency-Key`) وقيود قاعدة البيانات الفريدة.
- **المكافآت اليومية (`Daily Login`)**: سلسلة 7 أيام بتوقيت الخادم الموحد (`UTC`) مع إعادة التعيين تلقائيًا عند تفويت يوم.
- **نظام الإحالات (`Friends / Referrals`)**: روابط عميقة (`https://t.me/<BOT_USERNAME>?start=ref_<USER_ID>`) مع مكافأة 50 BELL للداعي والمستخدم الجديد، ومنع الإحالة الذاتية أو التكرار، وعرض أصدقاء الأصدقاء.
- **صفحة المحفظة (`Wallet`) وTON Connect**:
  - ربط المحفظة عبر `@tonconnect/ui` بدون طلب العبارة السرية أو المفتاح الخاص.
  - مستويات التعدين (`Free`, `Tin`, `Copper`, `Brass`, `Silver`).
  - تنبيه شفاف يوضح أن رصيد BELL داخل التطبيق رصيد افتراضي ما لم يتم ربط عقد ذكي رسمي.
- **مركز المهام (`Mission Center`)**: مهام القنوات، الدخول اليومي، دعوة الأصدقاء، ومهام قابلة للإضافة من لوحة الإدارة مع حالات (`Available` / `Pending` / `Completed`).
- **لوحة الإدارة (`Admin Dashboard` على المسار `/admin`)**:
  - إحصائيات المستخدمين، البحث بمعرف تيليجرام، تعطيل/تفعيل الحسابات، تعديل المستويات والمكافآت اليومية والقنوات والمهام، سجل العمليات وسجل التدقيق الإداري، وتصدير CSV.
  - مصادقة `scrypt` + رمز Bearer بالذاكرة + حماية CSRF + تقييد معدل الطلبات (Rate Limiting).

---

## الخطوة 1: إنشاء البوت والحصول على `BOT_TOKEN` عبر BotFather

1. افتح تطبيق **Telegram** وابحث عن البوت الرسمي `@BotFather`.
2. أرسل الأمر `/newbot`.
3. اختر اسم البوت الظاهر، مثل: `BELLGRAM`.
4. اختر اسم مستخدم ينتهي بكلمة `bot`، مثل: `bellgram_mine_bot`.
5. سينشئ لك BotFather رمز التوكن (**BOT_TOKEN**) — احفظه بسرية ولا تشاركه أو تضعه في Git.
6. لربط Mini App لاحقًا بعد النشر على رابط HTTPS:
   - أرسل `/newapp` إلى `@BotFather`، واختر البوت، وأدخل رابط HTTPS العام الخاص بالتطبيق.
7. للتحقق من اشتراك المستخدمين في القنوات:
   - أضف البوت كـ **Admin (مشرف)** في قناتك الرسمية وقناة المجتمع.

---

## الخطوة 2: أوامر التشغيل خطوة بخطوة على Windows (Windows Terminal / PowerShell)

### المتطلبات المسبقة
- تثبيت **Node.js 22+** من [nodejs.org](https://nodejs.org)
- تثبيت **Python 3.11+** من [python.org](https://www.python.org) (فعّل خيار *Add Python to PATH* أثناء التثبيت)

### 1) تجهيز ملف البيئة `.env`
افتح **Windows Terminal** داخل مجلد المشروع ونفّذ:

```powershell
copy .env.example .env
notepad .env
```

عدّل القيم التالية داخل `.env`:
```env
BOT_TOKEN=ضع_توكن_البوت_هنا
BOT_USERNAME=اسم_مستخدم_البوت_بدون_@
APP_URL=https://your-https-domain.com
ALLOW_PREVIEW_AUTH=true
ADMIN_PASSCODE=كلمة_مرور_قوية_للإدارة
```

> **ملاحظة:** إذا تركت `ADMIN_PASSCODE` فارغًا، ستظهر لك شاشة إعداد كلمة مرور الإدارة لأول مرة مباشرة من المتصفح عند فتح `/admin`.

### 2) تشغيل الخادم والواجهة (Node.js + Express + SQLite + React)

```powershell
npm install
npm test
npm run build
npm run dev
```

سيعمل التطبيق الآن على:
- التطبيق الرئيسي: `http://localhost:3000`
- لوحة الإدارة: `http://localhost:3000/admin`
- توثيق OpenAPI: `http://localhost:3000/api/openapi.json`

### 3) تشغيل بوت تيليجرام (Python + aiogram 3)
افتح تبويبًا جديدًا في **Windows Terminal** ونفّذ:

```powershell
cd bot
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python main.py
```

---

## الخطوة 3: التشغيل باستخدام Docker (اختياري)

```powershell
docker compose up --build -d
```

---

## الخطوة 4: النشر على الإنتاج (HTTPS)

يتطلب Telegram Mini Apps رابط **HTTPS** حقيقي:
1. يمكنك النشر على **Railway** أو **Render** أو **Fly.io** أو خادم VPS مع **Nginx + Certbot SSL**.
2. اضبط متغيرات البيئة في منصة الاستضافة:
   - `NODE_ENV=production`
   - `ALLOW_PREVIEW_AUTH=false` (لإلزام المصادقة عبر Telegram `initData` فقط في الإنتاج)
   - `BOT_TOKEN` و `BOT_USERNAME` و `APP_URL` و `ADMIN_PASSCODE`
3. في الإنتاج، استخدم `npm run build` ثم `npm start`.
4. لا تنسَ ضبط رابط HTTPS في `@BotFather` عبر `/setmenubutton` أو `/newapp`.

---

## هيكل المشروع

- `server.ts` — نقطة دخول Express وتوجيه API وتوثيق OpenAPI.
- `server/` — طبقة قاعدة البيانات (`db.ts`)، مصادقة تيليجرام (`telegramAuth.ts`)، والخدمات الذرية (`miningService.ts`, `rewardsService.ts`, `referralService.ts`, `missionService.ts`, `walletService.ts`, `adminService.ts`).
- `src/` — واجهة React + Tailwind CSS + TON Connect + لوحة الإدارة (`/admin`).
- `src/lib/bellMath.ts` و `src/lib/bellMath.test.ts` — المنطق الرياضي الدقيق واختبارات `node:test`.
- `bot/main.py` — بوت تيليجرام مكتوب بـ Python `aiogram 3`.
