import crypto from 'node:crypto';

export interface VerifiedTelegramUser {
  id: number;
  firstName: string;
  lastName: string | null;
  username: string | null;
  languageCode: string;
  startParam: string | null;
  authDate: number;
}

/**
 * Official Telegram Mini App initData verification:
 * https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
 */
export function verifyTelegramInitData(
  initData: string,
  botToken: string,
  maxAgeSec = 86400
): VerifiedTelegramUser | null {
  if (!initData || !botToken) return null;

  try {
    const params = new URLSearchParams(initData);
    const receivedHash = params.get('hash');
    if (!receivedHash || !/^[0-9a-f]{64}$/i.test(receivedHash)) {
      return null;
    }

    const authDateStr = params.get('auth_date');
    const authDate = Number(authDateStr);
    if (!Number.isFinite(authDate) || authDate <= 0) {
      return null;
    }

    const nowSec = Math.floor(Date.now() / 1000);
    if (nowSec - authDate > maxAgeSec) {
      return null;
    }

    const entries: Array<[string, string]> = [];
    for (const [k, v] of params.entries()) {
      if (k !== 'hash') {
        entries.push([k, v]);
      }
    }
    entries.sort(([a], [b]) => a.localeCompare(b));
    const dataCheckString = entries.map(([k, v]) => `${k}=${v}`).join('\n');

    const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
    const expectedHex = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');

    const receivedBuf = Buffer.from(receivedHash.toLowerCase(), 'hex');
    const expectedBuf = Buffer.from(expectedHex.toLowerCase(), 'hex');
    if (receivedBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(receivedBuf, expectedBuf)) {
      return null;
    }

    const userRaw = params.get('user');
    if (!userRaw) return null;
    const parsedUser = JSON.parse(userRaw) as {
      id?: number;
      first_name?: string;
      last_name?: string;
      username?: string;
      language_code?: string;
    };

    if (!parsedUser || typeof parsedUser.id !== 'number' || !Number.isFinite(parsedUser.id)) {
      return null;
    }

    return {
      id: parsedUser.id,
      firstName: (parsedUser.first_name || 'User').slice(0, 80),
      lastName: parsedUser.last_name ? parsedUser.last_name.slice(0, 80) : null,
      username: parsedUser.username ? parsedUser.username.slice(0, 64) : null,
      languageCode: (parsedUser.language_code || 'en').slice(0, 12),
      startParam: params.get('start_param') || null,
      authDate,
    };
  } catch {
    return null;
  }
}

export async function checkTelegramChannelMembership(
  botToken: string,
  channelUsername: string,
  telegramUserId: number
): Promise<{ ok: boolean; isMember: boolean; reason?: string }> {
  if (!botToken || !channelUsername) {
    return { ok: false, isMember: false, reason: 'bot_not_configured' };
  }

  let cleaned = channelUsername.trim();
  const tmeMatch = cleaned.match(/^(?:https?:\/\/)?t\.me\/(?:s\/)?([^/?#]+)/i);
  if (tmeMatch) {
    cleaned = tmeMatch[1];
  }
  const chatId =
    cleaned.startsWith('@') || /^-?\d+$/.test(cleaned) ? cleaned : `@${cleaned}`;

  try {
    const url = new URL(`https://api.telegram.org/bot${botToken}/getChatMember`);
    url.searchParams.set('chat_id', chatId);
    url.searchParams.set('user_id', String(telegramUserId));

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    const resp = await fetch(url.toString(), { signal: controller.signal });
    clearTimeout(timer);

    const json = (await resp.json().catch(() => ({}))) as {
      ok?: boolean;
      result?: { status?: string };
      description?: string;
    };

    if (!resp.ok || !json.ok || !json.result) {
      return {
        ok: false,
        isMember: false,
        reason: json.description || `telegram_http_${resp.status}`,
      };
    }

    const status = json.result.status || '';
    const isMember = ['creator', 'administrator', 'member', 'restricted'].includes(status);
    return { ok: true, isMember };
  } catch {
    return { ok: false, isMember: false, reason: 'telegram_network_error' };
  }
}

export function escapeTelegramHtml(input: string): string {
  return String(input || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

export async function sendTelegramMessage(
  botToken: string,
  chatId: string | number,
  htmlText: string,
  replyMarkup?: unknown
): Promise<boolean> {
  if (!botToken || !chatId) return false;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    const resp = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: htmlText,
        parse_mode: 'HTML',
        disable_web_page_preview: true,
        ...(replyMarkup ? { reply_markup: replyMarkup } : {}),
      }),
      signal: controller.signal,
    });
    clearTimeout(timer);
    if (!resp.ok) return false;
    const json = (await resp.json()) as { ok?: boolean };
    return Boolean(json.ok);
  } catch {
    return false;
  }
}

