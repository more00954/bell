import crypto from 'node:crypto';
import path from 'node:path';

const ephemSecret = crypto.randomBytes(32).toString('hex');

const rawEnvAppUrl = (process.env.APP_URL || '').trim();
const hasExplicitAppUrl =
  Boolean(rawEnvAppUrl) && rawEnvAppUrl !== 'MY_APP_URL' && /^https?:\/\//i.test(rawEnvAppUrl);

export const config = {
  port: Number(process.env.PORT || 3000),
  nodeEnv: process.env.NODE_ENV || 'development',
  botToken: (process.env.BOT_TOKEN || '').trim(),
  botUsername: (process.env.BOT_USERNAME || 'bellgrammbot').replace(/^@/, '').trim(),
  allowPreviewAuth: (process.env.ALLOW_PREVIEW_AUTH || 'true').toLowerCase() === 'true',
  adminPasscode: (process.env.ADMIN_PASSCODE || '').trim(),
  adminTelegramUsernames: (process.env.ADMIN_TELEGRAM_USERNAMES || 'ex_zain,g_h_o_s_t_14')
    .split(',')
    .map((u) => u.trim().replace(/^@/, '').toLowerCase())
    .filter(Boolean),
  sessionSecret: (process.env.SESSION_SECRET || '').trim() || ephemSecret,
  dbPath: path.resolve(process.cwd(), process.env.DB_PATH || './data/bellgram.db'),
  toncenterApiKey: (process.env.TONCENTER_API_KEY || '').trim(),
  bellgramJettonMaster: (
    process.env.BELLGRAM_JETTON_MASTER || 'EQAWPHubEzmFIM0UWV0yuATzbmj9HdRRn5WXvKLzqflrWGvl'
  ).trim(),
  walletVerifyAddress: (
    process.env.WALLET_VERIFY_ADDRESS || 'UQBQYTtbO41F-DS6tkVlLAB3zdXCAYt0iTShR-ed8EVdVMgt'
  ).trim(),
  walletVerifyAmountNano: 50_000_000, // 0.05 TON
  hasExplicitAppUrl,
  appUrl: hasExplicitAppUrl ? rawEnvAppUrl.replace(/\/+$/, '') : '',
};
