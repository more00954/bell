import net from 'node:net';

/**
 * Extracts and validates the client IP address from headers/socket strings.
 * Strips IPv4-mapped IPv6 prefixes (`::ffff:`) and optional port numbers,
 * returning null for invalid or non-IP values.
 */
export function normalizeIpAddress(rawInput: string | string[] | null | undefined): string | null {
  if (!rawInput) return null;
  const raw = Array.isArray(rawInput) ? rawInput[0] : rawInput;
  if (typeof raw !== 'string') return null;

  // x-forwarded-for can contain comma-separated hops; take the leftmost client hop
  const firstHop = raw.split(',')[0]?.trim();
  if (!firstHop || firstHop.length > 64) return null;

  let candidate = firstHop;

  // Handle bracketed IPv6 with optional port: [::1]:1234 -> ::1
  if (candidate.startsWith('[')) {
    const closeIdx = candidate.indexOf(']');
    if (closeIdx > 1) {
      candidate = candidate.slice(1, closeIdx);
    }
  } else if (net.isIP(candidate) === 0 && /^\d{1,3}(?:\.\d{1,3}){3}:\d+$/.test(candidate)) {
    // Strip IPv4 port: 1.2.3.4:5678 -> 1.2.3.4
    candidate = candidate.slice(0, candidate.lastIndexOf(':'));
  }

  // Normalize IPv4-mapped IPv6 ::ffff:1.2.3.4 -> 1.2.3.4
  if (candidate.toLowerCase().startsWith('::ffff:')) {
    const mapped = candidate.slice(7);
    if (net.isIPv4(mapped)) {
      candidate = mapped;
    }
  }

  if (net.isIP(candidate) === 0) {
    return null;
  }

  return candidate.toLowerCase();
}

/**
 * Returns the /24 prefix for IPv4 (e.g. `203.0.113.*`) or /64 prefix for IPv6
 * so accounts rotating dynamic IPs on the same router/ISP block can be flagged.
 */
export function getIpSubnetPrefix(ip: string): string | null {
  const normalized = normalizeIpAddress(ip);
  if (!normalized) return null;

  if (net.isIPv4(normalized)) {
    const parts = normalized.split('.');
    if (parts.length !== 4) return null;
    return `${parts[0]}.${parts[1]}.${parts[2]}.*`;
  }

  if (net.isIPv6(normalized)) {
    const expanded = expandIpv6(normalized);
    if (!expanded) return null;
    return `${expanded.slice(0, 4).join(':')}:*`;
  }

  return null;
}

function expandIpv6(ip: string): string[] | null {
  const halves = ip.split('::');
  if (halves.length > 2) return null;
  const left = halves[0] ? halves[0].split(':').filter(Boolean) : [];
  const right = halves[1] ? halves[1].split(':').filter(Boolean) : [];
  const missing = 8 - (left.length + right.length);
  if (halves.length === 1 && left.length !== 8) return null;
  if (halves.length === 2 && missing < 0) return null;
  const middle = halves.length === 2 ? Array<string>(missing).fill('0000') : [];
  return [...left, ...middle, ...right].map((g) => g.padStart(4, '0'));
}
