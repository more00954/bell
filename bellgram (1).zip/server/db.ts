import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { config } from './config.ts';
import type { ChannelConfig, MiningLevel } from '../src/types.ts';

let dbInstance: DatabaseSync | null = null;

export const DEFAULT_MINING_LEVELS: MiningLevel[] = [
  { level: 0, name: 'Free', nameAr: 'مجاني', minBellgram: 0, dailyBell: 500 },
  { level: 1, name: 'Tin', nameAr: 'قصدير', minBellgram: 1000, dailyBell: 700 },
  { level: 2, name: 'Copper', nameAr: 'نحاس', minBellgram: 2000, dailyBell: 800 },
  { level: 3, name: 'Brass', nameAr: 'نحاس أصفر', minBellgram: 3000, dailyBell: 900 },
  { level: 4, name: 'Silver', nameAr: 'فضة', minBellgram: 4000, dailyBell: 1000 },
];

export const DEFAULT_DAILY_REWARDS: number[] = [10, 15, 20, 30, 45, 65, 100];

export const DEFAULT_CHANNELS: ChannelConfig[] = [
  {
    id: 'official',
    title: 'BELLGRAM Official Channel',
    titleAr: 'قناة BELLGRAM الرسمية',
    username: 'bellgram_official',
    url: 'https://t.me/bellgram_official',
    isRequired: true,
  },
  {
    id: 'community',
    title: 'BELLGRAM Community Chat',
    titleAr: 'مجتمع BELLGRAM',
    username: 'bellgram_community',
    url: 'https://t.me/bellgram_community',
    isRequired: true,
  },
];

export function getDb(): DatabaseSync {
  if (dbInstance) return dbInstance;

  const dir = path.dirname(config.dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  const db = new DatabaseSync(config.dbPath);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA busy_timeout = 5000;');

  initSchema(db);
  seedDefaults(db);
  dbInstance = db;
  return db;
}

function initSchema(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      telegram_id TEXT NOT NULL UNIQUE,
      username TEXT,
      first_name TEXT NOT NULL,
      last_name TEXT,
      language_code TEXT NOT NULL DEFAULT 'en',
      balance_micro INTEGER NOT NULL DEFAULT 0 CHECK (balance_micro >= 0),
      total_mined_micro INTEGER NOT NULL DEFAULT 0 CHECK (total_mined_micro >= 0),
      ton_balance_nano INTEGER NOT NULL DEFAULT 0 CHECK (ton_balance_nano >= 0),
      bellgram_balance_micro INTEGER NOT NULL DEFAULT 0 CHECK (bellgram_balance_micro >= 0),
      level_id INTEGER NOT NULL DEFAULT 0,
      boost_bps INTEGER NOT NULL DEFAULT 10000,
      channels_verified INTEGER NOT NULL DEFAULT 0,
      joined_channel_ids_json TEXT NOT NULL DEFAULT '[]',
      is_banned INTEGER NOT NULL DEFAULT 0,
      is_preview INTEGER NOT NULL DEFAULT 0,
      wallet_verified INTEGER NOT NULL DEFAULT 0,
      wallet_verified_tx_hash TEXT,
      wallet_verified_at INTEGER,
      pending_referrer_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      last_ip TEXT,
      last_active_at INTEGER NOT NULL,
      created_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON users(telegram_id);
    CREATE INDEX IF NOT EXISTS idx_users_last_active ON users(last_active_at);

    CREATE TABLE IF NOT EXISTS mining_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      status TEXT NOT NULL CHECK (status IN ('running', 'paused', 'claimed')),
      daily_rate_bell INTEGER NOT NULL,
      multiplier_bps INTEGER NOT NULL DEFAULT 10000,
      started_at INTEGER NOT NULL,
      ends_at INTEGER NOT NULL,
      claimed_micro INTEGER NOT NULL DEFAULT 0 CHECK (claimed_micro >= 0),
      last_claimed_at INTEGER,
      created_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_mining_sessions_user_status ON mining_sessions(user_id, status);

    CREATE TABLE IF NOT EXISTS mining_claims (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      session_id INTEGER NOT NULL REFERENCES mining_sessions(id) ON DELETE CASCADE,
      amount_micro INTEGER NOT NULL CHECK (amount_micro > 0),
      idempotency_key TEXT NOT NULL UNIQUE,
      claimed_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_mining_claims_user ON mining_claims(user_id, claimed_at DESC);

    CREATE TABLE IF NOT EXISTS daily_rewards (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      day_number INTEGER NOT NULL CHECK (day_number BETWEEN 1 AND 7),
      claim_date_utc TEXT NOT NULL,
      amount_micro INTEGER NOT NULL CHECK (amount_micro > 0),
      claimed_at INTEGER NOT NULL,
      UNIQUE(user_id, claim_date_utc)
    );

    CREATE INDEX IF NOT EXISTS idx_daily_rewards_user ON daily_rewards(user_id, claimed_at DESC);

    CREATE TABLE IF NOT EXISTS referrals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      referrer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      referred_user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
      source TEXT NOT NULL DEFAULT 'telegram_deep_link',
      created_at INTEGER NOT NULL,
      CHECK (referrer_id != referred_user_id)
    );

    CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_id);

    CREATE TABLE IF NOT EXISTS referral_rewards (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      referral_id INTEGER NOT NULL UNIQUE REFERENCES referrals(id) ON DELETE CASCADE,
      referrer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      referred_user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
      referrer_amount_micro INTEGER NOT NULL CHECK (referrer_amount_micro >= 0),
      referred_amount_micro INTEGER NOT NULL CHECK (referred_amount_micro >= 0),
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS wallet_connections (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
      ton_address TEXT NOT NULL,
      wallet_app TEXT,
      ton_balance_nano INTEGER NOT NULL DEFAULT 0,
      bellgram_balance_micro INTEGER NOT NULL DEFAULT 0,
      is_verified_source INTEGER NOT NULL DEFAULT 0,
      connected_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS missions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      title_en TEXT NOT NULL,
      title_ar TEXT NOT NULL,
      description_en TEXT NOT NULL,
      description_ar TEXT NOT NULL,
      mission_type TEXT NOT NULL CHECK (mission_type IN ('channel', 'referral_count', 'daily_login', 'custom')),
      target_value INTEGER NOT NULL DEFAULT 1,
      channel_username TEXT,
      channel_url TEXT,
      reward_bell INTEGER NOT NULL CHECK (reward_bell > 0),
      is_active INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS mission_claims (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      mission_id INTEGER NOT NULL REFERENCES missions(id) ON DELETE CASCADE,
      status TEXT NOT NULL CHECK (status IN ('pending', 'completed')),
      reward_micro INTEGER NOT NULL CHECK (reward_micro > 0),
      claimed_at INTEGER NOT NULL,
      UNIQUE(user_id, mission_id)
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      tx_type TEXT NOT NULL,
      amount_micro INTEGER NOT NULL,
      balance_after_micro INTEGER NOT NULL,
      description TEXT NOT NULL,
      reference_id TEXT,
      created_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value_json TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'superadmin',
      created_at INTEGER NOT NULL,
      last_login_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS admin_audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      admin_actor TEXT NOT NULL,
      action TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT,
      details_json TEXT NOT NULL,
      ip_address TEXT,
      created_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_admin_audit_created ON admin_audit_logs(created_at DESC);

    CREATE TABLE IF NOT EXISTS withdrawals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      amount_micro INTEGER NOT NULL CHECK (amount_micro > 0),
      ton_address TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'rejected')),
      rejection_reason TEXT,
      tx_hash TEXT,
      reviewed_by TEXT,
      reviewed_at INTEGER,
      notified_telegram INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_withdrawals_user ON withdrawals(user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_withdrawals_status ON withdrawals(status, created_at DESC);

    CREATE TABLE IF NOT EXISTS user_ips (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      ip_address TEXT NOT NULL,
      hit_count INTEGER NOT NULL DEFAULT 1,
      first_seen_at INTEGER NOT NULL,
      last_seen_at INTEGER NOT NULL,
      UNIQUE(user_id, ip_address)
    );

    CREATE INDEX IF NOT EXISTS idx_user_ips_ip ON user_ips(ip_address);
    CREATE INDEX IF NOT EXISTS idx_user_ips_user ON user_ips(user_id, last_seen_at DESC);

    CREATE TABLE IF NOT EXISTS wallet_verifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      sender_address TEXT NOT NULL,
      recipient_address TEXT NOT NULL,
      amount_nano INTEGER NOT NULL CHECK (amount_nano > 0),
      tx_hash TEXT NOT NULL UNIQUE,
      status TEXT NOT NULL DEFAULT 'verified' CHECK (status IN ('verified')),
      verified_at INTEGER NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_wallet_verifications_user ON wallet_verifications(user_id, verified_at DESC);
  `);

  const userCols = db.prepare('PRAGMA table_info(users)').all() as Array<{ name: string }>;
  if (!userCols.some((c) => c.name === 'last_ip')) {
    db.exec('ALTER TABLE users ADD COLUMN last_ip TEXT;');
  }
  if (!userCols.some((c) => c.name === 'wallet_verified')) {
    db.exec('ALTER TABLE users ADD COLUMN wallet_verified INTEGER NOT NULL DEFAULT 0;');
  }
  if (!userCols.some((c) => c.name === 'wallet_verified_tx_hash')) {
    db.exec('ALTER TABLE users ADD COLUMN wallet_verified_tx_hash TEXT;');
  }
  if (!userCols.some((c) => c.name === 'wallet_verified_at')) {
    db.exec('ALTER TABLE users ADD COLUMN wallet_verified_at INTEGER;');
  }
  if (!userCols.some((c) => c.name === 'pending_referrer_id')) {
    db.exec('ALTER TABLE users ADD COLUMN pending_referrer_id INTEGER;');
  }
  db.exec('CREATE INDEX IF NOT EXISTS idx_users_last_ip ON users(last_ip);');
}

function seedDefaults(db: DatabaseSync): void {
  const now = Date.now();
  const upsertSetting = db.prepare(`
    INSERT OR IGNORE INTO app_settings (key, value_json, updated_at)
    VALUES (?, ?, ?)
  `);

  upsertSetting.run('mining_levels', JSON.stringify(DEFAULT_MINING_LEVELS), now);
  upsertSetting.run('daily_bonus_schedule', JSON.stringify(DEFAULT_DAILY_REWARDS), now);
  upsertSetting.run('required_channels', JSON.stringify(DEFAULT_CHANNELS), now);
  upsertSetting.run('referral_bonus_bell', JSON.stringify(50), now);
  upsertSetting.run('session_duration_hours', JSON.stringify(24), now);
  upsertSetting.run('min_claim_bell', JSON.stringify(0.0001), now);
  upsertSetting.run('min_withdraw_bell', JSON.stringify(50), now);
  upsertSetting.run('bot_username', JSON.stringify(config.botUsername), now);
  db.prepare(
    `UPDATE app_settings
     SET value_json = ?, updated_at = ?
     WHERE key = 'bot_username' AND value_json = '"bellgram_bot"'`
  ).run(JSON.stringify(config.botUsername), now);

  const insertMission = db.prepare(`
    INSERT OR IGNORE INTO missions (
      code, title_en, title_ar, description_en, description_ar,
      mission_type, target_value, channel_username, channel_url,
      reward_bell, is_active, sort_order, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
  `);

  insertMission.run(
    'join_official',
    'Subscribe to BELLGRAM Official',
    'الاشتراك في قناة BELLGRAM الرسمية',
    'Join our official announcement channel and verify membership.',
    'اشترك في قناة الإعلانات الرسمية وتحقق من العضوية.',
    'channel',
    1,
    'bellgram_official',
    'https://t.me/bellgram_official',
    25,
    1,
    now
  );

  insertMission.run(
    'daily_checkin_1',
    'Claim Today’s Daily Bonus',
    'استلام المكافأة اليومية اليوم',
    'Claim your Daily Login streak bonus on the Home screen.',
    'قم بالمطالبة بمكافأة تسجيل الدخول اليومية من الرئيسية.',
    'daily_login',
    1,
    null,
    null,
    15,
    2,
    now
  );

  insertMission.run(
    'invite_1_friend',
    'Invite 1 Friend to BELLGRAM',
    'دعوة صديق واحد إلى BELLGRAM',
    'Share your referral link and get 1 friend to join.',
    'شارك رابط الدعوة الخاص بك وانضم صديق واحد.',
    'referral_count',
    1,
    null,
    null,
    30,
    3,
    now
  );

  insertMission.run(
    'invite_3_friends',
    'Invite 3 Friends to BELLGRAM',
    'دعوة 3 أصدقاء إلى BELLGRAM',
    'Grow your mining network to 3 verified direct friends.',
    'وسّع شبكة التعدين الخاصة بك إلى 3 أصدقاء مباشرين.',
    'referral_count',
    3,
    null,
    null,
    100,
    4,
    now
  );
}

export function getSetting<T>(key: string, fallback: T): T {
  const db = getDb();
  const row = db.prepare('SELECT value_json FROM app_settings WHERE key = ?').get(key) as
    | { value_json: string }
    | undefined;
  if (!row) return fallback;
  try {
    return JSON.parse(row.value_json) as T;
  } catch {
    return fallback;
  }
}

export function setSetting(key: string, value: unknown): void {
  const db = getDb();
  db.prepare(`
    INSERT INTO app_settings (key, value_json, updated_at)
    VALUES (?, ?, ?)
    ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json, updated_at = excluded.updated_at
  `).run(key, JSON.stringify(value), Date.now());
}

export function runInTransaction<T>(fn: (db: DatabaseSync) => T): T {
  const db = getDb();
  db.exec('BEGIN IMMEDIATE;');
  try {
    const result = fn(db);
    db.exec('COMMIT;');
    return result;
  } catch (err) {
    try {
      db.exec('ROLLBACK;');
    } catch {
      // ignore rollback error
    }
    throw err;
  }
}
