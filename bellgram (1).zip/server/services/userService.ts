import crypto from 'node:crypto';
import { getDb, getSetting, runInTransaction, DEFAULT_MINING_LEVELS } from '../db.ts';
import { config } from '../config.ts';
import {
  bellToMicro,
  computeAccruedMicro,
  computeDailyStreakState,
  getUtcDateString,
  resolveLevelForBellgram,
} from '../../src/lib/bellMath.ts';
import { verifyTelegramInitData, checkTelegramChannelMembership } from '../telegramAuth.ts';
import { normalizeIpAddress } from '../ipUtils.ts';
import { capturePendingReferral, getFriendsSummary } from './referralService.ts';
import { getUserMissions } from './missionService.ts';
import { getUserWithdrawals } from './withdrawService.ts';
import { syncMiningSessionRateForUser } from './miningService.ts';
import type {
  BootstrapPayload,
  ChannelConfig,
  ChannelStatus,
  MiningLevel,
  TransactionItem,
} from '../../src/types.ts';

export interface DbUserRow {
  id: number;
  telegram_id: string;
  username: string | null;
  first_name: string;
  last_name: string | null;
  language_code: string;
  balance_micro: number;
  total_mined_micro: number;
  ton_balance_nano: number;
  bellgram_balance_micro: number;
  level_id: number;
  boost_bps: number;
  channels_verified: number;
  joined_channel_ids_json: string;
  is_banned: number;
  is_preview: number;
  wallet_verified: number;
  wallet_verified_tx_hash: string | null;
  wallet_verified_at: number | null;
  pending_referrer_id: number | null;
  last_ip: string | null;
  last_active_at: number;
  created_at: number;
}

export function resolveAuthenticatedUser(
  initDataHeader: string | undefined,
  clientIpRaw?: string | string[] | null
): {
  user: DbUserRow | null;
  error?: string;
  status?: number;
} {
  const initData = (initDataHeader || '').trim();
  const now = Date.now();

  if (initData) {
    if (!config.botToken) {
      return {
        user: null,
        error: 'Server BOT_TOKEN is not configured to verify Telegram initData.',
        status: 503,
      };
    }

    const verified = verifyTelegramInitData(initData, config.botToken);
    if (!verified) {
      return {
        user: null,
        error: 'Invalid or expired Telegram initData signature.',
        status: 401,
      };
    }

    const telegramIdStr = String(verified.id);
    const user = upsertTelegramUser({
      telegramId: telegramIdStr,
      username: verified.username,
      firstName: verified.firstName,
      lastName: verified.lastName,
      languageCode: verified.languageCode,
      startParam: verified.startParam,
      isPreview: false,
      clientIp: clientIpRaw,
      now,
    });

    if (user.is_banned) {
      return { user: null, error: 'This account has been suspended.', status: 403 };
    }
    return { user };
  }

  if (!config.allowPreviewAuth) {
    return {
      user: null,
      error: 'Open this application inside Telegram to authenticate.',
      status: 401,
    };
  }

  // Deterministic preview account when viewed outside Telegram
  const user = upsertTelegramUser({
    telegramId: 'preview_user_1',
    username: 'preview_miner',
    firstName: 'Preview',
    lastName: null,
    languageCode: 'en',
    startParam: null,
    isPreview: true,
    clientIp: clientIpRaw,
    now,
  });

  if (user.is_banned) {
    return { user: null, error: 'This account has been suspended.', status: 403 };
  }
  return { user };
}

export function upsertTelegramUser(params: {
  telegramId: string;
  username: string | null;
  firstName: string;
  lastName: string | null;
  languageCode: string;
  startParam: string | null;
  isPreview: boolean;
  clientIp?: string | string[] | null;
  now: number;
}): DbUserRow {
  const normalizedIp = normalizeIpAddress(params.clientIp);

  return runInTransaction((db) => {
    const existing = db
      .prepare('SELECT * FROM users WHERE telegram_id = ?')
      .get(params.telegramId) as DbUserRow | undefined;

    let userId: number;
    if (existing) {
      db.prepare(
        `UPDATE users
         SET username = COALESCE(?, username),
             first_name = ?,
             last_name = ?,
             last_ip = COALESCE(?, last_ip),
             last_active_at = ?
         WHERE id = ?`
      ).run(
        params.username,
        params.firstName,
        params.lastName,
        normalizedIp,
        params.now,
        existing.id
      );
      userId = existing.id;
    } else {
      const res = db
        .prepare(
          `INSERT INTO users (
            telegram_id, username, first_name, last_name, language_code,
            balance_micro, total_mined_micro, ton_balance_nano, bellgram_balance_micro,
            level_id, boost_bps, channels_verified, joined_channel_ids_json,
            is_banned, is_preview, last_ip, last_active_at, created_at
          ) VALUES (?, ?, ?, ?, ?, 0, 0, 0, 0, 0, 10000, 0, '[]', 0, ?, ?, ?, ?)`
        )
        .run(
          params.telegramId,
          params.username,
          params.firstName,
          params.lastName,
          params.languageCode,
          params.isPreview ? 1 : 0,
          normalizedIp,
          params.now,
          params.now
        );

      userId = Number(res.lastInsertRowid);

      if (params.startParam && !params.isPreview) {
        capturePendingReferral(db, userId, params.startParam);
      }
    }

    if (normalizedIp) {
      db.prepare(
        `INSERT INTO user_ips (user_id, ip_address, hit_count, first_seen_at, last_seen_at)
         VALUES (?, ?, 1, ?, ?)
         ON CONFLICT(user_id, ip_address) DO UPDATE SET
           hit_count = user_ips.hit_count + 1,
           last_seen_at = excluded.last_seen_at`
      ).run(userId, normalizedIp, params.now, params.now);
    }

    return db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as unknown as DbUserRow;
  });
}

export function markChannelJoinIntent(userId: number, channelId: string): string[] {
  const channels = getSetting<ChannelConfig[]>('required_channels', []);
  const target = channels.find((c) => c.id === channelId);
  if (!target) {
    throw new Error('Channel not found');
  }

  return runInTransaction((db) => {
    const row = db
      .prepare('SELECT joined_channel_ids_json, telegram_id, is_preview FROM users WHERE id = ?')
      .get(userId) as
      | { joined_channel_ids_json: string; telegram_id: string; is_preview: number }
      | undefined;
    let list: string[] = [];
    try {
      list = JSON.parse(row?.joined_channel_ids_json || '[]') as string[];
    } catch {
      list = [];
    }

    const hasRealBotAndTelegramUser =
      Boolean(config.botToken) && row && !row.is_preview && /^\d+$/.test(row.telegram_id);

    // Only treat Join tap as joined in preview mode (without live Bot API).
    // In live Telegram mode, green Joined status comes strictly from Telegram getChatMember verification.
    if (!hasRealBotAndTelegramUser && !list.includes(channelId)) {
      list.push(channelId);
      db.prepare('UPDATE users SET joined_channel_ids_json = ? WHERE id = ?').run(
        JSON.stringify(list),
        userId
      );
    }
    return list;
  });
}

export async function verifyRequiredChannels(userId: number): Promise<{
  verified: boolean;
  channels: ChannelStatus[];
  message?: string;
}> {
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as DbUserRow | undefined;
  if (!user) throw new Error('User not found');

  const channels = getSetting<ChannelConfig[]>('required_channels', []);
  let joinedIds: string[] = [];
  try {
    joinedIds = JSON.parse(user.joined_channel_ids_json || '[]') as string[];
  } catch {
    joinedIds = [];
  }

  const apiErrors: string[] = [];
  const hasRealBotAndTelegramUser =
    Boolean(config.botToken) && !user.is_preview && /^\d+$/.test(user.telegram_id);

  let hasTransientNetworkError = false;
  let hasDefinitiveNotMember = false;

  const statuses: ChannelStatus[] = await Promise.all(
    channels.map(async (ch) => {
      let joined = false;
      if (hasRealBotAndTelegramUser) {
        const check = await checkTelegramChannelMembership(
          config.botToken,
          ch.username,
          Number(user.telegram_id)
        );
        joined = check.ok && check.isMember;
        if (check.ok && !check.isMember && ch.isRequired) {
          hasDefinitiveNotMember = true;
        }
        if (!check.ok && ch.isRequired) {
          if (check.reason === 'telegram_network_error') {
            hasTransientNetworkError = true;
          }
          const label = ch.username.startsWith('-') ? ch.title : `@${ch.username.replace(/^@/, '')}`;
          if (
            check.reason?.toLowerCase().includes('inaccessible') ||
            check.reason?.toLowerCase().includes('administrator')
          ) {
            apiErrors.push(`${label}: add bot as Admin in channel`);
          } else if (check.reason?.toLowerCase().includes('chat not found')) {
            apiErrors.push(`${label}: channel not found (check username in /admin)`);
          } else if (check.reason) {
            apiErrors.push(`${label}: ${check.reason}`);
          }
        }
      } else {
        // In preview mode (no BOT_TOKEN or non-Telegram browser), require explicit Join tap per channel
        joined = joinedIds.includes(ch.id);
      }
      return { ...ch, joined };
    })
  );

  if (hasRealBotAndTelegramUser) {
    const verifiedIds = statuses.filter((s) => s.joined).map((s) => s.id);
    db.prepare('UPDATE users SET joined_channel_ids_json = ? WHERE id = ?').run(
      JSON.stringify(verifiedIds),
      userId
    );
  }

  const allRequiredJoined = statuses.filter((c) => c.isRequired).every((c) => c.joined);

  if (allRequiredJoined) {
    runInTransaction((txDb) => {
      txDb.prepare('UPDATE users SET channels_verified = 1 WHERE id = ?').run(userId);
      // Ensure an active 24h mining session starts immediately upon channel verification
      const activeSession = txDb
        .prepare("SELECT id FROM mining_sessions WHERE user_id = ? AND status = 'running' LIMIT 1")
        .get(userId);
      if (!activeSession) {
        const levels = getSetting<MiningLevel[]>('mining_levels', DEFAULT_MINING_LEVELS);
        const { current } = resolveLevelForBellgram(user.bellgram_balance_micro, levels);
        const durationHours = getSetting<number>('session_duration_hours', 24);
        const now = Date.now();
        const endsAt = now + durationHours * 3600 * 1000;
        txDb
          .prepare(
            `INSERT INTO mining_sessions (
              user_id, status, daily_rate_bell, multiplier_bps, started_at, ends_at, claimed_micro, created_at
            ) VALUES (?, 'running', ?, ?, ?, ?, 0, ?)`
          )
          .run(userId, current.dailyBell, user.boost_bps, now, endsAt, now);
      }
    });
  } else if (
    hasRealBotAndTelegramUser &&
    user.channels_verified === 1 &&
    (hasDefinitiveNotMember || !hasTransientNetworkError)
  ) {
    // User left a required channel (or no longer passes membership check): require re-subscribing
    db.prepare('UPDATE users SET channels_verified = 0 WHERE id = ?').run(userId);
  }

  let message: string | undefined;
  if (!allRequiredJoined) {
    if (apiErrors.length > 0) {
      message = `Telegram check issue (${apiErrors.join(' · ')})`;
    } else if (hasRealBotAndTelegramUser) {
      message = 'Please join all required channels first, then check again.';
    } else {
      message = 'Tap Join on each required channel first, then press check.';
    }
  }

  return {
    verified: allRequiredJoined,
    channels: statuses,
    message,
  };
}

export async function syncLiveChannelsOnEntry(userId: number): Promise<void> {
  if (!config.botToken) return;
  const db = getDb();
  const row = db
    .prepare('SELECT telegram_id, is_preview FROM users WHERE id = ?')
    .get(userId) as { telegram_id: string; is_preview: number } | undefined;
  if (!row || row.is_preview || !/^\d+$/.test(row.telegram_id)) return;
  try {
    await verifyRequiredChannels(userId);
  } catch {
    // Non-fatal background check failure
  }
}

export function isTelegramUsernameAdmin(username: string | null | undefined, isPreview: boolean): boolean {
  if (isPreview || !username) return false;
  const normalized = username.trim().replace(/^@/, '').toLowerCase();
  return config.adminTelegramUsernames.includes(normalized);
}

export function buildBootstrapPayload(userId: number): BootstrapPayload {
  const db = getDb();
  let user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as unknown as DbUserRow;

  const levels = getSetting<MiningLevel[]>('mining_levels', DEFAULT_MINING_LEVELS);
  const dailySchedule = getSetting<number[]>('daily_bonus_schedule', [10, 15, 20, 30, 45, 65, 100]);
  const channels = getSetting<ChannelConfig[]>('required_channels', []);
  const sessionDurationHours = getSetting<number>('session_duration_hours', 24);
  const minClaimBell = getSetting<number>('min_claim_bell', 0.0001);
  const minWithdrawBell = getSetting<number>('min_withdraw_bell', 50);
  const referralBonusBell = getSetting<number>('referral_bonus_bell', 50);
  const botUsername = getSetting<string>('bot_username', config.botUsername);

  const { current: currentLevel, next: nextLevel } = resolveLevelForBellgram(
    user.bellgram_balance_micro,
    levels
  );

  // Sync user's level_id if changed
  if (user.level_id !== currentLevel.level) {
    db.prepare('UPDATE users SET level_id = ? WHERE id = ?').run(currentLevel.level, user.id);
    user.level_id = currentLevel.level;
  }

  const hasRequiredChannels = channels.some((c) => c.isRequired);
  if (!hasRequiredChannels && user.channels_verified === 0) {
    db.prepare('UPDATE users SET channels_verified = 1 WHERE id = ?').run(user.id);
    user.channels_verified = 1;
  }

  if (user.channels_verified === 1) {
    const rateChanged = syncMiningSessionRateForUser(user.id, currentLevel.dailyBell);
    if (rateChanged) {
      user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as unknown as DbUserRow;
    }
  }

  const nowMs = Date.now();

  // Auto-ensure running session if user is verified and has no active session
  let session = db
    .prepare("SELECT * FROM mining_sessions WHERE user_id = ? AND status IN ('running', 'paused') ORDER BY id DESC LIMIT 1")
    .get(user.id) as
    | {
        id: number;
        status: 'running' | 'paused';
        daily_rate_bell: number;
        multiplier_bps: number;
        started_at: number;
        ends_at: number;
        claimed_micro: number;
      }
    | undefined;

  if (!session && user.channels_verified === 1) {
    const endsAt = nowMs + sessionDurationHours * 3600 * 1000;
    const insertRes = db
      .prepare(
        `INSERT INTO mining_sessions (
          user_id, status, daily_rate_bell, multiplier_bps, started_at, ends_at, claimed_micro, created_at
        ) VALUES (?, 'running', ?, ?, ?, ?, 0, ?)`
      )
      .run(user.id, currentLevel.dailyBell, user.boost_bps, nowMs, endsAt, nowMs);
    session = {
      id: Number(insertRes.lastInsertRowid),
      status: 'running',
      daily_rate_bell: currentLevel.dailyBell,
      multiplier_bps: user.boost_bps,
      started_at: nowMs,
      ends_at: endsAt,
      claimed_micro: 0,
    };
  }

  const sessionDurationSec = Math.max(60, Math.round(sessionDurationHours * 3600));
  const accrual = session
    ? computeAccruedMicro({
        dailyRateBell: session.daily_rate_bell,
        multiplierBps: session.multiplier_bps,
        startedAtMs: session.started_at,
        nowMs,
        sessionDurationSec,
        alreadyClaimedMicro: session.claimed_micro,
        status: session.status,
      })
    : { accruedMicro: 0, remainingSec: 0, progressPct: 0, isExpired: false };

  const effectiveDailyRate = session ? session.daily_rate_bell : currentLevel.dailyBell;
  const effectiveMultiplierBps = session ? session.multiplier_bps : user.boost_bps;
  const hourlyRateBell = Number(
    (((effectiveDailyRate * (effectiveMultiplierBps / 10000)) / 24)).toFixed(2)
  );

  // Daily login streak
  const lastDaily = db
    .prepare('SELECT day_number, claim_date_utc FROM daily_rewards WHERE user_id = ? ORDER BY id DESC LIMIT 1')
    .get(user.id) as { day_number: number; claim_date_utc: string } | undefined;

  const todayUtc = getUtcDateString(nowMs);
  const dailyComp = computeDailyStreakState(
    lastDaily?.claim_date_utc ?? null,
    lastDaily?.day_number ?? 0,
    todayUtc,
    dailySchedule
  );

  // Channels status
  let joinedChannelIds: string[] = [];
  try {
    joinedChannelIds = JSON.parse(user.joined_channel_ids_json || '[]') as string[];
  } catch {
    joinedChannelIds = [];
  }
  const channelStatuses: ChannelStatus[] = channels.map((ch) => ({
    ...ch,
    joined: user.channels_verified === 1 || joinedChannelIds.includes(ch.id),
  }));

  // Wallet info
  const walletRow = db
    .prepare('SELECT * FROM wallet_connections WHERE user_id = ?')
    .get(user.id) as
    | {
        ton_address: string;
        wallet_app: string | null;
        ton_balance_nano: number;
        bellgram_balance_micro: number;
        is_verified_source: number;
      }
    | undefined;

  const contractConfigured = Boolean(config.bellgramJettonMaster);
  const disclosureNote = contractConfigured
    ? 'Balances read from verified TON Jetton contract. BELL app points are off-chain rewards.'
    : 'No official BELLGRAM Jetton smart contract is configured yet. App BELL is an off-chain reward balance (not tradable on-chain).';

  // Transactions
  const txRows = db
    .prepare(
      `SELECT id, tx_type, amount_micro, balance_after_micro, description, created_at
       FROM transactions WHERE user_id = ? ORDER BY id DESC LIMIT 30`
    )
    .all(user.id) as Array<{
    id: number;
    tx_type: string;
    amount_micro: number;
    balance_after_micro: number;
    description: string;
    created_at: number;
  }>;

  const transactions: TransactionItem[] = txRows.map((t) => ({
    id: t.id,
    txType: t.tx_type,
    amountMicro: t.amount_micro,
    balanceAfterMicro: t.balance_after_micro,
    description: t.description,
    createdAt: new Date(t.created_at).toISOString(),
  }));

  return {
    user: {
      id: user.id,
      telegramId: user.telegram_id,
      username: user.username,
      firstName: user.first_name,
      lastName: user.last_name,
      balanceMicro: user.balance_micro,
      totalMinedMicro: user.total_mined_micro,
      level: currentLevel,
      nextLevel,
      boostBps: user.boost_bps,
      channelsVerified: user.channels_verified === 1,
      isBanned: user.is_banned === 1,
      isPreviewMode: user.is_preview === 1,
      isAdmin: isTelegramUsernameAdmin(user.username, user.is_preview === 1),
    },
    mining: {
      id: session?.id ?? null,
      status: session ? (accrual.isExpired ? 'paused' : session.status) : 'idle',
      dailyRateBell: effectiveDailyRate,
      hourlyRateBell,
      multiplierBps: effectiveMultiplierBps,
      startedAtMs: session?.started_at ?? nowMs,
      endsAtMs: session?.ends_at ?? nowMs,
      serverNowMs: nowMs,
      accruedMicro: accrual.accruedMicro,
      claimedMicro: session?.claimed_micro ?? 0,
      remainingSec: accrual.remainingSec,
      progressPct: accrual.progressPct,
      isExpired: accrual.isExpired,
      minClaimBell,
    },
    daily: {
      canClaim: dailyComp.canClaim,
      currentDayIndex: dailyComp.nextDayIndex,
      todayRewardBell: dailyComp.rewardBell,
      rewardsSchedule: dailySchedule,
      lastClaimDateUtc: lastDaily?.claim_date_utc ?? null,
      streakBroken: dailyComp.streakBroken,
    },
    wallet: {
      connected: Boolean(walletRow),
      tonAddress: walletRow?.ton_address ?? null,
      walletApp: walletRow?.wallet_app ?? null,
      tonBalanceNano: walletRow?.ton_balance_nano ?? user.ton_balance_nano,
      bellgramBalanceMicro: walletRow?.bellgram_balance_micro ?? user.bellgram_balance_micro,
      isVerifiedSource: Boolean(walletRow?.is_verified_source),
      contractConfigured,
      disclosureNote,
      walletVerified: user.wallet_verified === 1,
      walletVerifiedAt: user.wallet_verified_at
        ? new Date(user.wallet_verified_at).toISOString()
        : null,
      walletVerifiedTxHash: user.wallet_verified_tx_hash ?? null,
      verificationRecipientAddress: config.walletVerifyAddress,
      verificationAmountNano: config.walletVerifyAmountNano,
    },
    levels,
    channels: channelStatuses,
    missions: getUserMissions(user.id),
    friends: getFriendsSummary(user.id),
    transactions,
    withdrawals: getUserWithdrawals(user.id),
    settings: {
      botUsername,
      sessionDurationHours,
      minClaimBell,
      minWithdrawBell,
      referralBonusBell,
    },
  };
}

export function generateIdempotencyKey(prefix: string): string {
  return `${prefix}_${crypto.randomUUID()}`;
}

export { bellToMicro };
