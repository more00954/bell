import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

// Point DB_PATH to an isolated temp database before importing DB/services
const tmpDb = path.join(os.tmpdir(), `bellgram-test-${Date.now()}-${Math.random()}.db`);
process.env.DB_PATH = tmpDb;
process.env.ALLOW_PREVIEW_AUTH = 'true';

const { getDb, runInTransaction } = await import('../db.ts');
const { config } = await import('../config.ts');
const { normalizeIpAddress, getIpSubnetPrefix } = await import('../ipUtils.ts');
const {
  resolveAuthenticatedUser,
  markChannelJoinIntent,
  verifyRequiredChannels,
  syncLiveChannelsOnEntry,
  buildBootstrapPayload,
  isTelegramUsernameAdmin,
  upsertTelegramUser,
} = await import('./userService.ts');
const { claimMiningReward } = await import('./miningService.ts');
const { claimDailyBonus } = await import('./rewardsService.ts');
const { applyVerifiedReferral, getFriendsSummary } = await import('./referralService.ts');
const { claimMissionReward, getUserMissions } = await import('./missionService.ts');
const {
  getAdminAuthStatus,
  bootstrapFirstAdmin,
  authenticateAdmin,
  adminChangePassword,
  verifyAdminToken,
  adminExportUsersCsv,
  adminUpdateChannels,
  getAdminDashboardData,
  adminAdjustUserBalance,
  adminCreateMission,
  adminDeleteMission,
  adminExportFullDatabaseJson,
  adminCreateSqliteBackupBuffer,
} = await import('./adminService.ts');
const { requestWithdrawal, reviewWithdrawal, getUserWithdrawals } = await import(
  './withdrawService.ts'
);
const {
  getWebhookSecretToken,
  verifyWebhookSecretHeader,
  handleTelegramWebhookUpdate,
  isPublicWebhookHost,
  notePublicRequestOrigin,
} = await import('./telegramBotService.ts');
const {
  convertJettonUnitsToMicro,
  connectTonWallet,
  refreshConnectedWalletBalance,
  normalizeTonAddressToRaw,
  confirmWalletVerification,
} = await import('./walletService.ts');

test.after(() => {
  for (const suffix of ['', '-wal', '-shm']) {
    if (fs.existsSync(tmpDb + suffix)) {
      try {
        fs.unlinkSync(tmpDb + suffix);
      } catch {
        // ignore cleanup errors
      }
    }
  }
});

test('channel verification unlocks mining session and prevents double claim on same session', async () => {
  const { user } = resolveAuthenticatedUser(undefined);
  assert.ok(user);
  assert.equal(user.channels_verified, 0);

  markChannelJoinIntent(user.id, 'official');
  markChannelJoinIntent(user.id, 'community');
  const ver = await verifyRequiredChannels(user.id);
  assert.equal(ver.verified, true);

  // Backdate session start by 2 hours so > 0.0001 BELL accrues deterministically
  const db = getDb();
  const twoHoursAgo = Date.now() - 2 * 3600 * 1000;
  db.prepare('UPDATE mining_sessions SET started_at = ? WHERE user_id = ?').run(
    twoHoursAgo,
    user.id
  );

  const claim1 = claimMiningReward(user.id, 'idem-key-1');
  assert.ok(claim1.claimedMicro > 400_000); // ~41.66 BELL
  assert.equal(claim1.newBalanceMicro, claim1.claimedMicro);

  // Immediately claiming the brand new session (0 elapsed) rejects below minClaim
  assert.throws(() => claimMiningReward(user.id, 'idem-key-1'), /Minimum claim/);
});

test('daily login bonus awards Day 1/7 and blocks duplicate claim same UTC day', () => {
  const { user } = resolveAuthenticatedUser(undefined);
  assert.ok(user);

  const res = claimDailyBonus(user.id);
  assert.equal(res.dayNumber, 1);
  assert.equal(res.rewardMicro, 100_000); // 10 BELL

  assert.throws(() => claimDailyBonus(user.id), /already claimed/i);
});

test('referral is not counted or credited until invited user verifies wallet, blocks self-referral, and unlocks referral mission', async () => {
  const db = getDb();
  const { user: referrer } = resolveAuthenticatedUser(undefined);
  assert.ok(referrer);

  const referrerBeforeBal = buildBootstrapPayload(referrer.id).user.balanceMicro;

  const now = Date.now();
  const friendTgId = '777888999';
  const friendUser = upsertTelegramUser({
    telegramId: friendTgId,
    username: 'friend_one',
    firstName: 'Friend',
    lastName: null,
    languageCode: 'en',
    startParam: `ref_${referrer.telegram_id}`,
    isPreview: false,
    now,
  });
  const newUserId = friendUser.id;
  assert.equal(friendUser.pending_referrer_id, referrer.id);

  // Before wallet verification: referral is NOT counted yet and balances do not increase,
  // while the invited friend appears in the list with walletVerified = false
  const preFriends = getFriendsSummary(referrer.id);
  assert.equal(preFriends.friendsCount, 0);
  assert.equal(preFriends.friends.length, 1);
  assert.equal(preFriends.friends[0].id, newUserId);
  assert.equal(preFriends.friends[0].walletVerified, false);
  assert.equal(preFriends.friends[0].bonusBell, 0);
  const preVerifyPayload = buildBootstrapPayload(referrer.id);
  const preVerifyMission = preVerifyPayload.missions.find((m) => m.code === 'invite_1_friend');
  assert.equal(preVerifyMission?.canClaim, false);
  assert.equal(preVerifyPayload.user.balanceMicro, referrerBeforeBal);
  assert.equal(buildBootstrapPayload(newUserId).user.balanceMicro, 0);

  // Self-referral blocked
  const selfApplied = runInTransaction((tx) =>
    applyVerifiedReferral(tx, referrer.id, `ref_${referrer.telegram_id}`, now)
  );
  assert.equal(selfApplied, false);

  // Complete 0.05 TON wallet verification for the invited friend -> referral counts & credits both
  const friendWallet = 'UQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJKZ';
  const friendRaw = '0:0000000000000000000000000000000000000000000000000000000000000000';
  const verifyRaw = '0:50613b5b3b8d45f834bab645652c0077cdd5c2018b748934a147e79df0455d54';
  const prevFetch = globalThis.fetch;
  try {
    globalThis.fetch = (async (input: string | URL | Request) => {
      const url = String(input);
      if (url.includes('getAddressBalance')) {
        return new Response(JSON.stringify({ ok: true, result: '100000000' }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        });
      }
      if (url.includes('/v3/jetton/wallets')) {
        return new Response(JSON.stringify({ jetton_wallets: [] }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        });
      }
      if (url.includes('/v3/transactions')) {
        return new Response(
          JSON.stringify({
            transactions: [
              {
                hash: 'tx_referral_verify_friend_1',
                description: { aborted: false },
                in_msg: { source: friendRaw, destination: verifyRaw, value: '50000000' },
              },
            ],
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }
      return new Response('{}', { status: 404 });
    }) as typeof fetch;

    await connectTonWallet(newUserId, friendWallet, 'Tonkeeper');
    const verRes = await confirmWalletVerification(newUserId);
    assert.equal(verRes.verified, true);
  } finally {
    globalThis.fetch = prevFetch;
  }

  const friends = getFriendsSummary(referrer.id);
  assert.equal(friends.friendsCount, 1);
  assert.equal(friends.friends.length, 1);
  assert.equal(friends.friends[0].walletVerified, true);
  assert.equal(friends.friends[0].bonusBell, 50);
  assert.equal(buildBootstrapPayload(referrer.id).user.balanceMicro, referrerBeforeBal + 500_000); // +50 BELL
  assert.equal(buildBootstrapPayload(newUserId).user.balanceMicro, 500_000); // +50 BELL
  const friendAfterRow = db
    .prepare('SELECT pending_referrer_id FROM users WHERE id = ?')
    .get(newUserId) as { pending_referrer_id: number | null };
  assert.equal(friendAfterRow.pending_referrer_id, null);

  // Duplicate referral blocked even after verification
  const duplicate = runInTransaction((tx) =>
    applyVerifiedReferral(tx, newUserId, `ref_${referrer.telegram_id}`, now)
  );
  assert.equal(duplicate, false);

  // Claim "invite_1_friend" mission (reward 30 BELL) and block second claim
  const payload = buildBootstrapPayload(referrer.id);
  const invite1 = payload.missions.find((m) => m.code === 'invite_1_friend');
  assert.ok(invite1);
  assert.equal(invite1.canClaim, true);

  const missionClaim = await claimMissionReward(referrer.id, invite1.id);
  assert.equal(missionClaim.rewardMicro, 300_000);
  await assert.rejects(() => claimMissionReward(referrer.id, invite1.id), /already claimed/i);
});

test('admin bootstrap, login, token verification, and CSV export work securely', () => {
  const status1 = getAdminAuthStatus();
  assert.equal(status1.needsSetup, true);

  const token = bootstrapFirstAdmin('StrongAdminPass123!');
  assert.ok(verifyAdminToken(`Bearer ${token}`));

  assert.throws(() => bootstrapFirstAdmin('AnotherPass123!'), /already been claimed/i);
  assert.throws(() => authenticateAdmin('WrongPassword'), /Invalid admin password/i);

  const loginToken = authenticateAdmin('StrongAdminPass123!');
  assert.ok(verifyAdminToken(`Bearer ${loginToken}`));

  assert.throws(
    () => adminChangePassword('admin', 'WrongCurrent', 'NewStrongPass99!'),
    /Current password is incorrect/i
  );
  assert.throws(
    () => adminChangePassword('admin', 'StrongAdminPass123!', 'short'),
    /between 8 and 128/i
  );
  adminChangePassword('admin', 'StrongAdminPass123!', 'NewStrongPass99!');
  assert.throws(() => authenticateAdmin('StrongAdminPass123!'), /Invalid admin password/i);
  const rotatedToken = authenticateAdmin('NewStrongPass99!');
  assert.ok(verifyAdminToken(`Bearer ${rotatedToken}`));

  const csv = adminExportUsersCsv('admin');
  assert.ok(csv.includes('telegram_id,username,first_name'));
  assert.ok(csv.includes('preview_user_1'));
});

test('admin button allowlist permits only @ex_zain and @g_h_o_s_t_14 on real Telegram sessions', () => {
  assert.equal(isTelegramUsernameAdmin('ex_zain', false), true);
  assert.equal(isTelegramUsernameAdmin('@EX_ZAIN', false), true);
  assert.equal(isTelegramUsernameAdmin('g_h_o_s_t_14', false), true);
  assert.equal(isTelegramUsernameAdmin('@G_H_O_S_T_14', false), true);

  assert.equal(isTelegramUsernameAdmin('ex_zain', true), false);
  assert.equal(isTelegramUsernameAdmin('g_h_o_s_t_14', true), false);
  assert.equal(isTelegramUsernameAdmin('preview_miner', true), false);
  assert.equal(isTelegramUsernameAdmin('random_user', false), false);
  assert.equal(isTelegramUsernameAdmin(null, false), false);
  assert.equal(isTelegramUsernameAdmin('', false), false);

  const { user: previewUser } = resolveAuthenticatedUser(undefined);
  assert.ok(previewUser);
  assert.equal(buildBootstrapPayload(previewUser.id).user.isAdmin, false);

  const db = getDb();
  const now = Date.now();
  const res = db
    .prepare(
      `INSERT INTO users (
        telegram_id, username, first_name, last_name, language_code,
        balance_micro, total_mined_micro, ton_balance_nano, bellgram_balance_micro,
        level_id, boost_bps, channels_verified, joined_channel_ids_json,
        is_banned, is_preview, last_active_at, created_at
      ) VALUES ('99112233', 'ex_zain', 'Zain', NULL, 'ar', 0, 0, 0, 0, 0, 10000, 1, '[]', 0, 0, ?, ?)`
    )
    .run(now, now);
  assert.equal(buildBootstrapPayload(Number(res.lastInsertRowid)).user.isAdmin, true);
});

test('withdrawal request deducts balance atomically and admin reject refunds with reason', async () => {
  const db = getDb();
  const now = Date.now();
  const validTon = 'EQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM9c';
  const ins = db
    .prepare(
      `INSERT INTO users (
        telegram_id, username, first_name, last_name, language_code,
        balance_micro, total_mined_micro, ton_balance_nano, bellgram_balance_micro,
        level_id, boost_bps, channels_verified, joined_channel_ids_json,
        is_banned, is_preview, wallet_verified, last_active_at, created_at
      ) VALUES ('55443322', 'withdraw_tester', 'Tariq', NULL, 'ar', 2000000, 2000000, 0, 0, 0, 10000, 1, '[]', 0, 0, 1, ?, ?)`
    )
    .run(now, now);
  const userId = Number(ins.lastInsertRowid); // 200.0000 BELL

  // Rejects below min withdraw (50 BELL)
  await assert.rejects(() => requestWithdrawal(userId, 10, validTon), /Minimum withdrawal/);
  // Rejects invalid TON address
  await assert.rejects(() => requestWithdrawal(userId, 60, 'invalid_addr'), /valid TON/);
  // Rejects overdraw
  await assert.rejects(() => requestWithdrawal(userId, 500, validTon), /Insufficient BELL/);

  // Valid withdrawal 1: 80 BELL -> balance drops to 120 BELL
  const w1 = await requestWithdrawal(userId, 80, validTon);
  assert.equal(w1.status, 'pending');
  assert.equal(w1.amountMicro, 800_000);
  assert.equal(buildBootstrapPayload(userId).user.balanceMicro, 1_200_000);

  // Reject without reason fails
  await assert.rejects(
    () => reviewWithdrawal('admin', w1.id, 'rejected', { reason: '' }),
    /provide a reason/i
  );

  // Reject with reason refunds 80 BELL back to 200 BELL
  const rej = await reviewWithdrawal('admin', w1.id, 'rejected', {
    reason: 'Wallet address needs memo',
  });
  assert.equal(rej.status, 'rejected');
  assert.equal(buildBootstrapPayload(userId).user.balanceMicro, 2_000_000);
  const history1 = getUserWithdrawals(userId);
  assert.equal(history1[0].status, 'rejected');
  assert.equal(history1[0].rejectionReason, 'Wallet address needs memo');

  // Cannot re-process an already reviewed withdrawal
  await assert.rejects(
    () => reviewWithdrawal('admin', w1.id, 'completed', {}),
    /already been processed/i
  );

  // Valid withdrawal 2: 60 BELL completed
  const w2 = await requestWithdrawal(userId, 60, validTon);
  const comp = await reviewWithdrawal('admin', w2.id, 'completed', { txHash: 'ton_tx_999' });
  assert.equal(comp.status, 'completed');
  assert.equal(buildBootstrapPayload(userId).user.balanceMicro, 1_400_000);
  const history2 = getUserWithdrawals(userId);
  assert.equal(history2[0].status, 'completed');
  assert.equal(history2[0].txHash, 'ton_tx_999');
});

test('telegram bot webhook /start registers user and rejects invalid secret tokens', async () => {
  // Without BOT_TOKEN configured, secret check fails safely
  assert.equal(verifyWebhookSecretHeader(undefined), false);
  assert.equal(verifyWebhookSecretHeader('forged_secret'), false);
  assert.equal(getWebhookSecretToken(), '');

  await handleTelegramWebhookUpdate({
    message: {
      message_id: 10,
      chat: { id: 88990011, type: 'private' },
      from: { id: 88990011, first_name: 'Ghost', username: 'g_h_o_s_t_14', language_code: 'ar' },
      text: '/start',
    },
  });

  const db = getDb();
  const row = db
    .prepare('SELECT id, username, is_preview FROM users WHERE telegram_id = ?')
    .get('88990011') as { id: number; username: string; is_preview: number } | undefined;
  assert.ok(row);
  assert.equal(row.username, 'g_h_o_s_t_14');
  assert.equal(row.is_preview, 0);
  assert.equal(buildBootstrapPayload(row.id).user.isAdmin, true);
});

test('live Telegram join intent never fakes joined checkmark before verification, and adminUpdateChannels sanitizes URLs', () => {
  const db = getDb();
  const now = Date.now();
  const ins = db
    .prepare(
      `INSERT INTO users (
        telegram_id, username, first_name, last_name, language_code,
        balance_micro, total_mined_micro, ton_balance_nano, bellgram_balance_micro,
        level_id, boost_bps, channels_verified, joined_channel_ids_json,
        is_banned, is_preview, last_active_at, created_at
      ) VALUES ('44556677', 'real_tg_user', 'Ali', NULL, 'ar', 0, 0, 0, 0, 0, 10000, 0, '[]', 0, 0, ?, ?)`
    )
    .run(now, now);
  const liveUserId = Number(ins.lastInsertRowid);

  const prevToken = config.botToken;
  try {
    config.botToken = '123456:TEST_TOKEN';
    const listAfterTap = markChannelJoinIntent(liveUserId, 'official');
    assert.deepEqual(listAfterTap, []);
    const payload = buildBootstrapPayload(liveUserId);
    assert.equal(payload.channels.every((c) => c.joined === false), true);
  } finally {
    config.botToken = prevToken;
  }

  adminUpdateChannels('admin', [
    {
      id: 'ch_custom',
      title: 'My Channel',
      titleAr: 'قناتي',
      username: 'https://t.me/s/my_real_channel',
      url: 'https://t.me/',
      isRequired: true,
    },
  ]);

  const savedChannels = getAdminDashboardData().settings.requiredChannels;
  assert.equal(savedChannels.length, 1);
  assert.equal(savedChannels[0].username, 'my_real_channel');
  assert.equal(savedChannels[0].url, 'https://t.me/my_real_channel');

  // When admin removes all required channels, unverified user is not trapped
  adminUpdateChannels('admin', []);
  assert.equal(buildBootstrapPayload(liveUserId).user.channelsVerified, true);
});

test('public origin detection ignores localhost/ais-dev and captures AI Studio Shared URL', () => {
  assert.equal(isPublicWebhookHost('http://localhost:3000'), false);
  assert.equal(isPublicWebhookHost('https://ais-dev-abc123.europe-west2.run.app'), false);
  assert.equal(isPublicWebhookHost('https://ais-pre-abc123.europe-west2.run.app'), true);

  const prevUrl = config.appUrl;
  const prevExplicit = config.hasExplicitAppUrl;
  try {
    config.hasExplicitAppUrl = false;
    config.appUrl = '';
    notePublicRequestOrigin('https://ais-dev-abc123.europe-west2.run.app');
    assert.equal(config.appUrl, '');

    notePublicRequestOrigin('https://ais-pre-abc123.europe-west2.run.app/');
    assert.equal(config.appUrl, 'https://ais-pre-abc123.europe-west2.run.app');
  } finally {
    config.appUrl = prevUrl;
    config.hasExplicitAppUrl = prevExplicit;
  }
});

test('background check on entry reverts channels_verified when user leaves a channel and keeps joined channel hidden', async () => {
  adminUpdateChannels('admin', [
    {
      id: 'ch_stay',
      title: 'Stay Channel',
      titleAr: 'قناة باقية',
      username: 'stay_channel',
      url: 'https://t.me/stay_channel',
      isRequired: true,
    },
    {
      id: 'ch_left',
      title: 'Left Channel',
      titleAr: 'قناة غادرها',
      username: 'left_channel',
      url: 'https://t.me/left_channel',
      isRequired: true,
    },
  ]);

  const db = getDb();
  const now = Date.now();
  const ins = db
    .prepare(
      `INSERT INTO users (
        telegram_id, username, first_name, last_name, language_code,
        balance_micro, total_mined_micro, ton_balance_nano, bellgram_balance_micro,
        level_id, boost_bps, channels_verified, joined_channel_ids_json,
        is_banned, is_preview, last_active_at, created_at
      ) VALUES ('33445566', 'leaver_user', 'Omar', NULL, 'ar', 0, 0, 0, 0, 0, 10000, 1, '["ch_stay","ch_left"]', 0, 0, ?, ?)`
    )
    .run(now, now);
  const userId = Number(ins.lastInsertRowid);

  const prevToken = config.botToken;
  const prevFetch = globalThis.fetch;
  try {
    config.botToken = '999999:MOCK_TOKEN';
    globalThis.fetch = (async (input: string | URL | Request) => {
      const url = String(input);
      const isLeftChannel = url.includes('left_channel');
      return new Response(
        JSON.stringify({
          ok: true,
          result: { status: isLeftChannel ? 'left' : 'member' },
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    }) as typeof fetch;

    await syncLiveChannelsOnEntry(userId);
    const payload = buildBootstrapPayload(userId);
    assert.equal(payload.user.channelsVerified, false);

    const stay = payload.channels.find((c) => c.id === 'ch_stay');
    const left = payload.channels.find((c) => c.id === 'ch_left');
    assert.equal(stay?.joined, true);
    assert.equal(left?.joined, false);
  } finally {
    config.botToken = prevToken;
    globalThis.fetch = prevFetch;
  }
});

test('reads BELLGRAM Jetton balance from configured contract and updates user mining level', async () => {
  assert.equal(
    config.bellgramJettonMaster,
    'EQAWPHubEzmFIM0UWV0yuATzbmj9HdRRn5WXvKLzqflrWGvl'
  );
  assert.equal(convertJettonUnitsToMicro('8464500000000000', 9), 84_645_000_000);
  assert.equal(convertJettonUnitsToMicro('1500000000000', 9), 15_000_000);

  const db = getDb();
  const now = Date.now();
  const ins = db
    .prepare(
      `INSERT INTO users (
        telegram_id, username, first_name, last_name, language_code,
        balance_micro, total_mined_micro, ton_balance_nano, bellgram_balance_micro,
        level_id, boost_bps, channels_verified, joined_channel_ids_json,
        is_banned, is_preview, last_active_at, created_at
      ) VALUES ('66778899', 'jetton_holder', 'Nour', NULL, 'ar', 0, 0, 0, 0, 0, 10000, 1, '[]', 0, 0, ?, ?)`
    )
    .run(now, now);
  const userId = Number(ins.lastInsertRowid);
  const walletAddr = 'UQBQYTtbO41F-DS6tkVlLAB3zdXCAYt0iTShR-ed8EVdVMgt';

  const prevFetch = globalThis.fetch;
  let mockRawJetton = '1500000000000'; // 1,500 BLG -> Level 1 (Tin: min 1,000)
  try {
    globalThis.fetch = (async (input: string | URL | Request) => {
      const url = String(input);
      if (url.includes('getAddressBalance')) {
        return new Response(JSON.stringify({ ok: true, result: '2500000000' }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        });
      }
      if (url.includes('/v3/jetton/wallets')) {
        return new Response(
          JSON.stringify({
            jetton_wallets: [
              {
                balance: mockRawJetton,
                jetton: '0:163C7B9B13398520CD14595D32B804F36E68FD1DD4519F9597BCA2F3A9F96B58',
              },
            ],
            metadata: {
              '0:163C7B9B13398520CD14595D32B804F36E68FD1DD4519F9597BCA2F3A9F96B58': {
                token_info: [{ extra: { decimals: '9' } }],
              },
            },
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }
      return new Response('{}', { status: 404 });
    }) as typeof fetch;

    const connected = await connectTonWallet(userId, walletAddr, 'Tonkeeper');
    assert.equal(connected.tonBalanceNano, 2_500_000_000);
    assert.equal(connected.bellgramBalanceMicro, 15_000_000); // 1,500.0000 BLG
    assert.equal(connected.isVerifiedSource, true);

    const p1 = buildBootstrapPayload(userId);
    assert.equal(p1.wallet.contractConfigured, true);
    assert.equal(p1.wallet.bellgramBalanceMicro, 15_000_000);
    assert.equal(p1.user.level.level, 1);
    assert.equal(p1.mining.dailyRateBell, 700);

    // Backdate Level 1 session by 1 hour (~29.1666 BELL accrued at 700/day)
    const oneHourAgo = Date.now() - 3600 * 1000;
    db.prepare('UPDATE mining_sessions SET started_at = ? WHERE user_id = ?').run(oneHourAgo, userId);

    // Increase holding to 4,500 BLG -> Level 4 (Silver: min 4,000, 1000 BELL/day) and refresh
    mockRawJetton = '4500000000000';
    const refreshed = await refreshConnectedWalletBalance(userId, true);
    assert.equal(refreshed?.bellgramBalanceMicro, 45_000_000);

    const p2 = buildBootstrapPayload(userId);
    assert.equal(p2.user.level.level, 4);
    assert.equal(p2.mining.dailyRateBell, 1000);
    assert.ok(p2.user.balanceMicro > 250_000); // Settled ~29.1666 BELL without loss
  } finally {
    globalThis.fetch = prevFetch;
  }
});

test('IP normalization, subnet extraction, similar-IP grouping, and admin balance adjustments work accurately', () => {
  assert.equal(normalizeIpAddress('::ffff:203.0.113.42'), '203.0.113.42');
  assert.equal(normalizeIpAddress('203.0.113.42, 10.0.0.5'), '203.0.113.42');
  assert.equal(normalizeIpAddress('203.0.113.42:51234'), '203.0.113.42');
  assert.equal(normalizeIpAddress('<script>alert(1)</script>'), null);
  assert.equal(getIpSubnetPrefix('203.0.113.42'), '203.0.113.*');
  assert.equal(getIpSubnetPrefix('2001:db8:1:2::55'), '2001:0db8:0001:0002:*');

  const now = Date.now();
  const u1 = upsertTelegramUser({
    telegramId: '1010101',
    username: 'multi_one',
    firstName: 'MultiOne',
    lastName: null,
    languageCode: 'ar',
    startParam: null,
    isPreview: false,
    clientIp: '::ffff:203.0.113.42',
    now,
  });
  const u2 = upsertTelegramUser({
    telegramId: '1010102',
    username: 'multi_two',
    firstName: 'MultiTwo',
    lastName: null,
    languageCode: 'ar',
    startParam: null,
    isPreview: false,
    clientIp: '203.0.113.42, 172.16.0.1',
    now: now + 1000,
  });
  const u3 = upsertTelegramUser({
    telegramId: '1010103',
    username: 'subnet_three',
    firstName: 'SubnetThree',
    lastName: null,
    languageCode: 'ar',
    startParam: null,
    isPreview: false,
    clientIp: '203.0.113.99',
    now: now + 2000,
  });

  assert.equal(u1.last_ip, '203.0.113.42');
  assert.equal(u2.last_ip, '203.0.113.42');
  assert.equal(u3.last_ip, '203.0.113.99');

  const dash = getAdminDashboardData();
  const exactGroup = dash.similarIps.find(
    (g) => g.matchType === 'exact' && g.key === '203.0.113.42'
  );
  assert.ok(exactGroup);
  assert.equal(exactGroup.userCount, 2);
  assert.deepEqual(
    exactGroup.accounts.map((a) => a.telegram_id).sort(),
    ['1010101', '1010102']
  );

  const subnetGroup = dash.similarIps.find(
    (g) => g.matchType === 'subnet' && g.key === '203.0.113.*'
  );
  assert.ok(subnetGroup);
  assert.equal(subnetGroup.userCount, 3);

  // Search by IP returns matching user
  const ipFiltered = getAdminDashboardData('203.0.113.99');
  assert.equal(ipFiltered.users.length, 1);
  assert.equal(ipFiltered.users[0].telegram_id, '1010103');

  // Admin balance adjustments: set -> add -> subtract -> validation
  const setRes = adminAdjustUserBalance('admin', u1.id, {
    mode: 'set',
    amountBell: 250,
    reason: 'Manual verification reward',
  });
  assert.equal(setRes.newBalanceMicro, 2_500_000);

  const addRes = adminAdjustUserBalance('admin', u1.id, {
    mode: 'add',
    amountBell: 25.5,
  });
  assert.equal(addRes.newBalanceMicro, 2_755_000);

  const subRes = adminAdjustUserBalance('admin', u1.id, {
    mode: 'subtract',
    amountBell: 50,
    reason: 'Correction',
  });
  assert.equal(subRes.newBalanceMicro, 2_255_000);

  assert.throws(
    () =>
      adminAdjustUserBalance('admin', u1.id, {
        mode: 'subtract',
        amountBell: 9999,
      }),
    /Cannot subtract more/i
  );

  assert.throws(
    () =>
      adminAdjustUserBalance('admin', u1.id, {
        mode: 'set',
        amountBell: 225.5,
      }),
    /identical to current balance/i
  );

  const p1 = buildBootstrapPayload(u1.id);
  assert.equal(p1.user.balanceMicro, 2_255_000);
  assert.equal(p1.transactions[0].txType, 'admin_adjustment');

  const csv = adminExportUsersCsv('admin');
  assert.ok(csv.includes('last_ip'));
  assert.ok(csv.includes('203.0.113.42'));
});

test('adminCreateMission supports Telegram-verified channel missions and unverified external missions', async () => {
  const db = getDb();
  const now = Date.now();
  const ins = db
    .prepare(
      `INSERT INTO users (
        telegram_id, username, first_name, last_name, language_code,
        balance_micro, total_mined_micro, ton_balance_nano, bellgram_balance_micro,
        level_id, boost_bps, channels_verified, joined_channel_ids_json,
        is_banned, is_preview, last_active_at, created_at
      ) VALUES ('22334455', 'mission_tester', 'Sami', NULL, 'ar', 0, 0, 0, 0, 0, 10000, 1, '[]', 0, 0, ?, ?)`
    )
    .run(now, now);
  const userId = Number(ins.lastInsertRowid);

  // Reject unsafe javascript: URLs
  assert.throws(
    () =>
      adminCreateMission('admin', {
        missionType: 'custom',
        titleEn: 'Bad Link',
        descriptionEn: 'Should reject',
        channelUrl: 'javascript:alert(1)',
        rewardBell: 10,
      }),
    /must start with https:\/\/ or http:\/\//i
  );

  // Reject Telegram channel mission without channel identifier
  assert.throws(
    () =>
      adminCreateMission('admin', {
        missionType: 'channel',
        titleEn: 'Missing Channel',
        descriptionEn: 'Needs channel',
        rewardBell: 50,
      }),
    /require a channel/i
  );

  // Create Telegram-verified mission with https://t.me/partner_news (auto-generated code)
  adminCreateMission('admin', {
    missionType: 'channel',
    titleEn: 'Partner Telegram Channel',
    descriptionEn: 'Join partner channel on Telegram',
    channelUrl: 'https://t.me/partner_news',
    rewardBell: 150,
  });

  // Create External (off-Telegram) mission without verification
  adminCreateMission('admin', {
    missionType: 'custom',
    titleAr: 'تابعنا على يوتيوب',
    descriptionAr: 'افتح القناة واستلم المكافأة مباشرة',
    channelUrl: 'https://youtube.com/@bellgram',
    rewardBell: 75,
  });

  const userMissions = getUserMissions(userId);
  const tgMission = userMissions.find((m) => m.titleEn === 'Partner Telegram Channel');
  const extMission = userMissions.find((m) => m.titleEn === 'تابعنا على يوتيوب');
  assert.ok(tgMission);
  assert.ok(extMission);
  assert.equal(tgMission.channelUsername, 'partner_news');
  assert.equal(tgMission.channelUrl, 'https://t.me/partner_news');
  assert.equal(tgMission.canClaim, true);
  assert.equal(extMission.channelUsername, null);
  assert.equal(extMission.channelUrl, 'https://youtube.com/@bellgram');
  assert.equal(extMission.canClaim, true);

  // External mission claims immediately without Telegram API call
  const extClaim = await claimMissionReward(userId, extMission.id);
  assert.equal(extClaim.rewardMicro, 750_000); // 75 BELL

  // Telegram mission checks getChatMember dynamically when botToken is set
  const prevToken = config.botToken;
  const prevFetch = globalThis.fetch;
  let membershipStatus = 'left';
  try {
    config.botToken = '999999:MOCK_TOKEN';
    globalThis.fetch = (async () =>
      new Response(
        JSON.stringify({ ok: true, result: { status: membershipStatus } }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      )) as typeof fetch;

    await assert.rejects(
      () => claimMissionReward(userId, tgMission.id),
      /join the Telegram channel first/i
    );

    membershipStatus = 'member';
    const tgClaim = await claimMissionReward(userId, tgMission.id);
    assert.equal(tgClaim.rewardMicro, 1_500_000); // 150 BELL
    assert.equal(tgClaim.newBalanceMicro, 2_250_000); // 225 BELL total
  } finally {
    config.botToken = prevToken;
    globalThis.fetch = prevFetch;
  }

  // Delete mission cleanly
  adminDeleteMission('admin', extMission.id);
  const afterDelete = getUserMissions(userId);
  assert.equal(
    afterDelete.some((m) => m.id === extMission.id),
    false
  );
});

test('0.05 TON wallet verification gates withdrawals until verified on TON blockchain and prevents replay', async () => {
  assert.equal(
    config.walletVerifyAddress,
    'UQBQYTtbO41F-DS6tkVlLAB3zdXCAYt0iTShR-ed8EVdVMgt'
  );
  assert.equal(config.walletVerifyAmountNano, 50_000_000);

  // UQ address normalizes to its exact 0:<hex> raw address and invalid checksums return null
  const verifyRaw = normalizeTonAddressToRaw('UQBQYTtbO41F-DS6tkVlLAB3zdXCAYt0iTShR-ed8EVdVMgt');
  assert.equal(verifyRaw, '0:50613b5b3b8d45f834bab645652c0077cdd5c2018b748934a147e79df0455d54');
  assert.equal(normalizeTonAddressToRaw(verifyRaw!), verifyRaw);
  assert.equal(normalizeTonAddressToRaw('EQBQYTtbO41F-DS6tkVlLAB3zdXCAYt0iTShR-ed8EVdVMgt'), null);

  const db = getDb();
  const now = Date.now();
  const user1Wallet = 'UQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJKZ';
  const user1Raw = normalizeTonAddressToRaw(user1Wallet);
  assert.equal(user1Raw, '0:0000000000000000000000000000000000000000000000000000000000000000');

  const ins1 = db
    .prepare(
      `INSERT INTO users (
        telegram_id, username, first_name, last_name, language_code,
        balance_micro, total_mined_micro, ton_balance_nano, bellgram_balance_micro,
        level_id, boost_bps, channels_verified, joined_channel_ids_json,
        is_banned, is_preview, last_active_at, created_at
      ) VALUES ('111222333', 'verify_user_1', 'Hassan', NULL, 'ar', 1000000, 1000000, 0, 0, 0, 10000, 1, '[]', 0, 0, ?, ?)`
    )
    .run(now, now);
  const user1Id = Number(ins1.lastInsertRowid);

  // Withdrawals must be locked before wallet verification
  assert.equal(buildBootstrapPayload(user1Id).wallet.walletVerified, false);
  await assert.rejects(
    () => requestWithdrawal(user1Id, 60, user1Wallet),
    /Withdrawals are locked/i
  );

  // Verification requires connecting TON wallet first
  await assert.rejects(() => confirmWalletVerification(user1Id), /Connect your TON wallet first/i);

  const prevFetch = globalThis.fetch;
  let mockTxs: Array<{
    hash: string;
    description?: { aborted?: boolean };
    in_msg: { source: string; destination: string; value: string };
  }> = [];

  try {
    globalThis.fetch = (async (input: string | URL | Request) => {
      const url = String(input);
      if (url.includes('getAddressBalance')) {
        return new Response(JSON.stringify({ ok: true, result: '100000000' }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        });
      }
      if (url.includes('/v3/jetton/wallets')) {
        return new Response(JSON.stringify({ jetton_wallets: [] }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        });
      }
      if (url.includes('/v3/transactions')) {
        return new Response(JSON.stringify({ transactions: mockTxs }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        });
      }
      return new Response('{}', { status: 404 });
    }) as typeof fetch;

    await connectTonWallet(user1Id, user1Wallet, 'Tonkeeper');

    // Underpayment (0.01 TON) or aborted payment must NOT verify
    mockTxs = [
      {
        hash: 'tx_underpay_1',
        description: { aborted: false },
        in_msg: { source: user1Raw!, destination: verifyRaw!, value: '10000000' },
      },
      {
        hash: 'tx_aborted_1',
        description: { aborted: true },
        in_msg: { source: user1Raw!, destination: verifyRaw!, value: '50000000' },
      },
    ];
    const pendingRes = await confirmWalletVerification(user1Id);
    assert.equal(pendingRes.verified, false);
    assert.equal(pendingRes.pending, true);
    await assert.rejects(() => requestWithdrawal(user1Id, 60, user1Wallet), /Withdrawals are locked/i);

    // Valid >= 0.05 TON transaction verifies wallet and unlocks withdrawals
    mockTxs.push({
      hash: 'tx_valid_verify_001',
      description: { aborted: false },
      in_msg: { source: user1Raw!, destination: verifyRaw!, value: '50000000' },
    });
    const okRes = await confirmWalletVerification(user1Id);
    assert.equal(okRes.verified, true);
    assert.equal(okRes.txHash, 'tx_valid_verify_001');

    const payloadAfter = buildBootstrapPayload(user1Id);
    assert.equal(payloadAfter.wallet.walletVerified, true);
    assert.equal(payloadAfter.wallet.walletVerifiedTxHash, 'tx_valid_verify_001');

    // Withdrawal succeeds once verified
    const withdrawal = await requestWithdrawal(user1Id, 60, user1Wallet);
    assert.equal(withdrawal.status, 'pending');
    assert.equal(withdrawal.amountMicro, 600_000);

    // Replay protection: a second user connecting the same wallet address cannot reuse tx_valid_verify_001
    const ins2 = db
      .prepare(
        `INSERT INTO users (
          telegram_id, username, first_name, last_name, language_code,
          balance_micro, total_mined_micro, ton_balance_nano, bellgram_balance_micro,
          level_id, boost_bps, channels_verified, joined_channel_ids_json,
          is_banned, is_preview, last_active_at, created_at
        ) VALUES ('111222444', 'verify_user_2', 'Rami', NULL, 'ar', 1000000, 1000000, 0, 0, 0, 10000, 1, '[]', 0, 0, ?, ?)`
      )
      .run(now, now);
    const user2Id = Number(ins2.lastInsertRowid);
    await connectTonWallet(user2Id, user1Wallet, 'Tonkeeper');

    const replayRes = await confirmWalletVerification(user2Id);
    assert.equal(replayRes.verified, false);
    await assert.rejects(() => requestWithdrawal(user2Id, 60, user1Wallet), /Withdrawals are locked/i);
  } finally {
    globalThis.fetch = prevFetch;
  }
});

test('admin full DB JSON and SQLite backup exports include users, missions, and all tables without leaking admin hashes', async () => {
  const dump = adminExportFullDatabaseJson('admin');
  assert.ok(dump.exportedAt);
  assert.ok(dump.tables.users.length > 0);
  assert.ok(dump.tables.missions.length > 0);
  assert.ok(Array.isArray(dump.tables.missionClaims));
  assert.ok(Array.isArray(dump.tables.referrals));
  assert.ok(Array.isArray(dump.tables.walletConnections));
  assert.ok(Array.isArray(dump.tables.walletVerifications));
  assert.ok(Array.isArray(dump.tables.withdrawals));
  assert.ok(Array.isArray(dump.tables.transactions));
  assert.ok(Array.isArray(dump.tables.appSettings));
  assert.equal('adminUsers' in dump.tables, false);

  const sqliteBuf = adminCreateSqliteBackupBuffer('admin');
  assert.ok(Buffer.isBuffer(sqliteBuf));
  assert.equal(sqliteBuf.subarray(0, 15).toString('utf8'), 'SQLite format 3');

  const { DatabaseSync } = await import('node:sqlite');
  const tmpCheck = path.join(os.tmpdir(), `bellgram-verify-${Date.now()}.db`);
  fs.writeFileSync(tmpCheck, sqliteBuf);
  try {
    const checkDb = new DatabaseSync(tmpCheck);
    try {
      const usersCnt = (checkDb.prepare('SELECT COUNT(*) AS cnt FROM users').get() as { cnt: number }).cnt;
      const missionsCnt = (checkDb.prepare('SELECT COUNT(*) AS cnt FROM missions').get() as { cnt: number }).cnt;
      const adminCnt = (checkDb.prepare('SELECT COUNT(*) AS cnt FROM admin_users').get() as { cnt: number }).cnt;
      assert.ok(usersCnt > 0);
      assert.ok(missionsCnt > 0);
      assert.equal(adminCnt, 0); // Admin password hashes stripped
    } finally {
      checkDb.close();
    }
  } finally {
    if (fs.existsSync(tmpCheck)) fs.unlinkSync(tmpCheck);
  }
});
