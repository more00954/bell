import { getDb, runInTransaction } from '../db.ts';
import { config } from '../config.ts';
import { bellToMicro, getUtcDateString } from '../../src/lib/bellMath.ts';
import { checkTelegramChannelMembership } from '../telegramAuth.ts';
import { ServiceError } from './miningService.ts';
import type { MissionItem } from '../../src/types.ts';
import type { DbUserRow } from './userService.ts';

interface DbMissionRow {
  id: number;
  code: string;
  title_en: string;
  title_ar: string;
  description_en: string;
  description_ar: string;
  mission_type: 'channel' | 'referral_count' | 'daily_login' | 'custom';
  target_value: number;
  channel_username: string | null;
  channel_url: string | null;
  reward_bell: number;
  is_active: number;
  sort_order: number;
}

export function getUserMissions(userId: number): MissionItem[] {
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as unknown as DbUserRow;
  const missions = db
    .prepare('SELECT * FROM missions WHERE is_active = 1 ORDER BY sort_order ASC, id ASC')
    .all() as unknown as DbMissionRow[];

  const claims = db
    .prepare('SELECT mission_id, status FROM mission_claims WHERE user_id = ?')
    .all(userId) as Array<{ mission_id: number; status: 'pending' | 'completed' }>;
  const claimMap = new Map(claims.map((c) => [c.mission_id, c.status]));

  const refCountRow = db
    .prepare('SELECT COUNT(*) AS cnt FROM referrals WHERE referrer_id = ?')
    .get(userId) as { cnt: number };
  const refCount = refCountRow?.cnt ?? 0;

  const todayUtc = getUtcDateString(Date.now());
  const dailyTodayRow = db
    .prepare('SELECT id FROM daily_rewards WHERE user_id = ? AND claim_date_utc = ?')
    .get(userId, todayUtc);
  const dailyDoneToday = Boolean(dailyTodayRow);

  let joinedChannelIds: string[] = [];
  try {
    joinedChannelIds = JSON.parse(user.joined_channel_ids_json || '[]') as string[];
  } catch {
    joinedChannelIds = [];
  }

  return missions.map((m) => {
    const claimedStatus = claimMap.get(m.id);
    if (claimedStatus === 'completed') {
      return {
        id: m.id,
        code: m.code,
        titleEn: m.title_en,
        titleAr: m.title_ar,
        descriptionEn: m.description_en,
        descriptionAr: m.description_ar,
        missionType: m.mission_type,
        targetValue: m.target_value,
        channelUsername: m.channel_username,
        channelUrl: m.channel_url,
        rewardBell: m.reward_bell,
        status: 'Completed',
        progressCurrent: m.target_value,
        progressTarget: m.target_value,
        canClaim: false,
      };
    }

    if (claimedStatus === 'pending') {
      return {
        id: m.id,
        code: m.code,
        titleEn: m.title_en,
        titleAr: m.title_ar,
        descriptionEn: m.description_en,
        descriptionAr: m.description_ar,
        missionType: m.mission_type,
        targetValue: m.target_value,
        channelUsername: m.channel_username,
        channelUrl: m.channel_url,
        rewardBell: m.reward_bell,
        status: 'Pending',
        progressCurrent: 0,
        progressTarget: m.target_value,
        canClaim: false,
      };
    }

    let progressCurrent = 0;
    let canClaim = false;

    if (m.mission_type === 'referral_count') {
      progressCurrent = Math.min(m.target_value, refCount);
      canClaim = refCount >= m.target_value;
    } else if (m.mission_type === 'daily_login') {
      progressCurrent = dailyDoneToday ? 1 : 0;
      canClaim = dailyDoneToday;
    } else if (m.mission_type === 'channel') {
      // Allow clicking Verify & Claim so server performs live Telegram getChatMember check for this specific channel
      progressCurrent = 0;
      canClaim = true;
    } else {
      progressCurrent = 0;
      canClaim = true;
    }

    return {
      id: m.id,
      code: m.code,
      titleEn: m.title_en,
      titleAr: m.title_ar,
      descriptionEn: m.description_en,
      descriptionAr: m.description_ar,
      missionType: m.mission_type,
      targetValue: m.target_value,
      channelUsername: m.channel_username,
      channelUrl: m.channel_url,
      rewardBell: m.reward_bell,
      status: 'Available',
      progressCurrent,
      progressTarget: m.target_value,
      canClaim,
    };
  });
}

export async function claimMissionReward(userId: number, missionId: number): Promise<{
  rewardMicro: number;
  newBalanceMicro: number;
}> {
  const db = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as DbUserRow | undefined;
  if (!user) throw new ServiceError('User not found', 404);
  if (user.is_banned) throw new ServiceError('Account is suspended', 403);

  const mission = db
    .prepare('SELECT * FROM missions WHERE id = ? AND is_active = 1')
    .get(missionId) as DbMissionRow | undefined;
  if (!mission) throw new ServiceError('Mission not found or inactive', 404);

  // Server-side verification before entering transaction
  if (mission.mission_type === 'channel' && mission.channel_username) {
    const hasRealBot = Boolean(config.botToken) && !user.is_preview && /^\d+$/.test(user.telegram_id);
    if (hasRealBot) {
      const check = await checkTelegramChannelMembership(
        config.botToken,
        mission.channel_username,
        Number(user.telegram_id)
      );
      if (!check.ok) {
        throw new ServiceError(
          `Unable to verify channel membership (${check.reason || 'ensure bot is admin in channel'}).`,
          400
        );
      }
      if (!check.isMember) {
        throw new ServiceError('Please join the Telegram channel first, then tap Verify & Claim.', 400);
      }
    } else if (user.channels_verified !== 1) {
      throw new ServiceError('Complete channel verification first.', 400);
    }
  }

  return runInTransaction((txDb) => {
    const existing = txDb
      .prepare('SELECT id FROM mission_claims WHERE user_id = ? AND mission_id = ?')
      .get(userId, missionId);
    if (existing) {
      throw new ServiceError('Mission reward already claimed.', 409);
    }

    if (mission.mission_type === 'referral_count') {
      const row = txDb
        .prepare('SELECT COUNT(*) AS cnt FROM referrals WHERE referrer_id = ?')
        .get(userId) as { cnt: number };
      if ((row?.cnt ?? 0) < mission.target_value) {
        throw new ServiceError(
          `Invite ${mission.target_value} friend(s) to unlock this mission reward.`,
          400
        );
      }
    } else if (mission.mission_type === 'daily_login') {
      const todayUtc = getUtcDateString(Date.now());
      const dailyRow = txDb
        .prepare('SELECT id FROM daily_rewards WHERE user_id = ? AND claim_date_utc = ?')
        .get(userId, todayUtc);
      if (!dailyRow) {
        throw new ServiceError('Claim today’s Daily Login bonus on Home first.', 400);
      }
    }

    const freshUser = txDb.prepare('SELECT balance_micro FROM users WHERE id = ?').get(userId) as {
      balance_micro: number;
    };
    const rewardMicro = bellToMicro(mission.reward_bell);
    const nowMs = Date.now();

    txDb
      .prepare(
        `INSERT INTO mission_claims (user_id, mission_id, status, reward_micro, claimed_at)
         VALUES (?, ?, 'completed', ?, ?)`
      )
      .run(userId, missionId, rewardMicro, nowMs);

    const newBalanceMicro = freshUser.balance_micro + rewardMicro;
    txDb.prepare('UPDATE users SET balance_micro = ?, last_active_at = ? WHERE id = ?').run(
      newBalanceMicro,
      nowMs,
      userId
    );

    txDb
      .prepare(
        `INSERT INTO transactions (user_id, tx_type, amount_micro, balance_after_micro, description, reference_id, created_at)
         VALUES (?, 'mission_reward', ?, ?, ?, ?, ?)`
      )
      .run(
        userId,
        rewardMicro,
        newBalanceMicro,
        `Mission completed: ${mission.title_en}`,
        `mission_${missionId}`,
        nowMs
      );

    return { rewardMicro, newBalanceMicro };
  });
}
