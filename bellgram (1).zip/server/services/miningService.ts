import crypto from 'node:crypto';
import { getSetting, runInTransaction, DEFAULT_MINING_LEVELS } from '../db.ts';
import { bellToMicro, computeAccruedMicro, resolveLevelForBellgram } from '../../src/lib/bellMath.ts';
import type { MiningLevel } from '../../src/types.ts';
import type { DbUserRow } from './userService.ts';

export class ServiceError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

export function claimMiningReward(userId: number, clientIdempotencyKey?: string): {
  claimedMicro: number;
  newBalanceMicro: number;
  newSessionId: number;
} {
  return runInTransaction((db) => {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as DbUserRow | undefined;
    if (!user) throw new ServiceError('User not found', 404);
    if (user.is_banned) throw new ServiceError('Account is suspended', 403);
    if (user.channels_verified !== 1) {
      throw new ServiceError('Channel subscription verification is required before mining.', 403);
    }

    const session = db
      .prepare("SELECT * FROM mining_sessions WHERE user_id = ? AND status = 'running' ORDER BY id DESC LIMIT 1")
      .get(userId) as
      | {
          id: number;
          status: 'running';
          daily_rate_bell: number;
          multiplier_bps: number;
          started_at: number;
          ends_at: number;
          claimed_micro: number;
        }
      | undefined;

    if (!session) {
      throw new ServiceError('No active mining session found.', 409);
    }

    const durationHours = getSetting<number>('session_duration_hours', 24);
    const minClaimBell = getSetting<number>('min_claim_bell', 0.0001);
    const minClaimMicro = Math.max(1, bellToMicro(minClaimBell));
    const sessionDurationSec = Math.max(60, Math.round(durationHours * 3600));
    const nowMs = Date.now();

    const accrual = computeAccruedMicro({
      dailyRateBell: session.daily_rate_bell,
      multiplierBps: session.multiplier_bps,
      startedAtMs: session.started_at,
      nowMs,
      sessionDurationSec,
      alreadyClaimedMicro: session.claimed_micro,
      status: session.status,
    });

    if (accrual.accruedMicro < minClaimMicro) {
      throw new ServiceError(
        `Minimum claim is ${minClaimBell} BELL. Keep mining to accumulate rewards.`,
        400
      );
    }

    // Prevent claiming the same session twice even under concurrent requests
    const existingClaim = db
      .prepare('SELECT id FROM mining_claims WHERE session_id = ?')
      .get(session.id);
    if (existingClaim) {
      throw new ServiceError('This mining session has already been claimed.', 409);
    }

    const idempotencyKey =
      clientIdempotencyKey && clientIdempotencyKey.length >= 8
        ? `${userId}:${session.id}:${clientIdempotencyKey.slice(0, 64)}`
        : `${userId}:${session.id}:${crypto.randomUUID()}`;

    // Close current session atomically so it can never be claimed again
    const updateSessionRes = db
      .prepare(
        `UPDATE mining_sessions
         SET status = 'claimed',
             claimed_micro = ?,
             last_claimed_at = ?
         WHERE id = ? AND status = 'running'`
      )
      .run(accrual.accruedMicro, nowMs, session.id);

    if (updateSessionRes.changes !== 1) {
      throw new ServiceError('Mining session already claimed.', 409);
    }

    db.prepare(
      `INSERT INTO mining_claims (user_id, session_id, amount_micro, idempotency_key, claimed_at)
       VALUES (?, ?, ?, ?, ?)`
    ).run(userId, session.id, accrual.accruedMicro, idempotencyKey, nowMs);

    const newBalanceMicro = user.balance_micro + accrual.accruedMicro;
    const newTotalMinedMicro = user.total_mined_micro + accrual.accruedMicro;

    db.prepare(
      `UPDATE users
       SET balance_micro = ?,
           total_mined_micro = ?,
           last_active_at = ?
       WHERE id = ?`
    ).run(newBalanceMicro, newTotalMinedMicro, nowMs, userId);

    db.prepare(
      `INSERT INTO transactions (user_id, tx_type, amount_micro, balance_after_micro, description, reference_id, created_at)
       VALUES (?, 'mining_claim', ?, ?, ?, ?, ?)`
    ).run(
      userId,
      accrual.accruedMicro,
      newBalanceMicro,
      `Mining session #${session.id} claim`,
      `session_${session.id}`,
      nowMs
    );

    // Start a fresh 24h mining session using current level & multiplier
    const levels = getSetting<MiningLevel[]>('mining_levels', DEFAULT_MINING_LEVELS);
    const { current } = resolveLevelForBellgram(user.bellgram_balance_micro, levels);
    const newEndsAt = nowMs + sessionDurationSec * 1000;

    const newSessionRes = db
      .prepare(
        `INSERT INTO mining_sessions (
          user_id, status, daily_rate_bell, multiplier_bps, started_at, ends_at, claimed_micro, created_at
        ) VALUES (?, 'running', ?, ?, ?, ?, 0, ?)`
      )
      .run(userId, current.dailyBell, user.boost_bps, nowMs, newEndsAt, nowMs);

    return {
      claimedMicro: accrual.accruedMicro,
      newBalanceMicro,
      newSessionId: Number(newSessionRes.lastInsertRowid),
    };
  });
}

export function syncMiningSessionRateForUser(
  userId: number,
  targetDailyRateBell: number
): boolean {
  return runInTransaction((db) => {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as DbUserRow | undefined;
    if (!user || user.is_banned || user.channels_verified !== 1) return false;

    const session = db
      .prepare("SELECT * FROM mining_sessions WHERE user_id = ? AND status = 'running' ORDER BY id DESC LIMIT 1")
      .get(userId) as
      | {
          id: number;
          status: 'running';
          daily_rate_bell: number;
          multiplier_bps: number;
          started_at: number;
          ends_at: number;
          claimed_micro: number;
        }
      | undefined;

    if (!session || session.daily_rate_bell === targetDailyRateBell) {
      return false;
    }

    const durationHours = getSetting<number>('session_duration_hours', 24);
    const sessionDurationSec = Math.max(60, Math.round(durationHours * 3600));
    const nowMs = Date.now();

    const accrual = computeAccruedMicro({
      dailyRateBell: session.daily_rate_bell,
      multiplierBps: session.multiplier_bps,
      startedAtMs: session.started_at,
      nowMs,
      sessionDurationSec,
      alreadyClaimedMicro: session.claimed_micro,
      status: session.status,
    });

    if (accrual.accruedMicro <= 0) {
      db.prepare('UPDATE mining_sessions SET daily_rate_bell = ? WHERE id = ?').run(
        targetDailyRateBell,
        session.id
      );
      return true;
    }

    const updateRes = db
      .prepare(
        `UPDATE mining_sessions
         SET status = 'claimed',
             claimed_micro = ?,
             last_claimed_at = ?
         WHERE id = ? AND status = 'running'`
      )
      .run(accrual.accruedMicro, nowMs, session.id);

    if (updateRes.changes !== 1) return false;

    const idempotencyKey = `${userId}:${session.id}:lvl_${crypto.randomUUID()}`;
    db.prepare(
      `INSERT INTO mining_claims (user_id, session_id, amount_micro, idempotency_key, claimed_at)
       VALUES (?, ?, ?, ?, ?)`
    ).run(userId, session.id, accrual.accruedMicro, idempotencyKey, nowMs);

    const newBalanceMicro = user.balance_micro + accrual.accruedMicro;
    const newTotalMinedMicro = user.total_mined_micro + accrual.accruedMicro;

    db.prepare(
      `UPDATE users
       SET balance_micro = ?,
           total_mined_micro = ?,
           last_active_at = ?
       WHERE id = ?`
    ).run(newBalanceMicro, newTotalMinedMicro, nowMs, userId);

    db.prepare(
      `INSERT INTO transactions (user_id, tx_type, amount_micro, balance_after_micro, description, reference_id, created_at)
       VALUES (?, 'mining_claim', ?, ?, ?, ?, ?)`
    ).run(
      userId,
      accrual.accruedMicro,
      newBalanceMicro,
      `Mining level update settle (#${session.id})`,
      `level_sync_${session.id}`,
      nowMs
    );

    const newEndsAt = nowMs + sessionDurationSec * 1000;
    db.prepare(
      `INSERT INTO mining_sessions (
        user_id, status, daily_rate_bell, multiplier_bps, started_at, ends_at, claimed_micro, created_at
      ) VALUES (?, 'running', ?, ?, ?, ?, 0, ?)`
    ).run(userId, targetDailyRateBell, user.boost_bps, nowMs, newEndsAt, nowMs);

    return true;
  });
}
