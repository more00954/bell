import { config } from '../config.ts';
import { getDb, getSetting, runInTransaction, DEFAULT_MINING_LEVELS } from '../db.ts';
import { resolveLevelForBellgram } from '../../src/lib/bellMath.ts';
import { ServiceError, syncMiningSessionRateForUser } from './miningService.ts';
import { finalizePendingReferralOnWalletVerified } from './referralService.ts';
import type { MiningLevel } from '../../src/types.ts';

const TON_ADDRESS_REGEX = /^(EQ|UQ|kQ|0Q)[A-Za-z0-9_-]{46}$|^0:[0-9a-fA-F]{64}$/;

export function convertJettonUnitsToMicro(rawUnitsStr: string, decimals = 9): number {
  const cleaned = (rawUnitsStr || '').trim();
  if (!/^\d+$/.test(cleaned)) return 0;
  const safeDecimals = Math.max(0, Math.min(18, Math.floor(Number(decimals) || 9)));
  const raw = BigInt(cleaned);
  let microBigInt: bigint;
  if (safeDecimals >= 4) {
    microBigInt = raw / 10n ** BigInt(safeDecimals - 4);
  } else {
    microBigInt = raw * 10n ** BigInt(4 - safeDecimals);
  }
  const maxSafe = BigInt(Number.MAX_SAFE_INTEGER);
  if (microBigInt > maxSafe) return Number.MAX_SAFE_INTEGER;
  return Number(microBigInt);
}

async function fetchTonNativeBalanceNano(tonAddress: string): Promise<{
  ok: boolean;
  tonBalanceNano: number;
}> {
  const headers: Record<string, string> = {};
  if (config.toncenterApiKey) {
    headers['X-API-Key'] = config.toncenterApiKey;
  }

  try {
    const url = new URL('https://toncenter.com/api/v2/getAddressBalance');
    url.searchParams.set('address', tonAddress);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4500);
    const resp = await fetch(url.toString(), { headers, signal: controller.signal });
    clearTimeout(timer);
    if (resp.ok) {
      const json = (await resp.json()) as { ok?: boolean; result?: string };
      if (json.ok && json.result !== undefined) {
        const parsed = Number(json.result);
        if (Number.isFinite(parsed) && parsed >= 0) {
          return { ok: true, tonBalanceNano: Math.floor(parsed) };
        }
      }
    }
  } catch {
    // Fallback to TonAPI below
  }

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4500);
    const resp = await fetch(
      `https://tonapi.io/v2/accounts/${encodeURIComponent(tonAddress)}`,
      { signal: controller.signal }
    );
    clearTimeout(timer);
    if (resp.ok) {
      const json = (await resp.json()) as { balance?: number | string };
      const parsed = Number(json.balance);
      if (Number.isFinite(parsed) && parsed >= 0) {
        return { ok: true, tonBalanceNano: Math.floor(parsed) };
      }
    }
  } catch {
    // Ignore offline fallback
  }

  return { ok: false, tonBalanceNano: 0 };
}

async function fetchJettonBalanceMicro(
  ownerAddress: string,
  jettonMasterAddress: string
): Promise<{ ok: boolean; bellgramBalanceMicro: number }> {
  if (!jettonMasterAddress) {
    return { ok: false, bellgramBalanceMicro: 0 };
  }

  const headers: Record<string, string> = {};
  if (config.toncenterApiKey) {
    headers['X-API-Key'] = config.toncenterApiKey;
  }

  // Primary: TonCenter v3 indexed jetton wallets lookup
  try {
    const url = new URL('https://toncenter.com/api/v3/jetton/wallets');
    url.searchParams.set('owner_address', ownerAddress);
    url.searchParams.set('jetton_address', jettonMasterAddress);
    url.searchParams.set('limit', '1');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4500);
    const resp = await fetch(url.toString(), { headers, signal: controller.signal });
    clearTimeout(timer);
    if (resp.ok) {
      const json = (await resp.json()) as {
        jetton_wallets?: Array<{ balance?: string; jetton?: string }>;
        metadata?: Record<
          string,
          { token_info?: Array<{ extra?: { decimals?: string | number } }> }
        >;
      };
      if (Array.isArray(json.jetton_wallets)) {
        if (json.jetton_wallets.length === 0) {
          return { ok: true, bellgramBalanceMicro: 0 };
        }
        const wallet = json.jetton_wallets[0];
        const jettonRaw = wallet.jetton || '';
        const decRaw =
          json.metadata?.[jettonRaw]?.token_info?.[0]?.extra?.decimals ?? 9;
        const decimals = Number.isFinite(Number(decRaw)) ? Number(decRaw) : 9;
        return {
          ok: true,
          bellgramBalanceMicro: convertJettonUnitsToMicro(wallet.balance || '0', decimals),
        };
      }
    }
  } catch {
    // Fallback to TonAPI below
  }

  // Fallback: TonAPI v2 account jetton balance
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4500);
    const resp = await fetch(
      `https://tonapi.io/v2/accounts/${encodeURIComponent(ownerAddress)}/jettons/${encodeURIComponent(jettonMasterAddress)}`,
      { signal: controller.signal }
    );
    clearTimeout(timer);
    if (resp.ok) {
      const json = (await resp.json()) as {
        balance?: string;
        jetton?: { decimals?: number };
      };
      const decimals =
        typeof json.jetton?.decimals === 'number' ? json.jetton.decimals : 9;
      return {
        ok: true,
        bellgramBalanceMicro: convertJettonUnitsToMicro(json.balance || '0', decimals),
      };
    }
    if (resp.status === 404) {
      // Account exists on TON without a Jetton wallet for this token yet (0 balance)
      return { ok: true, bellgramBalanceMicro: 0 };
    }
  } catch {
    // Ignore offline fallback
  }

  return { ok: false, bellgramBalanceMicro: 0 };
}

async function fetchOnChainBalances(tonAddress: string): Promise<{
  tonBalanceNano: number;
  tonOk: boolean;
  bellgramBalanceMicro: number;
  jettonOk: boolean;
  isVerifiedSource: boolean;
}> {
  const [tonRes, jettonRes] = await Promise.all([
    fetchTonNativeBalanceNano(tonAddress),
    fetchJettonBalanceMicro(tonAddress, config.bellgramJettonMaster),
  ]);

  return {
    tonBalanceNano: tonRes.tonBalanceNano,
    tonOk: tonRes.ok,
    bellgramBalanceMicro: jettonRes.bellgramBalanceMicro,
    jettonOk: jettonRes.ok,
    isVerifiedSource: tonRes.ok || jettonRes.ok,
  };
}

export async function connectTonWallet(
  userId: number,
  tonAddress: string,
  walletApp?: string
): Promise<{
  tonAddress: string;
  tonBalanceNano: number;
  bellgramBalanceMicro: number;
  isVerifiedSource: boolean;
}> {
  const cleaned = (tonAddress || '').trim();
  if (!TON_ADDRESS_REGEX.test(cleaned)) {
    throw new ServiceError('Invalid TON public wallet address format.', 400);
  }

  const { tonBalanceNano, bellgramBalanceMicro, isVerifiedSource } =
    await fetchOnChainBalances(cleaned);

  let newDailyBell = DEFAULT_MINING_LEVELS[0].dailyBell;

  runInTransaction((db) => {
    const now = Date.now();
    const levels = getSetting<MiningLevel[]>('mining_levels', DEFAULT_MINING_LEVELS);
    const { current } = resolveLevelForBellgram(bellgramBalanceMicro, levels);
    newDailyBell = current.dailyBell;

    db.prepare(
      `INSERT INTO wallet_connections (
        user_id, ton_address, wallet_app, ton_balance_nano, bellgram_balance_micro,
        is_verified_source, connected_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET
        ton_address = excluded.ton_address,
        wallet_app = excluded.wallet_app,
        ton_balance_nano = excluded.ton_balance_nano,
        bellgram_balance_micro = excluded.bellgram_balance_micro,
        is_verified_source = excluded.is_verified_source,
        updated_at = excluded.updated_at`
    ).run(
      userId,
      cleaned,
      (walletApp || 'TON Connect').slice(0, 64),
      tonBalanceNano,
      bellgramBalanceMicro,
      isVerifiedSource ? 1 : 0,
      now,
      now
    );

    db.prepare(
      `UPDATE users
       SET ton_balance_nano = ?,
           bellgram_balance_micro = ?,
           level_id = ?,
           last_active_at = ?
       WHERE id = ?`
    ).run(tonBalanceNano, bellgramBalanceMicro, current.level, now, userId);
  });

  syncMiningSessionRateForUser(userId, newDailyBell);

  return {
    tonAddress: cleaned,
    tonBalanceNano,
    bellgramBalanceMicro,
    isVerifiedSource,
  };
}

export async function refreshConnectedWalletBalance(
  userId: number,
  force = false
): Promise<{
  tonAddress: string;
  tonBalanceNano: number;
  bellgramBalanceMicro: number;
  isVerifiedSource: boolean;
} | null> {
  const db = getDb();
  const existing = db
    .prepare(
      'SELECT ton_address, ton_balance_nano, bellgram_balance_micro, is_verified_source, updated_at FROM wallet_connections WHERE user_id = ?'
    )
    .get(userId) as
    | {
        ton_address: string;
        ton_balance_nano: number;
        bellgram_balance_micro: number;
        is_verified_source: number;
        updated_at: number;
      }
    | undefined;

  if (!existing) return null;

  const now = Date.now();
  if (!force && existing.is_verified_source === 1 && now - existing.updated_at < 60_000) {
    return {
      tonAddress: existing.ton_address,
      tonBalanceNano: existing.ton_balance_nano,
      bellgramBalanceMicro: existing.bellgram_balance_micro,
      isVerifiedSource: true,
    };
  }

  const fetched = await fetchOnChainBalances(existing.ton_address);
  if (!fetched.isVerifiedSource) {
    return {
      tonAddress: existing.ton_address,
      tonBalanceNano: existing.ton_balance_nano,
      bellgramBalanceMicro: existing.bellgram_balance_micro,
      isVerifiedSource: Boolean(existing.is_verified_source),
    };
  }

  const nextTonNano = fetched.tonOk ? fetched.tonBalanceNano : existing.ton_balance_nano;
  const nextBellgramMicro = fetched.jettonOk
    ? fetched.bellgramBalanceMicro
    : existing.bellgram_balance_micro;

  let nextDailyBell = DEFAULT_MINING_LEVELS[0].dailyBell;

  runInTransaction((txDb) => {
    const levels = getSetting<MiningLevel[]>('mining_levels', DEFAULT_MINING_LEVELS);
    const { current } = resolveLevelForBellgram(nextBellgramMicro, levels);
    nextDailyBell = current.dailyBell;

    txDb
      .prepare(
        `UPDATE wallet_connections
         SET ton_balance_nano = ?,
             bellgram_balance_micro = ?,
             is_verified_source = 1,
             updated_at = ?
         WHERE user_id = ?`
      )
      .run(nextTonNano, nextBellgramMicro, now, userId);

    txDb
      .prepare(
        `UPDATE users
         SET ton_balance_nano = ?,
             bellgram_balance_micro = ?,
             level_id = ?,
             last_active_at = ?
         WHERE id = ?`
      )
      .run(nextTonNano, nextBellgramMicro, current.level, now, userId);
  });

  syncMiningSessionRateForUser(userId, nextDailyBell);

  return {
    tonAddress: existing.ton_address,
    tonBalanceNano: nextTonNano,
    bellgramBalanceMicro: nextBellgramMicro,
    isVerifiedSource: true,
  };
}

export function disconnectTonWallet(userId: number): void {
  let baseDailyBell = DEFAULT_MINING_LEVELS[0].dailyBell;
  runInTransaction((db) => {
    const levels = getSetting<MiningLevel[]>('mining_levels', DEFAULT_MINING_LEVELS);
    const { current } = resolveLevelForBellgram(0, levels);
    baseDailyBell = current.dailyBell;

    db.prepare('DELETE FROM wallet_connections WHERE user_id = ?').run(userId);
    db.prepare(
      `UPDATE users
       SET ton_balance_nano = 0,
           bellgram_balance_micro = 0,
           level_id = ?,
           last_active_at = ?
       WHERE id = ?`
    ).run(current.level, Date.now(), userId);
  });
  syncMiningSessionRateForUser(userId, baseDailyBell);
}

function crc16Ccitt(data: Buffer): number {
  let crc = 0;
  for (let i = 0; i < data.length; i++) {
    crc ^= data[i] << 8;
    for (let bit = 0; bit < 8; bit++) {
      if ((crc & 0x8000) !== 0) {
        crc = ((crc << 1) ^ 0x1021) & 0xffff;
      } else {
        crc = (crc << 1) & 0xffff;
      }
    }
  }
  return crc;
}

export function normalizeTonAddressToRaw(address: string): string | null {
  const cleaned = (address || '').trim();
  if (!cleaned) return null;

  const rawMatch = cleaned.match(/^(-?\d+):([0-9a-fA-F]{64})$/);
  if (rawMatch) {
    return `${Number(rawMatch[1])}:${rawMatch[2].toLowerCase()}`;
  }

  if (!/^(EQ|UQ|kQ|0Q)[A-Za-z0-9_-]{46}$/.test(cleaned)) {
    return null;
  }

  const base64Std = cleaned.replace(/-/g, '+').replace(/_/g, '/');
  const bytes = Buffer.from(base64Std, 'base64');
  if (bytes.length !== 36) return null;

  const expectedCrc = crc16Ccitt(bytes.subarray(0, 34));
  const actualCrc = bytes.readUInt16BE(34);
  if (expectedCrc !== actualCrc) return null;

  const workchain = bytes.readInt8(1);
  const hashHex = bytes.subarray(2, 34).toString('hex').toLowerCase();
  return `${workchain}:${hashHex}`;
}

interface ParsedIncomingTonTx {
  txHash: string;
  sourceRaw: string;
  destRaw: string;
  valueNano: number;
  aborted: boolean;
}

function extractMsgAddress(field: unknown): string {
  if (typeof field === 'string') return field;
  if (field && typeof field === 'object' && 'address' in field) {
    return String((field as { address?: unknown }).address || '');
  }
  return '';
}

async function fetchRecipientIncomingTxs(recipientAddress: string): Promise<{
  ok: boolean;
  txs: ParsedIncomingTonTx[];
}> {
  const headers: Record<string, string> = {};
  if (config.toncenterApiKey) {
    headers['X-API-Key'] = config.toncenterApiKey;
  }

  // Primary: TonCenter v3 indexed transactions
  try {
    const url = new URL('https://toncenter.com/api/v3/transactions');
    url.searchParams.set('account', recipientAddress);
    url.searchParams.set('limit', '40');
    url.searchParams.set('sort', 'desc');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    const resp = await fetch(url.toString(), { headers, signal: controller.signal });
    clearTimeout(timer);
    if (resp.ok) {
      const json = (await resp.json()) as {
        transactions?: Array<{
          hash?: string;
          description?: { aborted?: boolean };
          in_msg?: {
            source?: string | { address?: string };
            destination?: string | { address?: string };
            value?: string | number;
          };
        }>;
      };
      if (Array.isArray(json.transactions)) {
        const parsed: ParsedIncomingTonTx[] = [];
        for (const tx of json.transactions) {
          const txHash = String(tx.hash || '').trim();
          const sourceRaw = normalizeTonAddressToRaw(extractMsgAddress(tx.in_msg?.source));
          const destRaw = normalizeTonAddressToRaw(extractMsgAddress(tx.in_msg?.destination));
          const valueNano = Number(tx.in_msg?.value || 0);
          if (txHash && sourceRaw && destRaw && Number.isFinite(valueNano) && valueNano > 0) {
            parsed.push({
              txHash,
              sourceRaw,
              destRaw,
              valueNano: Math.floor(valueNano),
              aborted: Boolean(tx.description?.aborted),
            });
          }
        }
        return { ok: true, txs: parsed };
      }
    }
  } catch {
    // Fallback to TonCenter v2 / TonAPI v2 below
  }

  // Fallback 1: TonCenter v2 getTransactions
  try {
    const url = new URL('https://toncenter.com/api/v2/getTransactions');
    url.searchParams.set('address', recipientAddress);
    url.searchParams.set('limit', '40');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    const resp = await fetch(url.toString(), { headers, signal: controller.signal });
    clearTimeout(timer);
    if (resp.ok) {
      const json = (await resp.json()) as {
        ok?: boolean;
        result?: Array<{
          transaction_id?: { hash?: string };
          in_msg?: {
            source?: string | { address?: string };
            destination?: string | { address?: string };
            value?: string | number;
          };
        }>;
      };
      if (json.ok && Array.isArray(json.result)) {
        const parsed: ParsedIncomingTonTx[] = [];
        for (const tx of json.result) {
          const txHash = String(tx.transaction_id?.hash || '').trim();
          const sourceRaw = normalizeTonAddressToRaw(extractMsgAddress(tx.in_msg?.source));
          const destRaw = normalizeTonAddressToRaw(extractMsgAddress(tx.in_msg?.destination));
          const valueNano = Number(tx.in_msg?.value || 0);
          if (txHash && sourceRaw && destRaw && Number.isFinite(valueNano) && valueNano > 0) {
            parsed.push({
              txHash,
              sourceRaw,
              destRaw,
              valueNano: Math.floor(valueNano),
              aborted: false,
            });
          }
        }
        return { ok: true, txs: parsed };
      }
    }
  } catch {
    // Fallback to TonAPI v2 below
  }

  // Fallback 2: TonAPI v2 blockchain account transactions
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    const resp = await fetch(
      `https://tonapi.io/v2/blockchain/accounts/${encodeURIComponent(recipientAddress)}/transactions?limit=40`,
      { signal: controller.signal }
    );
    clearTimeout(timer);
    if (resp.ok) {
      const json = (await resp.json()) as {
        transactions?: Array<{
          hash?: string;
          aborted?: boolean;
          success?: boolean;
          in_msg?: {
            source?: string | { address?: string };
            destination?: string | { address?: string };
            value?: string | number;
          };
        }>;
      };
      if (Array.isArray(json.transactions)) {
        const parsed: ParsedIncomingTonTx[] = [];
        for (const tx of json.transactions) {
          const txHash = String(tx.hash || '').trim();
          const sourceRaw = normalizeTonAddressToRaw(extractMsgAddress(tx.in_msg?.source));
          const destRaw = normalizeTonAddressToRaw(extractMsgAddress(tx.in_msg?.destination));
          const valueNano = Number(tx.in_msg?.value || 0);
          if (txHash && sourceRaw && destRaw && Number.isFinite(valueNano) && valueNano > 0) {
            parsed.push({
              txHash,
              sourceRaw,
              destRaw,
              valueNano: Math.floor(valueNano),
              aborted: Boolean(tx.aborted) || tx.success === false,
            });
          }
        }
        return { ok: true, txs: parsed };
      }
    }
  } catch {
    // All explorers unreachable
  }

  return { ok: false, txs: [] };
}

export async function confirmWalletVerification(userId: number): Promise<{
  verified: boolean;
  pending?: boolean;
  txHash?: string;
  message: string;
}> {
  const db = getDb();
  const user = db
    .prepare('SELECT id, wallet_verified, wallet_verified_tx_hash, is_banned FROM users WHERE id = ?')
    .get(userId) as
    | { id: number; wallet_verified: number; wallet_verified_tx_hash: string | null; is_banned: number }
    | undefined;

  if (!user) throw new ServiceError('User not found.', 404);
  if (user.is_banned) throw new ServiceError('This account has been suspended.', 403);

  if (user.wallet_verified === 1) {
    return {
      verified: true,
      txHash: user.wallet_verified_tx_hash || undefined,
      message: 'Your TON wallet is already verified.',
    };
  }

  const walletRow = db
    .prepare('SELECT ton_address FROM wallet_connections WHERE user_id = ?')
    .get(userId) as { ton_address: string } | undefined;

  if (!walletRow) {
    throw new ServiceError('Connect your TON wallet first before verifying.', 400);
  }

  const senderRaw = normalizeTonAddressToRaw(walletRow.ton_address);
  const recipientRaw = normalizeTonAddressToRaw(config.walletVerifyAddress);
  if (!senderRaw || !recipientRaw) {
    throw new ServiceError('Invalid TON wallet verification address configuration.', 400);
  }

  const fetched = await fetchRecipientIncomingTxs(config.walletVerifyAddress);
  if (!fetched.ok) {
    throw new ServiceError(
      'Unable to reach TON blockchain explorers right now. Please try again in a few seconds.',
      503
    );
  }

  const candidates = fetched.txs.filter(
    (tx) =>
      !tx.aborted &&
      tx.destRaw === recipientRaw &&
      tx.sourceRaw === senderRaw &&
      tx.valueNano >= config.walletVerifyAmountNano
  );

  if (candidates.length === 0) {
    return {
      verified: false,
      pending: true,
      message:
        'No confirmed 0.05 TON transfer from your connected wallet was detected yet. Wait 10–15 seconds after sending and check again.',
    };
  }

  const matched = runInTransaction((txDb) => {
    const fresh = txDb
      .prepare('SELECT wallet_verified, wallet_verified_tx_hash FROM users WHERE id = ?')
      .get(userId) as { wallet_verified: number; wallet_verified_tx_hash: string | null };

    if (fresh.wallet_verified === 1) {
      return { already: true, txHash: fresh.wallet_verified_tx_hash || '' };
    }

    const checkUsed = txDb.prepare('SELECT id FROM wallet_verifications WHERE tx_hash = ?');
    const unused = candidates.find((c) => !checkUsed.get(c.txHash));
    if (!unused) {
      return null;
    }

    const now = Date.now();
    txDb
      .prepare(
        `INSERT INTO wallet_verifications (
          user_id, sender_address, recipient_address, amount_nano, tx_hash, status, verified_at
        ) VALUES (?, ?, ?, ?, ?, 'verified', ?)`
      )
      .run(
        userId,
        walletRow.ton_address,
        config.walletVerifyAddress,
        unused.valueNano,
        unused.txHash,
        now
      );

    txDb
      .prepare(
        `UPDATE users
         SET wallet_verified = 1,
             wallet_verified_tx_hash = ?,
             wallet_verified_at = ?,
             last_active_at = ?
         WHERE id = ?`
      )
      .run(unused.txHash, now, now, userId);

    finalizePendingReferralOnWalletVerified(txDb, userId, now);

    return { already: false, txHash: unused.txHash };
  });

  if (!matched) {
    return {
      verified: false,
      pending: true,
      message:
        'No new unused 0.05 TON transfer from your connected wallet was found yet.',
    };
  }

  return {
    verified: true,
    txHash: matched.txHash,
    message: 'Wallet verified on TON! Withdrawals are now unlocked.',
  };
}

