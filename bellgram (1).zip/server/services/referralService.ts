import type { DatabaseSync } from 'node:sqlite';
import { getDb, getSetting } from '../db.ts';
import { config } from '../config.ts';
import { bellToMicro, microToBell } from '../../src/lib/bellMath.ts';
import type { FriendItem, FriendsSummary } from '../../src/types.ts';

export function capturePendingReferral(
  db: DatabaseSync,
  newUserId: number,
  startParam: string
): boolean {
  const match = /^ref_([A-Za-z0-9_]{1,64})$/.exec(startParam.trim());
  if (!match) return false;

  const referrerTelegramId = match[1];
  const referrer = db
    .prepare('SELECT id, is_banned FROM users WHERE telegram_id = ?')
    .get(referrerTelegramId) as { id: number; is_banned: number } | undefined;

  if (!referrer || referrer.id === newUserId || referrer.is_banned) {
    return false;
  }

  const alreadyReferred = db
    .prepare('SELECT id FROM referrals WHERE referred_user_id = ?')
    .get(newUserId);
  if (alreadyReferred) return false;

  const targetUser = db
    .prepare('SELECT wallet_verified, pending_referrer_id FROM users WHERE id = ?')
    .get(newUserId) as
    | { wallet_verified: number; pending_referrer_id: number | null }
    | undefined;
  if (!targetUser || targetUser.pending_referrer_id !== null) {
    return false;
  }

  if (targetUser.wallet_verified === 1) {
    return creditReferralByIds(db, referrer.id, newUserId, Date.now());
  }

  db.prepare('UPDATE users SET pending_referrer_id = ? WHERE id = ? AND pending_referrer_id IS NULL').run(
    referrer.id,
    newUserId
  );
  return true;
}

export function finalizePendingReferralOnWalletVerified(
  db: DatabaseSync,
  verifiedUserId: number,
  nowMs: number
): boolean {
  const user = db
    .prepare('SELECT wallet_verified, pending_referrer_id FROM users WHERE id = ?')
    .get(verifiedUserId) as
    | { wallet_verified: number; pending_referrer_id: number | null }
    | undefined;

  if (!user || user.wallet_verified !== 1 || !user.pending_referrer_id) {
    return false;
  }

  const referrerId = user.pending_referrer_id;
  db.prepare('UPDATE users SET pending_referrer_id = NULL WHERE id = ?').run(verifiedUserId);

  return creditReferralByIds(db, referrerId, verifiedUserId, nowMs);
}

export function applyVerifiedReferral(
  db: DatabaseSync,
  newUserId: number,
  startParam: string,
  nowMs: number
): boolean {
  const match = /^ref_([A-Za-z0-9_]{1,64})$/.exec(startParam.trim());
  if (!match) return false;

  const referrerTelegramId = match[1];
  const referrer = db
    .prepare('SELECT id, is_banned FROM users WHERE telegram_id = ?')
    .get(referrerTelegramId) as { id: number; is_banned: number } | undefined;

  if (!referrer || referrer.id === newUserId || referrer.is_banned) {
    return false;
  }

  const referredUser = db
    .prepare('SELECT wallet_verified FROM users WHERE id = ?')
    .get(newUserId) as { wallet_verified: number } | undefined;

  if (!referredUser || referredUser.wallet_verified !== 1) {
    // Store pending attribution until the invited user verifies their TON wallet
    db.prepare(
      'UPDATE users SET pending_referrer_id = ? WHERE id = ? AND pending_referrer_id IS NULL'
    ).run(referrer.id, newUserId);
    return false;
  }

  return creditReferralByIds(db, referrer.id, newUserId, nowMs);
}

function creditReferralByIds(
  db: DatabaseSync,
  referrerId: number,
  referredUserId: number,
  nowMs: number
): boolean {
  const referrer = db
    .prepare('SELECT id, balance_micro, is_banned FROM users WHERE id = ?')
    .get(referrerId) as { id: number; balance_micro: number; is_banned: number } | undefined;

  if (!referrer || referrer.id === referredUserId || referrer.is_banned) {
    return false;
  }

  const referred = db
    .prepare('SELECT id, balance_micro, wallet_verified FROM users WHERE id = ?')
    .get(referredUserId) as
    | { id: number; balance_micro: number; wallet_verified: number }
    | undefined;

  if (!referred || referred.wallet_verified !== 1) {
    return false;
  }

  // Prevent duplicate referral for the same referred user
  const existing = db
    .prepare('SELECT id FROM referrals WHERE referred_user_id = ?')
    .get(referredUserId);
  if (existing) return false;

  const bonusBell = getSetting<number>('referral_bonus_bell', 50);
  const bonusMicro = bellToMicro(bonusBell);

  const refRes = db
    .prepare(
      `INSERT INTO referrals (referrer_id, referred_user_id, source, created_at)
       VALUES (?, ?, 'telegram_deep_link', ?)`
    )
    .run(referrer.id, referredUserId, nowMs);

  const referralId = Number(refRes.lastInsertRowid);

  db.prepare(
    `INSERT INTO referral_rewards (
      referral_id, referrer_id, referred_user_id, referrer_amount_micro, referred_amount_micro, created_at
    ) VALUES (?, ?, ?, ?, ?, ?)`
  ).run(referralId, referrer.id, referredUserId, bonusMicro, bonusMicro, nowMs);

  // Credit referrer
  const newReferrerBal = referrer.balance_micro + bonusMicro;
  db.prepare('UPDATE users SET balance_micro = ? WHERE id = ?').run(newReferrerBal, referrer.id);
  db.prepare(
    `INSERT INTO transactions (user_id, tx_type, amount_micro, balance_after_micro, description, reference_id, created_at)
     VALUES (?, 'referral_bonus', ?, ?, ?, ?, ?)`
  ).run(
    referrer.id,
    bonusMicro,
    newReferrerBal,
    'Referral reward for inviting a friend',
    `ref_${referralId}`,
    nowMs
  );

  // Credit referred user
  const newUserBal = referred.balance_micro + bonusMicro;
  db.prepare('UPDATE users SET balance_micro = ?, pending_referrer_id = NULL WHERE id = ?').run(
    newUserBal,
    referredUserId
  );
  db.prepare(
    `INSERT INTO transactions (user_id, tx_type, amount_micro, balance_after_micro, description, reference_id, created_at)
     VALUES (?, 'referral_welcome', ?, ?, ?, ?, ?)`
  ).run(
    referredUserId,
    bonusMicro,
    newUserBal,
    'Welcome bonus from friend referral',
    `ref_welcome_${referralId}`,
    nowMs
  );

  return true;
}

export function getFriendsSummary(userId: number): FriendsSummary {
  const db = getDb();
  const user = db
    .prepare('SELECT telegram_id FROM users WHERE id = ?')
    .get(userId) as { telegram_id: string };

  const botUsername = getSetting<string>('bot_username', config.botUsername);
  const referralBonusBell = getSetting<number>('referral_bonus_bell', 50);

  const directRows = db
    .prepare(
      `SELECT u.id, u.telegram_id, u.username, u.first_name, r.created_at,
              COALESCE(rr.referrer_amount_micro, 0) AS reward_micro
       FROM referrals r
       JOIN users u ON u.id = r.referred_user_id
       LEFT JOIN referral_rewards rr ON rr.referral_id = r.id
       WHERE r.referrer_id = ?
       ORDER BY r.created_at DESC
       LIMIT 100`
    )
    .all(userId) as Array<{
    id: number;
    telegram_id: string;
    username: string | null;
    first_name: string;
    created_at: number;
    reward_micro: number;
  }>;

  const pendingRows = db
    .prepare(
      `SELECT u.id, u.telegram_id, u.username, u.first_name, u.created_at
       FROM users u
       WHERE u.pending_referrer_id = ?
         AND NOT EXISTS (SELECT 1 FROM referrals r WHERE r.referred_user_id = u.id)
       ORDER BY u.created_at DESC
       LIMIT 100`
    )
    .all(userId) as Array<{
    id: number;
    telegram_id: string;
    username: string | null;
    first_name: string;
    created_at: number;
  }>;

  const fofRow = db
    .prepare(
      `SELECT COUNT(DISTINCT r2.referred_user_id) AS cnt
       FROM referrals r1
       JOIN referrals r2 ON r2.referrer_id = r1.referred_user_id
       WHERE r1.referrer_id = ?`
    )
    .get(userId) as { cnt: number };

  const verifiedFriends: Array<FriendItem & { sortAt: number }> = directRows.map((row) => ({
    id: row.id,
    telegramId: row.telegram_id,
    username: row.username,
    firstName: row.first_name,
    joinedAt: new Date(row.created_at).toISOString(),
    bonusBell: microToBell(row.reward_micro),
    walletVerified: true,
    sortAt: row.created_at,
  }));

  const pendingFriends: Array<FriendItem & { sortAt: number }> = pendingRows.map((row) => ({
    id: row.id,
    telegramId: row.telegram_id,
    username: row.username,
    firstName: row.first_name,
    joinedAt: new Date(row.created_at).toISOString(),
    bonusBell: 0,
    walletVerified: false,
    sortAt: row.created_at,
  }));

  const friends: FriendItem[] = [...verifiedFriends, ...pendingFriends]
    .sort((a, b) => b.sortAt - a.sortAt)
    .slice(0, 100)
    .map(({ sortAt: _sortAt, ...item }) => item);

  return {
    inviteLink: `https://t.me/${botUsername}?start=ref_${user.telegram_id}`,
    botUsername,
    referralBonusBell,
    friendsCount: verifiedFriends.length,
    friendsOfFriendsCount: fofRow?.cnt ?? 0,
    friends,
  };
}
