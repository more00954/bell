import crypto from 'node:crypto';
import { config } from '../config.ts';
import { getSetting, setSetting } from '../db.ts';
import {
  checkTelegramChannelMembership,
  escapeTelegramHtml,
  sendTelegramMessage,
} from '../telegramAuth.ts';
import { syncLiveChannelsOnEntry, upsertTelegramUser } from './userService.ts';
import type { ChannelConfig } from '../../src/types.ts';

interface TelegramUserObj {
  id: number;
  first_name?: string;
  last_name?: string;
  username?: string;
  language_code?: string;
}

interface TelegramUpdate {
  update_id?: number;
  message?: {
    message_id: number;
    from?: TelegramUserObj;
    chat: { id: number; type: string };
    text?: string;
  };
  callback_query?: {
    id: string;
    from: TelegramUserObj;
    message?: { chat: { id: number } };
    data?: string;
  };
}

export function getWebhookSecretToken(): string {
  if (!config.botToken) return '';
  return crypto
    .createHmac('sha256', 'bellgram-webhook-secret-v1')
    .update(config.botToken)
    .digest('hex')
    .slice(0, 48);
}

export function verifyWebhookSecretHeader(headerVal: string | undefined): boolean {
  const expected = getWebhookSecretToken();
  if (!expected || !headerVal) return false;
  const a = Buffer.from(headerVal.trim());
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

let lastSyncedPublicOrigin: string | null = null;
let syncInFlightOrigin: string | null = null;

function getBaseAppUrl(overrideUrl?: string): string {
  const detected = getSetting<string>('detected_app_url', '');
  const raw = (overrideUrl || config.appUrl || detected || '').trim().replace(/\/+$/, '');
  return /^https?:\/\//i.test(raw) ? raw : '';
}

export function isPublicWebhookHost(baseUrl: string): boolean {
  try {
    const parsed = new URL(baseUrl);
    if (parsed.protocol !== 'https:') return false;
    const host = parsed.hostname.toLowerCase();
    if (
      host === 'localhost' ||
      host === '127.0.0.1' ||
      host.startsWith('10.') ||
      host.startsWith('192.168.') ||
      host.startsWith('ais-dev-')
    ) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

export function notePublicRequestOrigin(origin: string | undefined): void {
  if (!origin) return;
  const cleanOrigin = origin.trim().replace(/\/+$/, '');
  if (!isPublicWebhookHost(cleanOrigin)) return;

  if (!config.hasExplicitAppUrl && config.appUrl !== cleanOrigin) {
    config.appUrl = cleanOrigin;
    try {
      setSetting('detected_app_url', cleanOrigin);
    } catch {
      // Ignore DB write errors on read path
    }
  }

  const targetUrl = config.hasExplicitAppUrl ? config.appUrl : cleanOrigin;
  if (!config.botToken || !isPublicWebhookHost(targetUrl)) return;
  if (lastSyncedPublicOrigin === targetUrl || syncInFlightOrigin === targetUrl) return;

  syncInFlightOrigin = targetUrl;
  void syncTelegramBotSetup(targetUrl)
    .then((res) => {
      if (res.ok) {
        lastSyncedPublicOrigin = targetUrl;
        console.log(`Telegram bot menu & webhook auto-synced to ${targetUrl}`);
      }
    })
    .finally(() => {
      if (syncInFlightOrigin === targetUrl) {
        syncInFlightOrigin = null;
      }
    });
}

function buildInlineKeyboard(baseUrl: string, startParam?: string | null) {
  const rows: Array<Array<Record<string, unknown>>> = [];
  if (/^https:\/\//i.test(baseUrl)) {
    let homeUrl = baseUrl;
    if (startParam) {
      const sep = homeUrl.includes('?') ? '&' : '?';
      homeUrl = `${homeUrl}${sep}tgWebAppStartParam=${encodeURIComponent(startParam)}`;
    }
    const walletSep = baseUrl.includes('?') ? '&' : '?';
    const walletUrl = `${baseUrl}${walletSep}tab=wallet`;
    rows.push([
      {
        text: '🔔 Open BELLGRAM | فتح التطبيق',
        web_app: { url: homeUrl },
      },
    ]);
    rows.push([
      {
        text: '💸 Withdraw | سحب الأرباح',
        web_app: { url: walletUrl },
      },
    ]);
  }
  rows.push([
    {
      text: '✅ Check Channels | تحقق من القنوات',
      callback_data: 'check_channels',
    },
    {
      text: '👥 Invite Link | رابط الدعوة',
      callback_data: 'my_invite',
    },
  ]);

  return { inline_keyboard: rows };
}

async function callTelegramBotApi(
  method: string,
  payload: Record<string, unknown>
): Promise<{ ok: boolean; description?: string }> {
  if (!config.botToken) {
    return { ok: false, description: 'BOT_TOKEN is not configured.' };
  }
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 6000);
    const resp = await fetch(`https://api.telegram.org/bot${config.botToken}/${method}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    clearTimeout(timer);
    const json = (await resp.json().catch(() => ({}))) as {
      ok?: boolean;
      description?: string;
    };
    return { ok: Boolean(json.ok), description: json.description };
  } catch {
    return { ok: false, description: 'Network error contacting Telegram Bot API.' };
  }
}

export async function syncTelegramBotSetup(overrideBaseUrl?: string): Promise<{
  ok: boolean;
  appUrl: string;
  webhookUrl: string | null;
  menuButtonSet: boolean;
  commandsSet: boolean;
  message: string;
}> {
  const baseUrl = getBaseAppUrl(overrideBaseUrl);
  if (!config.botToken) {
    return {
      ok: false,
      appUrl: baseUrl,
      webhookUrl: null,
      menuButtonSet: false,
      commandsSet: false,
      message: 'BOT_TOKEN is missing on server.',
    };
  }

  if (!isPublicWebhookHost(baseUrl)) {
    return {
      ok: false,
      appUrl: baseUrl,
      webhookUrl: null,
      menuButtonSet: false,
      commandsSet: false,
      message: `Skipped auto-webhook on non-public URL (${baseUrl}).`,
    };
  }

  const commandsRes = await callTelegramBotApi('setMyCommands', {
    commands: [
      { command: 'start', description: 'Open BELLGRAM Mining App 🔔' },
      { command: 'withdraw', description: 'Withdraw BELL to TON Wallet 💸' },
    ],
  });

  const menuRes = await callTelegramBotApi('setChatMenuButton', {
    menu_button: {
      type: 'web_app',
      text: 'BELLGRAM 🔔',
      web_app: { url: baseUrl },
    },
  });

  const webhookUrl = `${baseUrl}/api/telegram/webhook`;
  const webhookRes = await callTelegramBotApi('setWebhook', {
    url: webhookUrl,
    secret_token: getWebhookSecretToken(),
    allowed_updates: ['message', 'callback_query'],
  });

  const ok = commandsRes.ok && menuRes.ok && webhookRes.ok;
  return {
    ok,
    appUrl: baseUrl,
    webhookUrl,
    menuButtonSet: menuRes.ok,
    commandsSet: commandsRes.ok,
    message: ok
      ? `Synced menu button and webhook to ${baseUrl}`
      : webhookRes.description || menuRes.description || commandsRes.description || 'Sync incomplete',
  };
}

export async function handleTelegramWebhookUpdate(
  update: TelegramUpdate,
  overrideBaseUrl?: string
): Promise<void> {
  const baseUrl = getBaseAppUrl(overrideBaseUrl);

  if (update.message && update.message.from && update.message.chat.type === 'private') {
    const from = update.message.from;
    const chatId = update.message.chat.id;
    const text = (update.message.text || '').trim();

    if (text.startsWith('/start')) {
      const parts = text.split(/\s+/);
      const startParam = parts.length > 1 ? parts[1].trim() : null;

      const botUser = upsertTelegramUser({
        telegramId: String(from.id),
        username: from.username || null,
        firstName: (from.first_name || 'User').slice(0, 80),
        lastName: from.last_name ? from.last_name.slice(0, 80) : null,
        languageCode: (from.language_code || 'en').slice(0, 12),
        startParam,
        isPreview: false,
        now: Date.now(),
      });
      void syncLiveChannelsOnEntry(botUser.id);

      const refNote =
        startParam && startParam.startsWith('ref_')
          ? '\n🎁 تم تسجيل رابط الدعوة الخاص بك! افتح التطبيق ووثّق محفظتك لتفعيل مكافأة الدعوة.'
          : '';

      const welcome = [
        `أهلاً بك يا <b>${escapeTelegramHtml(from.first_name || 'صديقي')}</b> في <b>BELLGRAM</b> 🔔`,
        '',
        '• عدّن عملة <b>BELL</b> يوميًا داخل التطبيق.',
        '• احصل على مكافآت الدخول اليومي لمدة 7 أيام.',
        '• ادعُ أصدقاءك واربط محفظة <b>TON</b> واسحب أرباحك.',
        '• استخدم الزر أدناه لفتح التطبيق مباشرة داخل تيليجرام:',
        refNote,
      ]
        .filter(Boolean)
        .join('\n');

      await sendTelegramMessage(
        config.botToken,
        chatId,
        welcome,
        buildInlineKeyboard(baseUrl, startParam)
      );
      return;
    }

    if (text.startsWith('/withdraw')) {
      upsertTelegramUser({
        telegramId: String(from.id),
        username: from.username || null,
        firstName: (from.first_name || 'User').slice(0, 80),
        lastName: from.last_name ? from.last_name.slice(0, 80) : null,
        languageCode: (from.language_code || 'en').slice(0, 12),
        startParam: null,
        isPreview: false,
        now: Date.now(),
      });

      await sendTelegramMessage(
        config.botToken,
        chatId,
        [
          '💸 <b>سحب عملة BELL</b>',
          '',
          'اضغط زر <b>Withdraw | سحب الأرباح</b> لفتح شاشة السحب وإرسال طلبك للإدارة.',
          'سيصلك إشعار مباشر هنا في البوت فور المراجعة (<b>مكتمل</b> أو <b>مرفوض مع السبب</b>).',
        ].join('\n'),
        buildInlineKeyboard(baseUrl)
      );
      return;
    }
  }

  if (update.callback_query) {
    const cq = update.callback_query;
    const data = cq.data || '';
    const chatId = cq.message?.chat.id || cq.from.id;

    if (data === 'check_channels') {
      const channels = getSetting<ChannelConfig[]>('required_channels', []);
      const missing: string[] = [];

      for (const ch of channels.filter((c) => c.isRequired)) {
        const res = await checkTelegramChannelMembership(config.botToken, ch.username, cq.from.id);
        if (!res.ok || !res.isMember) {
          missing.push(`@${ch.username.replace(/^@/, '')}`);
        }
      }

      if (missing.length === 0) {
        await callTelegramBotApi('answerCallbackQuery', {
          callback_query_id: cq.id,
          text: 'تم التحقق من اشتراكك في جميع القنوات! ✅',
          show_alert: true,
        });
        await sendTelegramMessage(
          config.botToken,
          chatId,
          '✅ جميع الاشتراكات مكتملة! يمكنك الآن فتح BELLGRAM وبدء التعدين:',
          buildInlineKeyboard(baseUrl)
        );
      } else {
        await callTelegramBotApi('answerCallbackQuery', {
          callback_query_id: cq.id,
          text: 'يرجى الاشتراك في القنوات المطلوبة أولاً.',
          show_alert: true,
        });
        await sendTelegramMessage(
          config.botToken,
          chatId,
          `⚠️ لم يتم التحقق من الاشتراك في:\n${escapeTelegramHtml(missing.join(' ، '))}\n\nاشترك ثم اضغط تحقق مجددًا.`,
          buildInlineKeyboard(baseUrl)
        );
      }
      return;
    }

    if (data === 'my_invite') {
      const botUsername = getSetting<string>('bot_username', config.botUsername).replace(/^@/, '');
      const referralBonus = getSetting<number>('referral_bonus_bell', 50);
      const inviteUrl = `https://t.me/${botUsername}?start=ref_${cq.from.id}`;

      await callTelegramBotApi('answerCallbackQuery', { callback_query_id: cq.id });
      await sendTelegramMessage(
        config.botToken,
        chatId,
        [
          '🔗 <b>رابط الدعوة الخاص بك:</b>',
          `<code>${escapeTelegramHtml(inviteUrl)}</code>`,
          '',
          `شارك هذا الرابط مع أصدقائك ليحصل كل منكما على <b>${referralBonus} BELL</b> عند انضمامهم وتوثيق محافظهم!`,
        ].join('\n'),
        buildInlineKeyboard(baseUrl)
      );
    }
  }
}
