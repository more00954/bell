import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import {
  getDb,
  getSetting,
  setSetting,
  runInTransaction,
  DEFAULT_MINING_LEVELS,
  DEFAULT_DAILY_REWARDS,
  DEFAULT_CHANNELS,
} from '../db.ts';
import { config } from '../config.ts';
import { bellToMicro, microToBell } from '../../src/lib/bellMath.ts';
import { getIpSubnetPrefix, normalizeIpAddress } from '../ipUtils.ts';
import { ServiceError } from './miningService.ts';
import { getAdminWithdrawals } from './withdrawService.ts';
import type { ChannelConfig, MiningLevel } from '../../src/types.ts';

export interface SimilarIpAccount {
  id: number;
  telegram_id: string;
  username: string | null;
  first_name: string;
  balance_micro: number;
  total_mined_micro: number;
  level_id: number;
  is_banned: number;
  last_ip: string | null;
  matched_ip: string;
  hit_count: number;
  first_seen_at: number;
  last_seen_at: number;
}

export interface SimilarIpGroup {
  key: string;
  matchType: 'exact' | 'subnet';
  userCount: number;
  bannedCount: number;
  totalBalanceMicro: number;
  lastSeenAt: number;
  accounts: SimilarIpAccount[];
}

function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPasswordHash(password: string, stored: string): boolean {
  const parts = stored.split(':');
  if (parts.length !== 2) return false;
  const [salt, hexHash] = parts;
  const expected = Buffer.from(hexHash, 'hex');
  const actual = crypto.scryptSync(password, salt, 64);
  if (expected.length !== actual.length) return false;
  return crypto.timingSafeEqual(expected, actual);
}

export function getAdminAuthStatus(): { needsSetup: boolean; envOverrideActive: boolean } {
  if (config.adminPasscode) {
    return { needsSetup: false, envOverrideActive: true };
  }
  const db = getDb();
  const countRow = db.prepare('SELECT COUNT(*) AS cnt FROM admin_users').get() as { cnt: number };
  return {
    needsSetup: (countRow?.cnt ?? 0) === 0,
    envOverrideActive: false,
  };
}

export function bootstrapFirstAdmin(password: string, ipAddress?: string): string {
  if (config.adminPasscode) {
    throw new ServiceError('Admin passcode is managed by environment configuration.', 409);
  }
  const trimmed = (password || '').trim();
  if (trimmed.length < 8) {
    throw new ServiceError('Admin password must be at least 8 characters.', 400);
  }

  return runInTransaction((db) => {
    const countRow = db.prepare('SELECT COUNT(*) AS cnt FROM admin_users').get() as { cnt: number };
    if ((countRow?.cnt ?? 0) > 0) {
      throw new ServiceError('Admin account has already been claimed.', 409);
    }

    const now = Date.now();
    const hash = hashPassword(trimmed);
    db.prepare(
      `INSERT INTO admin_users (username, password_hash, role, created_at, last_login_at)
       VALUES ('admin', ?, 'superadmin', ?, ?)`
    ).run(hash, now, now);

    logAdminAction(db, 'admin', 'bootstrap_claim', 'admin_users', 'admin', {}, ipAddress);
    return signAdminToken('admin');
  });
}

export function authenticateAdmin(password: string, ipAddress?: string): string {
  const input = (password || '').trim();
  if (!input) {
    throw new ServiceError('Password is required.', 400);
  }

  if (config.adminPasscode) {
    const a = Buffer.from(input);
    const b = Buffer.from(config.adminPasscode);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      throw new ServiceError('Invalid admin passcode.', 401);
    }
    const db = getDb();
    logAdminAction(db, 'env_admin', 'login', 'session', null, { mode: 'env' }, ipAddress);
    return signAdminToken('env_admin');
  }

  const db = getDb();
  const admin = db.prepare('SELECT * FROM admin_users ORDER BY id ASC LIMIT 1').get() as
    | { id: number; username: string; password_hash: string }
    | undefined;

  if (!admin) {
    throw new ServiceError('Admin setup is required before signing in.', 409);
  }

  if (!verifyPasswordHash(input, admin.password_hash)) {
    throw new ServiceError('Invalid admin password.', 401);
  }

  db.prepare('UPDATE admin_users SET last_login_at = ? WHERE id = ?').run(Date.now(), admin.id);
  logAdminAction(db, admin.username, 'login', 'session', String(admin.id), {}, ipAddress);
  return signAdminToken(admin.username);
}

export function adminChangePassword(
  actor: string,
  currentPassword: string,
  newPassword: string,
  ipAddress?: string
): void {
  if (config.adminPasscode) {
    throw new ServiceError(
      'Admin password is controlled by ADMIN_PASSCODE in server environment secrets.',
      409
    );
  }
  const current = (currentPassword || '').trim();
  const next = (newPassword || '').trim();
  if (!current) {
    throw new ServiceError('Current password is required.', 400);
  }
  if (next.length < 8 || next.length > 128) {
    throw new ServiceError('New admin password must be between 8 and 128 characters.', 400);
  }

  runInTransaction((db) => {
    const admin = db.prepare('SELECT * FROM admin_users ORDER BY id ASC LIMIT 1').get() as
      | { id: number; username: string; password_hash: string }
      | undefined;
    if (!admin) {
      throw new ServiceError('Admin account not found.', 404);
    }
    if (!verifyPasswordHash(current, admin.password_hash)) {
      throw new ServiceError('Current password is incorrect.', 401);
    }
    const newHash = hashPassword(next);
    db.prepare('UPDATE admin_users SET password_hash = ? WHERE id = ?').run(newHash, admin.id);
    logAdminAction(
      db,
      actor,
      'change_admin_password',
      'admin_users',
      String(admin.id),
      {},
      ipAddress
    );
  });
}

export function signAdminToken(actor: string): string {
  const payload = Buffer.from(
    JSON.stringify({
      sub: actor,
      role: 'superadmin',
      exp: Date.now() + 8 * 3600 * 1000,
      jti: crypto.randomUUID(),
    })
  ).toString('base64url');
  const sig = crypto
    .createHmac('sha256', config.sessionSecret)
    .update(payload)
    .digest('base64url');
  return `${payload}.${sig}`;
}

export function verifyAdminToken(authHeader: string | undefined): { actor: string } | null {
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const token = authHeader.slice(7).trim();
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [payloadB64, sigB64] = parts;

  const expectedSig = crypto
    .createHmac('sha256', config.sessionSecret)
    .update(payloadB64)
    .digest('base64url');

  const a = Buffer.from(sigB64);
  const b = Buffer.from(expectedSig);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;

  try {
    const parsed = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8')) as {
      sub: string;
      exp: number;
    };
    if (!parsed.sub || typeof parsed.exp !== 'number' || parsed.exp < Date.now()) {
      return null;
    }
    return { actor: parsed.sub };
  } catch {
    return null;
  }
}

function logAdminAction(
  db: ReturnType<typeof getDb>,
  actor: string,
  action: string,
  targetType: string,
  targetId: string | null,
  details: unknown,
  ipAddress?: string
): void {
  db.prepare(
    `INSERT INTO admin_audit_logs (
      admin_actor, action, target_type, target_id, details_json, ip_address, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(
    actor,
    action,
    targetType,
    targetId,
    JSON.stringify(details ?? {}),
    ipAddress || null,
    Date.now()
  );
}

export function getAdminDashboardData(searchTelegramId?: string) {
  const db = getDb();
  const dayAgoMs = Date.now() - 24 * 3600 * 1000;

  const userStats = db
    .prepare(
      `SELECT
         COUNT(*) AS totalUsers,
         SUM(CASE WHEN last_active_at >= ? THEN 1 ELSE 0 END) AS activeUsers24h,
         COALESCE(SUM(balance_micro), 0) AS totalBalanceMicro,
         COALESCE(SUM(total_mined_micro), 0) AS totalMinedMicro
       FROM users`
    )
    .get(dayAgoMs) as {
    totalUsers: number;
    activeUsers24h: number;
    totalBalanceMicro: number;
    totalMinedMicro: number;
  };

  const refStats = db.prepare('SELECT COUNT(*) AS totalReferrals FROM referrals').get() as {
    totalReferrals: number;
  };

  const trimmedQuery = (searchTelegramId || '').trim();
  const users = trimmedQuery
    ? db
        .prepare(
          `SELECT id, telegram_id, username, first_name, balance_micro, total_mined_micro,
                  level_id, channels_verified, is_banned, is_preview, last_ip, last_active_at, created_at
           FROM users
           WHERE telegram_id LIKE ? OR username LIKE ? OR first_name LIKE ? OR COALESCE(last_ip, '') LIKE ?
           ORDER BY id DESC LIMIT 50`
        )
        .all(`%${trimmedQuery}%`, `%${trimmedQuery}%`, `%${trimmedQuery}%`, `%${trimmedQuery}%`)
    : db
        .prepare(
          `SELECT id, telegram_id, username, first_name, balance_micro, total_mined_micro,
                  level_id, channels_verified, is_banned, is_preview, last_ip, last_active_at, created_at
           FROM users
           ORDER BY last_active_at DESC LIMIT 50`
        )
        .all();

  const similarIps = computeSimilarIpGroups(db);

  const recentTransactions = db
    .prepare(
      `SELECT t.id, t.user_id, u.telegram_id, u.first_name, t.tx_type, t.amount_micro,
              t.balance_after_micro, t.description, t.created_at
       FROM transactions t
       JOIN users u ON u.id = t.user_id
       ORDER BY t.id DESC LIMIT 40`
    )
    .all();

  const auditLogs = db
    .prepare(
      `SELECT id, admin_actor, action, target_type, target_id, details_json, ip_address, created_at
       FROM admin_audit_logs ORDER BY id DESC LIMIT 40`
    )
    .all();

  const missions = db
    .prepare('SELECT * FROM missions ORDER BY sort_order ASC, id ASC')
    .all();

  const withdrawals = getAdminWithdrawals();
  const pendingWithdrawalsCount = withdrawals.filter((w) => w.status === 'pending').length;

  return {
    stats: {
      totalUsers: userStats?.totalUsers ?? 0,
      activeUsers24h: userStats?.activeUsers24h ?? 0,
      totalBellDistributed: microToBell(userStats?.totalBalanceMicro ?? 0),
      totalMiningRewards: microToBell(userStats?.totalMinedMicro ?? 0),
      totalReferrals: refStats?.totalReferrals ?? 0,
      pendingWithdrawalsCount,
      similarIpGroupsCount: similarIps.length,
    },
    users,
    similarIps,
    recentTransactions,
    auditLogs,
    missions,
    withdrawals,
    settings: {
      miningLevels: getSetting<MiningLevel[]>('mining_levels', DEFAULT_MINING_LEVELS),
      dailyBonusSchedule: getSetting<number[]>('daily_bonus_schedule', DEFAULT_DAILY_REWARDS),
      requiredChannels: getSetting<ChannelConfig[]>('required_channels', DEFAULT_CHANNELS),
      referralBonusBell: getSetting<number>('referral_bonus_bell', 50),
      sessionDurationHours: getSetting<number>('session_duration_hours', 24),
      minClaimBell: getSetting<number>('min_claim_bell', 0.0001),
      minWithdrawBell: getSetting<number>('min_withdraw_bell', 50),
      botUsername: getSetting<string>('bot_username', config.botUsername),
    },
  };
}

function computeSimilarIpGroups(db: ReturnType<typeof getDb>): SimilarIpGroup[] {
  type IpRow = {
    user_id: number;
    ip_address: string;
    hit_count: number;
    first_seen_at: number;
    last_seen_at: number;
    telegram_id: string;
    username: string | null;
    first_name: string;
    balance_micro: number;
    total_mined_micro: number;
    level_id: number;
    is_banned: number;
    last_ip: string | null;
  };

  const rows = db
    .prepare(
      `SELECT ui.user_id, ui.ip_address, ui.hit_count, ui.first_seen_at, ui.last_seen_at,
              u.telegram_id, u.username, u.first_name, u.balance_micro, u.total_mined_micro,
              u.level_id, u.is_banned, u.last_ip
       FROM user_ips ui
       JOIN users u ON u.id = ui.user_id
       ORDER BY ui.last_seen_at DESC`
    )
    .all() as IpRow[];

  // Fallback for any user row carrying last_ip not yet mirrored in user_ips
  const seenPairs = new Set(rows.map((r) => `${r.user_id}:${r.ip_address}`));
  const fallbackUsers = db
    .prepare(
      `SELECT id AS user_id, last_ip, last_active_at, created_at,
              telegram_id, username, first_name, balance_micro, total_mined_micro,
              level_id, is_banned
       FROM users
       WHERE last_ip IS NOT NULL AND TRIM(last_ip) != ''`
    )
    .all() as Array<{
    user_id: number;
    last_ip: string;
    last_active_at: number;
    created_at: number;
    telegram_id: string;
    username: string | null;
    first_name: string;
    balance_micro: number;
    total_mined_micro: number;
    level_id: number;
    is_banned: number;
  }>;

  for (const u of fallbackUsers) {
    const normalized = normalizeIpAddress(u.last_ip);
    if (!normalized) continue;
    const key = `${u.user_id}:${normalized}`;
    if (!seenPairs.has(key)) {
      seenPairs.add(key);
      rows.push({
        user_id: u.user_id,
        ip_address: normalized,
        hit_count: 1,
        first_seen_at: u.created_at,
        last_seen_at: u.last_active_at,
        telegram_id: u.telegram_id,
        username: u.username,
        first_name: u.first_name,
        balance_micro: u.balance_micro,
        total_mined_micro: u.total_mined_micro,
        level_id: u.level_id,
        is_banned: u.is_banned,
        last_ip: normalized,
      });
    }
  }

  const exactBuckets = new Map<string, Map<number, SimilarIpAccount>>();
  const subnetBuckets = new Map<
    string,
    { ips: Set<string>; accounts: Map<number, SimilarIpAccount> }
  >();

  for (const r of rows) {
    const account: SimilarIpAccount = {
      id: r.user_id,
      telegram_id: r.telegram_id,
      username: r.username,
      first_name: r.first_name,
      balance_micro: r.balance_micro,
      total_mined_micro: r.total_mined_micro,
      level_id: r.level_id,
      is_banned: r.is_banned,
      last_ip: r.last_ip,
      matched_ip: r.ip_address,
      hit_count: r.hit_count,
      first_seen_at: r.first_seen_at,
      last_seen_at: r.last_seen_at,
    };

    let exactMap = exactBuckets.get(r.ip_address);
    if (!exactMap) {
      exactMap = new Map();
      exactBuckets.set(r.ip_address, exactMap);
    }
    if (!exactMap.has(r.user_id)) {
      exactMap.set(r.user_id, account);
    }

    const subnet = getIpSubnetPrefix(r.ip_address);
    if (subnet) {
      let bucket = subnetBuckets.get(subnet);
      if (!bucket) {
        bucket = { ips: new Set(), accounts: new Map() };
        subnetBuckets.set(subnet, bucket);
      }
      bucket.ips.add(r.ip_address);
      const existingAcc = bucket.accounts.get(r.user_id);
      if (!existingAcc || r.last_seen_at > existingAcc.last_seen_at) {
        bucket.accounts.set(r.user_id, account);
      }
    }
  }

  const toGroup = (
    key: string,
    matchType: 'exact' | 'subnet',
    accountMap: Map<number, SimilarIpAccount>
  ): SimilarIpGroup => {
    const accounts = Array.from(accountMap.values()).sort(
      (a, b) => b.last_seen_at - a.last_seen_at
    );
    return {
      key,
      matchType,
      userCount: accounts.length,
      bannedCount: accounts.filter((a) => a.is_banned === 1).length,
      totalBalanceMicro: accounts.reduce((sum, a) => sum + a.balance_micro, 0),
      lastSeenAt: accounts.reduce((max, a) => Math.max(max, a.last_seen_at), 0),
      accounts,
    };
  };

  const exactGroups: SimilarIpGroup[] = [];
  for (const [ip, map] of exactBuckets.entries()) {
    if (map.size >= 2) {
      exactGroups.push(toGroup(ip, 'exact', map));
    }
  }
  exactGroups.sort((a, b) => b.userCount - a.userCount || b.lastSeenAt - a.lastSeenAt);

  const subnetGroups: SimilarIpGroup[] = [];
  for (const [subnet, bucket] of subnetBuckets.entries()) {
    // Only emit subnet group when at least 2 distinct users hit >= 2 distinct IPs in the same subnet
    if (bucket.accounts.size >= 2 && bucket.ips.size >= 2) {
      subnetGroups.push(toGroup(subnet, 'subnet', bucket.accounts));
    }
  }
  subnetGroups.sort((a, b) => b.userCount - a.userCount || b.lastSeenAt - a.lastSeenAt);

  return [...exactGroups, ...subnetGroups];
}

export function adminUpdateLevels(actor: string, levels: MiningLevel[], ipAddress?: string): void {
  if (!Array.isArray(levels) || levels.length === 0) {
    throw new ServiceError('Levels array is required.', 400);
  }
  const sanitized = levels.map((lvl, idx) => ({
    level: Number.isFinite(Number(lvl.level)) ? Number(lvl.level) : idx,
    name: String(lvl.name || `Level ${idx}`).slice(0, 32),
    nameAr: String(lvl.nameAr || lvl.name || `مستوى ${idx}`).slice(0, 32),
    minBellgram: Math.max(0, Number(lvl.minBellgram) || 0),
    dailyBell: Math.max(1, Number(lvl.dailyBell) || 500),
  }));
  setSetting('mining_levels', sanitized);
  logAdminAction(getDb(), actor, 'update_mining_levels', 'app_settings', 'mining_levels', sanitized, ipAddress);
}

export function adminUpdateDailyRewards(actor: string, schedule: number[], ipAddress?: string): void {
  if (!Array.isArray(schedule) || schedule.length !== 7) {
    throw new ServiceError('Daily rewards schedule must contain exactly 7 daily values.', 400);
  }
  const sanitized = schedule.map((v) => Math.max(1, Math.round(Number(v) || 10)));
  setSetting('daily_bonus_schedule', sanitized);
  logAdminAction(
    getDb(),
    actor,
    'update_daily_rewards',
    'app_settings',
    'daily_bonus_schedule',
    sanitized,
    ipAddress
  );
}

export function adminUpdateChannels(actor: string, channels: ChannelConfig[], ipAddress?: string): void {
  if (!Array.isArray(channels)) {
    throw new ServiceError('Channels list is invalid.', 400);
  }
  const sanitized = channels.map((c, i) => {
    let rawUsername = String(c.username || '').trim();
    const tmeMatch = rawUsername.match(/^(?:https?:\/\/)?t\.me\/(?:s\/)?([^/?#]+)/i);
    if (tmeMatch) {
      rawUsername = tmeMatch[1];
    }
    const cleanUsername = rawUsername.startsWith('-')
      ? rawUsername.slice(0, 64)
      : rawUsername.replace(/^@/, '').slice(0, 64);

    const isRequired = c.isRequired !== false;
    if (isRequired && !cleanUsername) {
      throw new ServiceError(
        'Each required channel needs a @username or numeric -100... chat ID.',
        400
      );
    }

    const rawUrl = String(c.url || '').trim();
    const hasMeaningfulUrl =
      /^https?:\/\//i.test(rawUrl) && rawUrl.replace(/\/+$/, '').toLowerCase() !== 'https://t.me';
    const safeUrl = hasMeaningfulUrl
      ? rawUrl
      : cleanUsername && !cleanUsername.startsWith('-')
      ? `https://t.me/${cleanUsername}`
      : 'https://t.me/';

    return {
      id: String(c.id || `channel_${Date.now()}_${i + 1}`).replace(/[^a-zA-Z0-9_-]/g, ''),
      title: String(c.title || 'Channel').slice(0, 64),
      titleAr: String(c.titleAr || c.title || 'قناة').slice(0, 64),
      username: cleanUsername,
      url: safeUrl,
      isRequired,
    };
  });
  setSetting('required_channels', sanitized);
  logAdminAction(
    getDb(),
    actor,
    'update_channels',
    'app_settings',
    'required_channels',
    sanitized,
    ipAddress
  );
}

export function adminUpdateGeneralSettings(
  actor: string,
  payload: {
    referralBonusBell?: number;
    sessionDurationHours?: number;
    minClaimBell?: number;
    minWithdrawBell?: number;
    botUsername?: string;
  },
  ipAddress?: string
): void {
  if (payload.referralBonusBell !== undefined) {
    setSetting('referral_bonus_bell', Math.max(0, Number(payload.referralBonusBell) || 50));
  }
  if (payload.sessionDurationHours !== undefined) {
    setSetting('session_duration_hours', Math.max(1, Math.min(168, Number(payload.sessionDurationHours) || 24)));
  }
  if (payload.minClaimBell !== undefined) {
    setSetting('min_claim_bell', Math.max(0.0001, Number(payload.minClaimBell) || 0.0001));
  }
  if (payload.minWithdrawBell !== undefined) {
    setSetting('min_withdraw_bell', Math.max(1, Number(payload.minWithdrawBell) || 50));
  }
  if (payload.botUsername !== undefined) {
    setSetting('bot_username', String(payload.botUsername).replace(/^@/, '').trim() || config.botUsername);
  }
  logAdminAction(getDb(), actor, 'update_general_settings', 'app_settings', 'general', payload, ipAddress);
}

export function adminSetUserBan(
  actor: string,
  targetUserId: number,
  isBanned: boolean,
  ipAddress?: string
): void {
  const db = getDb();
  const res = db.prepare('UPDATE users SET is_banned = ? WHERE id = ?').run(isBanned ? 1 : 0, targetUserId);
  if (res.changes === 0) throw new ServiceError('User not found.', 404);
  logAdminAction(
    db,
    actor,
    isBanned ? 'ban_user' : 'unban_user',
    'users',
    String(targetUserId),
    { isBanned },
    ipAddress
  );
}

export function adminAdjustUserBalance(
  actor: string,
  targetUserId: number,
  payload: {
    mode?: 'set' | 'add' | 'subtract';
    amountBell: number;
    reason?: string;
  },
  ipAddress?: string
): {
  userId: number;
  oldBalanceMicro: number;
  newBalanceMicro: number;
  deltaMicro: number;
} {
  if (!Number.isInteger(targetUserId) || targetUserId <= 0) {
    throw new ServiceError('Invalid user ID.', 400);
  }

  const mode = payload.mode === 'add' || payload.mode === 'subtract' ? payload.mode : 'set';
  const rawBell = Number(payload.amountBell);
  if (!Number.isFinite(rawBell) || rawBell < 0 || rawBell > 1_000_000_000) {
    throw new ServiceError('Balance amount must be between 0 and 1,000,000,000 BELL.', 400);
  }

  const amountMicro = bellToMicro(rawBell);
  const reason = String(payload.reason || '').trim().slice(0, 160);

  return runInTransaction((db) => {
    const user = db
      .prepare('SELECT id, telegram_id, balance_micro FROM users WHERE id = ?')
      .get(targetUserId) as { id: number; telegram_id: string; balance_micro: number } | undefined;

    if (!user) {
      throw new ServiceError('User not found.', 404);
    }

    let newBalanceMicro: number;
    if (mode === 'add') {
      if (amountMicro <= 0) {
        throw new ServiceError('Amount to add must be greater than 0.', 400);
      }
      newBalanceMicro = user.balance_micro + amountMicro;
    } else if (mode === 'subtract') {
      if (amountMicro <= 0) {
        throw new ServiceError('Amount to subtract must be greater than 0.', 400);
      }
      if (amountMicro > user.balance_micro) {
        throw new ServiceError('Cannot subtract more than the user’s current balance.', 400);
      }
      newBalanceMicro = user.balance_micro - amountMicro;
    } else {
      newBalanceMicro = amountMicro;
    }

    const deltaMicro = newBalanceMicro - user.balance_micro;
    if (deltaMicro === 0) {
      throw new ServiceError('New balance is identical to current balance.', 400);
    }

    const now = Date.now();
    db.prepare('UPDATE users SET balance_micro = ? WHERE id = ?').run(newBalanceMicro, targetUserId);

    const txDescription = reason
      ? `Admin adjustment: ${reason}`
      : 'Admin balance adjustment';

    db.prepare(
      `INSERT INTO transactions (
        user_id, tx_type, amount_micro, balance_after_micro, description, reference_id, created_at
      ) VALUES (?, 'admin_adjustment', ?, ?, ?, ?, ?)`
    ).run(
      targetUserId,
      deltaMicro,
      newBalanceMicro,
      txDescription,
      `admin_adj_${now}`,
      now
    );

    logAdminAction(
      db,
      actor,
      'adjust_user_balance',
      'users',
      String(targetUserId),
      {
        telegramId: user.telegram_id,
        mode,
        oldBalanceMicro: user.balance_micro,
        newBalanceMicro,
        deltaMicro,
        reason: reason || null,
      },
      ipAddress
    );

    return {
      userId: targetUserId,
      oldBalanceMicro: user.balance_micro,
      newBalanceMicro,
      deltaMicro,
    };
  });
}

export function adminCreateMission(
  actor: string,
  payload: {
    code?: string;
    titleEn?: string;
    titleAr?: string;
    descriptionEn?: string;
    descriptionAr?: string;
    missionType?: 'channel' | 'referral_count' | 'daily_login' | 'custom';
    targetValue?: number;
    channelUsername?: string;
    channelUrl?: string;
    rewardBell: number;
  },
  ipAddress?: string
): void {
  const db = getDb();
  const missionType: 'channel' | 'referral_count' | 'daily_login' | 'custom' =
    payload.missionType === 'channel' ||
    payload.missionType === 'referral_count' ||
    payload.missionType === 'daily_login' ||
    payload.missionType === 'custom'
      ? payload.missionType
      : 'custom';

  const rawTitleEn = String(payload.titleEn || '').trim();
  const rawTitleAr = String(payload.titleAr || '').trim();
  if (!rawTitleEn && !rawTitleAr) {
    throw new ServiceError('Mission title is required.', 400);
  }
  const titleEn = (rawTitleEn || rawTitleAr).slice(0, 80);
  const titleAr = (rawTitleAr || rawTitleEn).slice(0, 80);

  const rawDescEn = String(payload.descriptionEn || '').trim();
  const rawDescAr = String(payload.descriptionAr || '').trim();
  const descriptionEn = (rawDescEn || rawDescAr).slice(0, 200);
  const descriptionAr = (rawDescAr || rawDescEn).slice(0, 200);

  const rewardBell = Math.round(Number(payload.rewardBell));
  if (!Number.isFinite(rewardBell) || rewardBell < 1 || rewardBell > 10_000_000) {
    throw new ServiceError('Reward must be between 1 and 10,000,000 BELL.', 400);
  }

  let cleanUsername: string | null = null;
  let safeUrl: string | null = null;

  const rawUserInput = String(payload.channelUsername || '').trim();
  const rawUrlInput = String(payload.channelUrl || '').trim();

  if (missionType === 'channel') {
    const combinedSource = rawUserInput || rawUrlInput;
    let extracted = combinedSource;
    const tmeMatch = combinedSource.match(/^(?:https?:\/\/)?t\.me\/(?:s\/)?([^/?#]+)/i);
    if (tmeMatch) {
      extracted = tmeMatch[1];
    }
    if (extracted.startsWith('+')) {
      // Private invite link alone cannot verify membership via getChatMember unless -100... chat ID is supplied
      extracted = rawUserInput && !rawUserInput.includes('t.me/') ? rawUserInput : '';
    }
    cleanUsername = extracted.startsWith('-')
      ? extracted.slice(0, 64)
      : extracted.replace(/^@/, '').slice(0, 64);

    if (!cleanUsername) {
      throw new ServiceError(
        'Telegram verified missions require a channel @username, https://t.me/channel link, or -100... chat ID.',
        400
      );
    }

    if (rawUrlInput) {
      let parsedUrl: URL;
      try {
        parsedUrl = new URL(rawUrlInput);
      } catch {
        throw new ServiceError('Channel link must be a valid https:// URL.', 400);
      }
      if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
        throw new ServiceError('Channel link must start with https:// or http://.', 400);
      }
      safeUrl = parsedUrl.toString();
    } else if (!cleanUsername.startsWith('-')) {
      safeUrl = `https://t.me/${cleanUsername}`;
    }
  } else {
    if (rawUrlInput) {
      let parsedUrl: URL;
      try {
        parsedUrl = new URL(rawUrlInput);
      } catch {
        throw new ServiceError('External mission link must be a valid https:// or http:// URL.', 400);
      }
      if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
        throw new ServiceError('External mission link must start with https:// or http://.', 400);
      }
      safeUrl = parsedUrl.toString();
    }
  }

  const now = Date.now();
  const rawCode = String(payload.code || '').trim().toLowerCase().replace(/[^a-z0-9_]/g, '_');
  const code = rawCode || `task_${now}_${crypto.randomBytes(2).toString('hex')}`;

  try {
    db.prepare(
      `INSERT INTO missions (
        code, title_en, title_ar, description_en, description_ar,
        mission_type, target_value, channel_username, channel_url,
        reward_bell, is_active, sort_order, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 99, ?)`
    ).run(
      code,
      titleEn,
      titleAr,
      descriptionEn,
      descriptionAr,
      missionType,
      Math.max(1, Math.round(Number(payload.targetValue) || 1)),
      cleanUsername,
      safeUrl,
      rewardBell,
      now
    );
  } catch {
    throw new ServiceError('Mission code already exists.', 409);
  }

  logAdminAction(
    db,
    actor,
    'create_mission',
    'missions',
    code,
    {
      code,
      titleEn,
      titleAr,
      missionType,
      channelUsername: cleanUsername,
      channelUrl: safeUrl,
      rewardBell,
    },
    ipAddress
  );
}

export function adminToggleMission(
  actor: string,
  missionId: number,
  isActive: boolean,
  ipAddress?: string
): void {
  const db = getDb();
  const res = db
    .prepare('UPDATE missions SET is_active = ? WHERE id = ?')
    .run(isActive ? 1 : 0, missionId);
  if (res.changes === 0) throw new ServiceError('Mission not found.', 404);
  logAdminAction(db, actor, 'toggle_mission', 'missions', String(missionId), { isActive }, ipAddress);
}

export function adminDeleteMission(
  actor: string,
  missionId: number,
  ipAddress?: string
): void {
  if (!Number.isInteger(missionId) || missionId <= 0) {
    throw new ServiceError('Invalid mission ID.', 400);
  }
  const db = getDb();
  const res = db.prepare('DELETE FROM missions WHERE id = ?').run(missionId);
  if (res.changes === 0) throw new ServiceError('Mission not found.', 404);
  logAdminAction(db, actor, 'delete_mission', 'missions', String(missionId), {}, ipAddress);
}

export function adminExportUsersCsv(actor: string, ipAddress?: string): string {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT id, telegram_id, username, first_name, balance_micro, total_mined_micro,
              level_id, channels_verified, is_banned, last_ip, created_at
       FROM users ORDER BY id ASC`
    )
    .all() as Array<{
    id: number;
    telegram_id: string;
    username: string | null;
    first_name: string;
    balance_micro: number;
    total_mined_micro: number;
    level_id: number;
    channels_verified: number;
    is_banned: number;
    last_ip: string | null;
    created_at: number;
  }>;

  logAdminAction(db, actor, 'export_csv', 'users', null, { rowCount: rows.length }, ipAddress);

  const escapeCsv = (val: unknown) => {
    const s = String(val ?? '');
    if (/[",\n\r]/.test(s)) {
      return `"${s.replace(/"/g, '""')}"`;
    }
    return s;
  };

  const header = [
    'id',
    'telegram_id',
    'username',
    'first_name',
    'balance_bell',
    'total_mined_bell',
    'level_id',
    'channels_verified',
    'is_banned',
    'last_ip',
    'created_at_iso',
  ].join(',');

  const lines = rows.map((r) =>
    [
      r.id,
      r.telegram_id,
      r.username || '',
      r.first_name,
      microToBell(r.balance_micro).toFixed(4),
      microToBell(r.total_mined_micro).toFixed(4),
      r.level_id,
      r.channels_verified,
      r.is_banned,
      r.last_ip || '',
      new Date(r.created_at).toISOString(),
    ]
      .map(escapeCsv)
      .join(',')
  );

  return [header, ...lines].join('\n');
}

export function adminExportFullDatabaseJson(actor: string, ipAddress?: string) {
  const db = getDb();

  const tables = {
    users: db.prepare('SELECT * FROM users ORDER BY id ASC').all(),
    missions: db.prepare('SELECT * FROM missions ORDER BY sort_order ASC, id ASC').all(),
    missionClaims: db.prepare('SELECT * FROM mission_claims ORDER BY id ASC').all(),
    referrals: db.prepare('SELECT * FROM referrals ORDER BY id ASC').all(),
    referralRewards: db.prepare('SELECT * FROM referral_rewards ORDER BY id ASC').all(),
    walletConnections: db.prepare('SELECT * FROM wallet_connections ORDER BY id ASC').all(),
    walletVerifications: db.prepare('SELECT * FROM wallet_verifications ORDER BY id ASC').all(),
    withdrawals: db.prepare('SELECT * FROM withdrawals ORDER BY id ASC').all(),
    miningSessions: db.prepare('SELECT * FROM mining_sessions ORDER BY id ASC').all(),
    miningClaims: db.prepare('SELECT * FROM mining_claims ORDER BY id ASC').all(),
    dailyRewards: db.prepare('SELECT * FROM daily_rewards ORDER BY id ASC').all(),
    transactions: db.prepare('SELECT * FROM transactions ORDER BY id ASC').all(),
    userIps: db.prepare('SELECT * FROM user_ips ORDER BY id ASC').all(),
    appSettings: db.prepare('SELECT * FROM app_settings ORDER BY key ASC').all(),
    adminAuditLogs: db.prepare('SELECT * FROM admin_audit_logs ORDER BY id ASC').all(),
  };

  logAdminAction(
    db,
    actor,
    'export_full_json',
    'database',
    null,
    {
      usersCount: tables.users.length,
      missionsCount: tables.missions.length,
      withdrawalsCount: tables.withdrawals.length,
    },
    ipAddress
  );

  return {
    exportedAt: new Date().toISOString(),
    counts: {
      users: tables.users.length,
      missions: tables.missions.length,
      missionClaims: tables.missionClaims.length,
      referrals: tables.referrals.length,
      walletConnections: tables.walletConnections.length,
      walletVerifications: tables.walletVerifications.length,
      withdrawals: tables.withdrawals.length,
      miningSessions: tables.miningSessions.length,
      dailyRewards: tables.dailyRewards.length,
      transactions: tables.transactions.length,
      userIps: tables.userIps.length,
    },
    tables,
  };
}

export function adminCreateSqliteBackupBuffer(actor: string, ipAddress?: string): Buffer {
  const db = getDb();
  logAdminAction(db, actor, 'export_sqlite_db', 'database', null, {}, ipAddress);

  const tmpPath = path.join(os.tmpdir(), `bellgram-backup-${crypto.randomUUID()}.db`);
  try {
    db.exec(`VACUUM INTO '${tmpPath.replace(/'/g, "''")}'`);
    const snapshotDb = new DatabaseSync(tmpPath);
    try {
      // Strip credential hashes from downloadable backup snapshot
      snapshotDb.exec('DELETE FROM admin_users;');
    } finally {
      snapshotDb.close();
    }
    return fs.readFileSync(tmpPath);
  } finally {
    for (const suffix of ['', '-wal', '-shm']) {
      if (fs.existsSync(tmpPath + suffix)) {
        try {
          fs.unlinkSync(tmpPath + suffix);
        } catch {
          // ignore cleanup failure
        }
      }
    }
  }
}
