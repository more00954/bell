import { getDb, getSetting, runInTransaction } from '../db.ts';
import { config } from '../config.ts';
import { bellToMicro, formatBell } from '../../src/lib/bellMath.ts';
import { escapeTelegramHtml, sendTelegramMessage } from '../telegramAuth.ts';
import { ServiceError } from './miningService.ts';
import type { WithdrawalItem, WithdrawalStatus } from '../../src/types.ts';

const TON_ADDRESS_REGEX = /^(EQ|UQ|kQ|0Q)[A-Za-z0-9_-]{46}$|^0:[0-9a-fA-F]{64}$/;

interface DbWithdrawalRow {
  id: number;
  user_id: number;
  amount_micro: number;
  ton_address: string;
  status: WithdrawalStatus;
  rejection_reason: string | null;
  tx_hash: string | null;
  reviewed_by: string | null;
  reviewed_at: number | null;
  notified_telegram: number;
  created_at: number;
}

export interface AdminWithdrawalRow extends DbWithdrawalRow {
  telegram_id: string;
  username: string | null;
  first_name: string;
}

export function getUserWithdrawals(userId: number): WithdrawalItem[] {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT id, amount_micro, ton_address, status, rejection_reason, tx_hash, reviewed_at, created_at
       FROM withdrawals
       WHERE user_id = ?
       ORDER BY id DESC
       LIMIT 30`
    )
    .all(userId) as unknown as DbWithdrawalRow[];

  return rows.map((w) => ({
    id: w.id,
    amountMicro: w.amount_micro,
    tonAddress: w.ton_address,
    status: w.status,
    rejectionReason: w.rejection_reason,
    txHash: w.tx_hash,
    reviewedAt: w.reviewed_at ? new Date(w.reviewed_at).toISOString() : null,
    createdAt: new Date(w.created_at).toISOString(),
  }));
}

export function getAdminWithdrawals(statusFilter?: string): AdminWithdrawalRow[] {
  const db = getDb();
  if (statusFilter && ['pending', 'completed', 'rejected'].includes(statusFilter)) {
    return db
      .prepare(
        `SELECT w.*, u.telegram_id, u.username, u.first_name
         FROM withdrawals w
         JOIN users u ON u.id = w.user_id
         WHERE w.status = ?
         ORDER BY w.id DESC
         LIMIT 100`
      )
      .all(statusFilter) as unknown as AdminWithdrawalRow[];
  }
  return db
    .prepare(
      `SELECT w.*, u.telegram_id, u.username, u.first_name
       FROM withdrawals w
       JOIN users u ON u.id = w.user_id
       ORDER BY CASE WHEN w.status = 'pending' THEN 0 ELSE 1 END, w.id DESC
       LIMIT 100`
    )
    .all() as unknown as AdminWithdrawalRow[];
}

export async function requestWithdrawal(
  userId: number,
  amountBell: number,
  tonAddressInput?: string
): Promise<WithdrawalItem> {
  const minWithdrawBell = Math.max(1, getSetting<number>('min_withdraw_bell', 50));
  const minWithdrawMicro = bellToMicro(minWithdrawBell);

  if (!Number.isFinite(amountBell) || amountBell <= 0) {
    throw new ServiceError('Please enter a valid BELL withdrawal amount.', 400);
  }
  const amountMicro = bellToMicro(amountBell);
  if (amountMicro < minWithdrawMicro) {
    throw new ServiceError(`Minimum withdrawal is ${minWithdrawBell} BELL.`, 400);
  }

  const created = runInTransaction((db) => {
    const user = db
      .prepare(
        'SELECT id, telegram_id, username, first_name, balance_micro, is_banned, wallet_verified FROM users WHERE id = ?'
      )
      .get(userId) as
      | {
          id: number;
          telegram_id: string;
          username: string | null;
          first_name: string;
          balance_micro: number;
          is_banned: number;
          wallet_verified: number;
        }
      | undefined;

    if (!user) throw new ServiceError('User not found.', 404);
    if (user.is_banned) throw new ServiceError('This account has been suspended.', 403);
    if (user.wallet_verified !== 1) {
      throw new ServiceError(
        'Withdrawals are locked. Please verify your TON wallet with a 0.05 TON payment first.',
        403
      );
    }

    const walletRow = db
      .prepare('SELECT ton_address FROM wallet_connections WHERE user_id = ?')
      .get(userId) as { ton_address: string } | undefined;

    const tonAddress = (tonAddressInput || walletRow?.ton_address || '').trim();
    if (!TON_ADDRESS_REGEX.test(tonAddress)) {
      throw new ServiceError('Please connect or enter a valid TON wallet address.', 400);
    }

    if (user.balance_micro < amountMicro) {
      throw new ServiceError('Insufficient BELL balance for this withdrawal.', 400);
    }

    const now = Date.now();
    const debitRes = db
      .prepare(
        `UPDATE users
         SET balance_micro = balance_micro - ?,
             last_active_at = ?
         WHERE id = ? AND balance_micro >= ?`
      )
      .run(amountMicro, now, userId, amountMicro);

    if (debitRes.changes === 0) {
      throw new ServiceError('Insufficient BELL balance for this withdrawal.', 400);
    }

    const newBalanceMicro = user.balance_micro - amountMicro;

    const ins = db
      .prepare(
        `INSERT INTO withdrawals (
          user_id, amount_micro, ton_address, status, created_at
        ) VALUES (?, ?, ?, 'pending', ?)`
      )
      .run(userId, amountMicro, tonAddress, now);

    const withdrawalId = Number(ins.lastInsertRowid);

    db.prepare(
      `INSERT INTO transactions (
        user_id, tx_type, amount_micro, balance_after_micro, description, reference_id, created_at
      ) VALUES (?, 'withdraw_request', ?, ?, ?, ?, ?)`
    ).run(
      userId,
      -amountMicro,
      newBalanceMicro,
      `Withdrawal request #${withdrawalId} (Pending)`,
      `withdraw:${withdrawalId}`,
      now
    );

    return {
      withdrawal: {
        id: withdrawalId,
        amountMicro,
        tonAddress,
        status: 'pending' as const,
        rejectionReason: null,
        txHash: null,
        reviewedAt: null,
        createdAt: new Date(now).toISOString(),
      },
      user,
    };
  });

  // Best-effort real-time Telegram notification to authorized admins
  void notifyAdminsOfNewWithdrawal({
    withdrawalId: created.withdrawal.id,
    amountMicro: created.withdrawal.amountMicro,
    tonAddress: created.withdrawal.tonAddress,
    user: created.user,
  });

  return created.withdrawal;
}

export async function reviewWithdrawal(
  actor: string,
  withdrawalId: number,
  decision: 'completed' | 'rejected',
  options: { reason?: string; txHash?: string },
  ipAddress?: string
): Promise<{ withdrawalId: number; status: WithdrawalStatus; notifiedTelegram: boolean }> {
  if (decision !== 'completed' && decision !== 'rejected') {
    throw new ServiceError('Decision must be completed or rejected.', 400);
  }

  const cleanReason = (options.reason || '').trim().slice(0, 400);
  const cleanTxHash = (options.txHash || '').trim().slice(0, 160);

  if (decision === 'rejected' && cleanReason.length < 2) {
    throw new ServiceError('Please provide a reason when rejecting a withdrawal.', 400);
  }

  const processed = runInTransaction((db) => {
    const row = db
      .prepare(
        `SELECT w.*, u.telegram_id, u.username, u.first_name, u.is_preview, u.balance_micro
         FROM withdrawals w
         JOIN users u ON u.id = w.user_id
         WHERE w.id = ?`
      )
      .get(withdrawalId) as
      | (DbWithdrawalRow & {
          telegram_id: string;
          username: string | null;
          first_name: string;
          is_preview: number;
          balance_micro: number;
        })
      | undefined;

    if (!row) {
      throw new ServiceError('Withdrawal request not found.', 404);
    }
    if (row.status !== 'pending') {
      throw new ServiceError('This withdrawal request has already been processed.', 409);
    }

    const now = Date.now();

    if (decision === 'rejected') {
      db.prepare(
        `UPDATE users
         SET balance_micro = balance_micro + ?
         WHERE id = ?`
      ).run(row.amount_micro, row.user_id);

      const newBalanceMicro = row.balance_micro + row.amount_micro;

      db.prepare(
        `INSERT INTO transactions (
          user_id, tx_type, amount_micro, balance_after_micro, description, reference_id, created_at
        ) VALUES (?, 'withdraw_refund', ?, ?, ?, ?, ?)`
      ).run(
        row.user_id,
        row.amount_micro,
        newBalanceMicro,
        `Withdrawal #${withdrawalId} rejected & refunded: ${cleanReason}`,
        `withdraw_refund:${withdrawalId}`,
        now
      );

      db.prepare(
        `UPDATE withdrawals
         SET status = 'rejected',
             rejection_reason = ?,
             reviewed_by = ?,
             reviewed_at = ?
         WHERE id = ?`
      ).run(cleanReason, actor, now, withdrawalId);
    } else {
      db.prepare(
        `UPDATE withdrawals
         SET status = 'completed',
             tx_hash = ?,
             reviewed_by = ?,
             reviewed_at = ?
         WHERE id = ?`
      ).run(cleanTxHash || null, actor, now, withdrawalId);
    }

    db.prepare(
      `INSERT INTO admin_audit_logs (
        admin_actor, action, target_type, target_id, details_json, ip_address, created_at
      ) VALUES (?, ?, 'withdrawals', ?, ?, ?, ?)`
    ).run(
      actor,
      decision === 'completed' ? 'approve_withdrawal' : 'reject_withdrawal',
      String(withdrawalId),
      JSON.stringify({
        userId: row.user_id,
        amountMicro: row.amount_micro,
        decision,
        reason: cleanReason || null,
        txHash: cleanTxHash || null,
      }),
      ipAddress || null,
      now
    );

    return {
      withdrawalId,
      amountMicro: row.amount_micro,
      tonAddress: row.ton_address,
      telegramId: row.telegram_id,
      isPreview: row.is_preview === 1,
      status: decision,
      reason: cleanReason,
      txHash: cleanTxHash,
    };
  });

  let notifiedTelegram = false;
  if (config.botToken && !processed.isPreview && /^\d+$/.test(processed.telegramId)) {
    const amountLabel = formatBell(processed.amountMicro);
    const addrLabel = escapeTelegramHtml(processed.tonAddress);

    const msg =
      decision === 'completed'
        ? [
            `✅ <b>تم تنفيذ طلب السحب الخاص بك (#${processed.withdrawalId}) — مكتمل</b>`,
            '',
            `• المبلغ: <b>${amountLabel} BELL</b>`,
            `• المحفظة: <code>${addrLabel}</code>`,
            processed.txHash
              ? `• مرجع العملية: <code>${escapeTelegramHtml(processed.txHash)}</code>`
              : '',
            '',
            'شكرًا لاستخدامك BELLGRAM 🔔',
          ]
            .filter(Boolean)
            .join('\n')
        : [
            `❌ <b>تم رفض طلب السحب الخاص بك (#${processed.withdrawalId})</b>`,
            '',
            `• المبلغ: <b>${amountLabel} BELL</b>`,
            `• السبب: <b>${escapeTelegramHtml(processed.reason)}</b>`,
            '',
            '💰 تم إرجاع كامل المبلغ إلى رصيدك داخل التطبيق تلقائيًا.',
          ].join('\n');

    notifiedTelegram = await sendTelegramMessage(config.botToken, processed.telegramId, msg);
    if (notifiedTelegram) {
      getDb()
        .prepare('UPDATE withdrawals SET notified_telegram = 1 WHERE id = ?')
        .run(processed.withdrawalId);
    }
  }

  return {
    withdrawalId: processed.withdrawalId,
    status: processed.status,
    notifiedTelegram,
  };
}

async function notifyAdminsOfNewWithdrawal(params: {
  withdrawalId: number;
  amountMicro: number;
  tonAddress: string;
  user: {
    id: number;
    telegram_id: string;
    username: string | null;
    first_name: string;
  };
}): Promise<void> {
  if (!config.botToken || config.adminTelegramUsernames.length === 0) return;

  try {
    const db = getDb();
    const rows = db
      .prepare(
        `SELECT telegram_id, username
         FROM users
         WHERE is_preview = 0 AND username IS NOT NULL`
      )
      .all() as Array<{ telegram_id: string; username: string | null }>;

    const adminChatIds = new Set<string>();
    for (const r of rows) {
      const normalized = (r.username || '').trim().replace(/^@/, '').toLowerCase();
      if (normalized && config.adminTelegramUsernames.includes(normalized) && /^\d+$/.test(r.telegram_id)) {
        adminChatIds.add(r.telegram_id);
      }
    }

    if (adminChatIds.size === 0) return;

    const amountLabel = formatBell(params.amountMicro);
    const handle = params.user.username ? `@${escapeTelegramHtml(params.user.username)}` : 'بدون يوزرنيم';
    const text = [
      `💸 <b>طلب سحب جديد (#${params.withdrawalId})</b>`,
      '',
      `• المستخدم: <b>${escapeTelegramHtml(params.user.first_name)}</b> (${handle})`,
      `• المعرّف: <code>${escapeTelegramHtml(params.user.telegram_id)}</code>`,
      `• المبلغ: <b>${amountLabel} BELL</b>`,
      `• محفظة TON: <code>${escapeTelegramHtml(params.tonAddress)}</code>`,
      '',
      'افتح لوحة الإدارة لمراجعة الطلب (مكتمل أو مرفوض مع السبب).',
    ].join('\n');

    const replyMarkup =
      config.appUrl && /^https:\/\//i.test(config.appUrl)
        ? {
            inline_keyboard: [
              [
                {
                  text: '🛡️ فتح لوحة الإدارة',
                  web_app: { url: `${config.appUrl.replace(/\/+$/, '')}/admin` },
                },
              ],
            ],
          }
        : undefined;

    await Promise.allSettled(
      Array.from(adminChatIds).map((chatId) =>
        sendTelegramMessage(config.botToken, chatId, text, replyMarkup)
      )
    );
  } catch {
    // Non-fatal notification failure
  }
}
