import { getSetting, runInTransaction, DEFAULT_DAILY_REWARDS } from '../db.ts';
import { bellToMicro, computeDailyStreakState, getUtcDateString } from '../../src/lib/bellMath.ts';
import { ServiceError } from './miningService.ts';
import type { DbUserRow } from './userService.ts';

export function claimDailyBonus(userId: number): {
  dayNumber: number;
  rewardMicro: number;
  newBalanceMicro: number;
  claimDateUtc: string;
} {
  return runInTransaction((db) => {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as DbUserRow | undefined;
    if (!user) throw new ServiceError('User not found', 404);
    if (user.is_banned) throw new ServiceError('Account is suspended', 403);

    const schedule = getSetting<number[]>('daily_bonus_schedule', DEFAULT_DAILY_REWARDS);
    const nowMs = Date.now();
    const todayUtc = getUtcDateString(nowMs);

    const lastClaim = db
      .prepare('SELECT day_number, claim_date_utc FROM daily_rewards WHERE user_id = ? ORDER BY id DESC LIMIT 1')
      .get(userId) as { day_number: number; claim_date_utc: string } | undefined;

    const streak = computeDailyStreakState(
      lastClaim?.claim_date_utc ?? null,
      lastClaim?.day_number ?? 0,
      todayUtc,
      schedule
    );

    if (!streak.canClaim) {
      throw new ServiceError('Daily bonus already claimed for today (UTC).', 409);
    }

    const rewardMicro = bellToMicro(streak.rewardBell);

    // UNIQUE(user_id, claim_date_utc) guarantees atomic once-per-day enforcement
    try {
      db.prepare(
        `INSERT INTO daily_rewards (user_id, day_number, claim_date_utc, amount_micro, claimed_at)
         VALUES (?, ?, ?, ?, ?)`
      ).run(userId, streak.nextDayIndex, todayUtc, rewardMicro, nowMs);
    } catch {
      throw new ServiceError('Daily bonus already claimed today.', 409);
    }

    const newBalanceMicro = user.balance_micro + rewardMicro;
    db.prepare('UPDATE users SET balance_micro = ?, last_active_at = ? WHERE id = ?').run(
      newBalanceMicro,
      nowMs,
      userId
    );

    db.prepare(
      `INSERT INTO transactions (user_id, tx_type, amount_micro, balance_after_micro, description, reference_id, created_at)
       VALUES (?, 'daily_bonus', ?, ?, ?, ?, ?)`
    ).run(
      userId,
      rewardMicro,
      newBalanceMicro,
      `Daily login bonus (Day ${streak.nextDayIndex}/7)`,
      `daily_${todayUtc}`,
      nowMs
    );

    return {
      dayNumber: streak.nextDayIndex,
      rewardMicro,
      newBalanceMicro,
      claimDateUtc: todayUtc,
    };
  });
}
