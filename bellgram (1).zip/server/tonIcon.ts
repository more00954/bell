import zlib from 'node:zlib';

let cachedPng: Buffer | null = null;

function crc32(buf: Buffer): number {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc ^= buf[i];
    for (let j = 0; j < 8; j++) {
      crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function makeChunk(type: string, data: Buffer): Buffer {
  const typeBuf = Buffer.from(type, 'ascii');
  const lenBuf = Buffer.alloc(4);
  lenBuf.writeUInt32BE(data.length, 0);
  const crcInput = Buffer.concat([typeBuf, data]);
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(crcInput), 0);
  return Buffer.concat([lenBuf, typeBuf, data, crcBuf]);
}

/**
 * Generates a valid 128x128 RGBA PNG icon (golden bell on deep emerald)
 * required by TON Connect wallets (Telegram Wallet @walt, Tonkeeper, etc.).
 */
export function getBellgramPngIcon(): Buffer {
  if (cachedPng) return cachedPng;

  const size = 128;
  const stride = size * 4 + 1;
  const raw = Buffer.alloc(stride * size);

  for (let y = 0; y < size; y++) {
    const rowStart = y * stride;
    raw[rowStart] = 0; // filter type 0

    for (let x = 0; x < size; x++) {
      const idx = rowStart + 1 + x * 4;
      const nx = (x - 64) / 64;
      const ny = (y - 64) / 64;

      // Deep emerald rounded background (#05160e) with subtle radial highlight
      const dist = Math.sqrt(nx * nx + ny * ny);
      let r = 5;
      let g = Math.round(22 + Math.max(0, 1 - dist) * 28);
      let b = Math.round(14 + Math.max(0, 1 - dist) * 16);
      const a = 255;

      // Golden bell silhouette (#f5b731)
      const inCrown = (x - 64) ** 2 + (y - 31) ** 2 <= 6 ** 2;
      const inBellBody =
        y >= 34 &&
        y <= 82 &&
        Math.abs(x - 64) <= 18 + Math.pow((y - 34) / 48, 1.4) * 14;
      const inRim = y >= 80 && y <= 88 && Math.abs(x - 64) <= 34;
      const inClapper = (x - 64) ** 2 + (y - 97) ** 2 <= 7.5 ** 2;

      if (inCrown || inBellBody || inRim || inClapper) {
        r = 245;
        g = 183;
        b = 49;
        // Soft highlight on left curve
        if (inBellBody && x < 54 && y > 40 && y < 74) {
          r = 253;
          g = 224;
          b = 120;
        }
      }

      raw[idx] = r;
      raw[idx + 1] = g;
      raw[idx + 2] = b;
      raw[idx + 3] = a;
    }
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  const compressed = zlib.deflateSync(raw);
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  cachedPng = Buffer.concat([
    sig,
    makeChunk('IHDR', ihdr),
    makeChunk('IDAT', compressed),
    makeChunk('IEND', Buffer.alloc(0)),
  ]);

  return cachedPng;
}
