import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { config } from './server/config.ts';
import { getDb } from './server/db.ts';
import { createRateLimiter } from './server/rateLimit.ts';
import { getBellgramPngIcon } from './server/tonIcon.ts';
import {
  resolveAuthenticatedUser,
  markChannelJoinIntent,
  verifyRequiredChannels,
  syncLiveChannelsOnEntry,
  buildBootstrapPayload,
  isTelegramUsernameAdmin,
} from './server/services/userService.ts';
import { claimMiningReward, ServiceError } from './server/services/miningService.ts';
import { claimDailyBonus } from './server/services/rewardsService.ts';
import { claimMissionReward } from './server/services/missionService.ts';
import {
  confirmWalletVerification,
  connectTonWallet,
  disconnectTonWallet,
  refreshConnectedWalletBalance,
} from './server/services/walletService.ts';
import { requestWithdrawal, reviewWithdrawal } from './server/services/withdrawService.ts';
import {
  handleTelegramWebhookUpdate,
  isPublicWebhookHost,
  notePublicRequestOrigin,
  syncTelegramBotSetup,
  verifyWebhookSecretHeader,
} from './server/services/telegramBotService.ts';
import {
  getAdminAuthStatus,
  bootstrapFirstAdmin,
  authenticateAdmin,
  adminChangePassword,
  verifyAdminToken,
  getAdminDashboardData,
  adminUpdateLevels,
  adminUpdateDailyRewards,
  adminUpdateChannels,
  adminUpdateGeneralSettings,
  adminSetUserBan,
  adminAdjustUserBalance,
  adminCreateMission,
  adminToggleMission,
  adminDeleteMission,
  adminExportUsersCsv,
  adminExportFullDatabaseJson,
  adminCreateSqliteBackupBuffer,
} from './server/services/adminService.ts';
import { normalizeIpAddress } from './server/ipUtils.ts';

async function startServer() {
  // Initialize SQLite database and defaults
  getDb();

  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '256kb' }));

  const generalLimiter = createRateLimiter({ windowMs: 60_000, maxRequests: 120, keyPrefix: 'api' });
  const claimLimiter = createRateLimiter({ windowMs: 60_000, maxRequests: 25, keyPrefix: 'claim' });
  const adminAuthLimiter = createRateLimiter({ windowMs: 60_000, maxRequests: 15, keyPrefix: 'admin_auth' });

  app.use((req, _res, next) => {
    const rawProto = String(req.headers['x-forwarded-proto'] || req.protocol || '')
      .split(',')[0]
      .trim();
    const rawHost = String(req.headers['x-forwarded-host'] || req.headers.host || '')
      .split(',')[0]
      .trim();
    if (rawProto && rawHost) {
      notePublicRequestOrigin(`${rawProto}://${rawHost}`);
    }
    next();
  });

  app.use('/api', generalLimiter);

  // Health & OpenAPI documentation
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'bellgram-api', timestamp: new Date().toISOString() });
  });

  app.get('/api/openapi.json', (_req, res) => {
    res.json({
      openapi: '3.0.3',
      info: {
        title: 'BELLGRAM Mining Mini App API',
        version: '1.0.0',
        description: 'Server-authoritative Telegram Mini App API for BELLGRAM.',
      },
      paths: {
        '/api/health': { get: { summary: 'Health check' } },
        '/api/bootstrap': { get: { summary: 'Authenticate Telegram initData & return full app state' } },
        '/api/channels/join-intent': { post: { summary: 'Record channel join tap' } },
        '/api/channels/verify': { post: { summary: 'Verify Telegram channel membership' } },
        '/api/mining/claim': { post: { summary: 'Atomically claim accrued mining rewards' } },
        '/api/daily/claim': { post: { summary: 'Claim daily login streak bonus (UTC)' } },
        '/api/missions/{id}/claim': { post: { summary: 'Verify & claim mission reward' } },
        '/api/wallet/connect': { post: { summary: 'Link TON public address via TON Connect' } },
        '/api/wallet/disconnect': { post: { summary: 'Unlink TON wallet' } },
        '/api/withdrawals/request': { post: { summary: 'Submit BELL withdrawal request for admin approval' } },
        '/api/admin/status': { get: { summary: 'Check admin bootstrap status' } },
        '/api/admin/bootstrap': { post: { summary: 'Claim initial admin password' } },
        '/api/admin/login': { post: { summary: 'Authenticate admin session' } },
        '/api/admin/password': { post: { summary: 'Change admin password' } },
        '/api/admin/dashboard': { get: { summary: 'Admin KPIs, users, similar IPs, withdrawals, transactions, audit logs' } },
        '/api/admin/users/{id}/balance': { post: { summary: 'Adjust or set user BELL balance' } },
        '/api/admin/withdrawals/{id}/review': { post: { summary: 'Complete or reject withdrawal with reason and notify user' } },
        '/api/admin/export/csv': { get: { summary: 'Export users & balances CSV' } },
      },
    });
  });

  app.get('/ton-icon.png', (_req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.send(getBellgramPngIcon());
  });

  app.get('/favicon.ico', (_req, res) => {
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.send(getBellgramPngIcon());
  });

  app.options('/tonconnect-manifest.json', (_req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.status(204).end();
  });

  // Dynamic TON Connect manifest (public metadata, CORS enabled per TON Connect spec)
  app.get('/tonconnect-manifest.json', (req, res) => {
    const rawProto = String(req.headers['x-forwarded-proto'] || req.protocol || 'https')
      .split(',')[0]
      .trim();
    const rawHost = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
    const reqOrigin = rawHost ? `${rawProto}://${rawHost}` : '';
    const fallbackAppUrl =
      config.appUrl && /^https?:\/\//i.test(config.appUrl) ? config.appUrl.replace(/\/+$/, '') : '';
    const baseUrl = (reqOrigin || fallbackAppUrl || `http://localhost:${config.port}`).replace(
      /\/+$/,
      ''
    );

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache');
    res.json({
      url: baseUrl,
      name: 'BELLGRAM',
      iconUrl: `${baseUrl}/ton-icon.png`,
    });
  });

  const getRequestClientIp = (req: express.Request): string | null =>
    normalizeIpAddress(req.headers['x-forwarded-for']) ||
    normalizeIpAddress(req.ip) ||
    normalizeIpAddress(req.socket?.remoteAddress);

  // Helper middleware for Telegram Mini App user routes
  const requireUser = (
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    const initData = req.header('X-Telegram-Init-Data') || (req.body?.initData as string | undefined);
    const resolved = resolveAuthenticatedUser(initData, getRequestClientIp(req));
    if (!resolved.user) {
      res.status(resolved.status || 401).json({ error: resolved.error || 'Unauthorized' });
      return;
    }
    (req as express.Request & { bellUserId: number }).bellUserId = resolved.user.id;
    next();
  };

  const getBellUserId = (req: express.Request): number =>
    (req as express.Request & { bellUserId: number }).bellUserId;

  // User Mini App APIs
  app.get('/api/bootstrap', requireUser, async (req, res) => {
    const userId = getBellUserId(req);
    await Promise.all([
      syncLiveChannelsOnEntry(userId),
      refreshConnectedWalletBalance(userId, false).catch(() => null),
    ]);
    const payload = buildBootstrapPayload(userId);
    res.json(payload);
  });

  app.post('/api/channels/join-intent', requireUser, (req, res) => {
    try {
      const channelId = String(req.body?.channelId || '');
      markChannelJoinIntent(getBellUserId(req), channelId);
      res.json(buildBootstrapPayload(getBellUserId(req)));
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/channels/verify', requireUser, claimLimiter, async (req, res) => {
    try {
      const result = await verifyRequiredChannels(getBellUserId(req));
      res.json({
        verification: result,
        bootstrap: buildBootstrapPayload(getBellUserId(req)),
      });
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/mining/claim', requireUser, claimLimiter, (req, res) => {
    try {
      const idempotencyKey =
        req.header('Idempotency-Key') || (req.body?.idempotencyKey as string | undefined);
      const claimResult = claimMiningReward(getBellUserId(req), idempotencyKey);
      res.json({
        claim: claimResult,
        bootstrap: buildBootstrapPayload(getBellUserId(req)),
      });
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/daily/claim', requireUser, claimLimiter, (req, res) => {
    try {
      const claimResult = claimDailyBonus(getBellUserId(req));
      res.json({
        claim: claimResult,
        bootstrap: buildBootstrapPayload(getBellUserId(req)),
      });
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/missions/:id/claim', requireUser, claimLimiter, async (req, res) => {
    try {
      const missionId = Number(req.params.id);
      if (!Number.isFinite(missionId) || missionId <= 0) {
        res.status(400).json({ error: 'Invalid mission ID.' });
        return;
      }
      const claimResult = await claimMissionReward(getBellUserId(req), missionId);
      res.json({
        claim: claimResult,
        bootstrap: buildBootstrapPayload(getBellUserId(req)),
      });
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/wallet/connect', requireUser, async (req, res) => {
    try {
      const tonAddress = String(req.body?.tonAddress || '');
      const walletApp = req.body?.walletApp ? String(req.body.walletApp) : undefined;
      const result = await connectTonWallet(getBellUserId(req), tonAddress, walletApp);
      res.json({
        wallet: result,
        bootstrap: buildBootstrapPayload(getBellUserId(req)),
      });
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/wallet/disconnect', requireUser, (req, res) => {
    disconnectTonWallet(getBellUserId(req));
    res.json({ bootstrap: buildBootstrapPayload(getBellUserId(req)) });
  });

  app.post('/api/wallet/refresh', requireUser, claimLimiter, async (req, res) => {
    try {
      const userId = getBellUserId(req);
      const wallet = await refreshConnectedWalletBalance(userId, true);
      res.json({
        wallet,
        bootstrap: buildBootstrapPayload(userId),
      });
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/wallet/verify/confirm', requireUser, claimLimiter, async (req, res) => {
    try {
      const userId = getBellUserId(req);
      const verification = await confirmWalletVerification(userId);
      res.json({
        verification,
        bootstrap: buildBootstrapPayload(userId),
      });
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/withdrawals/request', requireUser, claimLimiter, async (req, res) => {
    try {
      const amountBell = Number(req.body?.amountBell);
      const tonAddress = req.body?.tonAddress ? String(req.body.tonAddress) : undefined;
      const withdrawal = await requestWithdrawal(getBellUserId(req), amountBell, tonAddress);
      res.json({
        withdrawal,
        bootstrap: buildBootstrapPayload(getBellUserId(req)),
      });
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  // Telegram Bot Webhook (secured by HMAC secret_token header verified via timingSafeEqual)
  app.post('/api/telegram/webhook', async (req, res) => {
    if (!config.botToken) {
      res.status(503).json({ ok: false, error: 'BOT_TOKEN not configured' });
      return;
    }
    const secretHeader = req.header('X-Telegram-Bot-Api-Secret-Token');
    if (!verifyWebhookSecretHeader(secretHeader)) {
      res.status(403).json({ ok: false, error: 'Invalid Telegram webhook secret' });
      return;
    }

    const rawProto = String(req.headers['x-forwarded-proto'] || req.protocol || 'https')
      .split(',')[0]
      .trim();
    const rawHost = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
    const origin = rawHost ? `${rawProto}://${rawHost}` : undefined;

    try {
      await handleTelegramWebhookUpdate(req.body || {}, origin);
    } catch (err) {
      console.error('Telegram webhook update error:', (err as Error).message);
    }
    res.json({ ok: true });
  });

  // When accessed from inside Telegram WebApp, restrict admin endpoints to allowlisted Telegram usernames
  const ensureTelegramAdminIfPresent = (
    req: express.Request,
    res: express.Response
  ): boolean => {
    const initData = req.header('X-Telegram-Init-Data');
    if (!initData || !initData.trim()) {
      return true;
    }
    const resolved = resolveAuthenticatedUser(initData);
    if (!resolved.user) {
      res.status(resolved.status || 401).json({ error: resolved.error || 'Unauthorized' });
      return false;
    }
    if (!isTelegramUsernameAdmin(resolved.user.username, resolved.user.is_preview === 1)) {
      res.status(403).json({ error: 'Admin access is restricted to authorized Telegram administrators.' });
      return false;
    }
    return true;
  };

  // Admin CSRF + Bearer auth middleware
  const requireAdmin = (
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
  ) => {
    if (!ensureTelegramAdminIfPresent(req, res)) {
      return;
    }
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
      const xrw = req.header('X-Requested-With');
      if (xrw !== 'bellgram-admin') {
        res.status(403).json({ error: 'Missing required CSRF protection header.' });
        return;
      }
    }
    const verified = verifyAdminToken(req.header('Authorization'));
    if (!verified) {
      res.status(401).json({ error: 'Admin authentication required.' });
      return;
    }
    (req as express.Request & { adminActor: string }).adminActor = verified.actor;
    next();
  };

  const getAdminActor = (req: express.Request): string =>
    (req as express.Request & { adminActor: string }).adminActor;

  app.get('/api/admin/status', (req, res) => {
    if (!ensureTelegramAdminIfPresent(req, res)) return;
    res.json(getAdminAuthStatus());
  });

  app.post('/api/admin/bootstrap', adminAuthLimiter, (req, res) => {
    try {
      if (!ensureTelegramAdminIfPresent(req, res)) return;
      if (req.header('X-Requested-With') !== 'bellgram-admin') {
        res.status(403).json({ error: 'Missing required CSRF protection header.' });
        return;
      }
      const token = bootstrapFirstAdmin(String(req.body?.password || ''), getRequestClientIp(req) ?? req.ip);
      res.json({ token, actor: 'admin' });
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/admin/login', adminAuthLimiter, (req, res) => {
    try {
      if (!ensureTelegramAdminIfPresent(req, res)) return;
      if (req.header('X-Requested-With') !== 'bellgram-admin') {
        res.status(403).json({ error: 'Missing required CSRF protection header.' });
        return;
      }
      const token = authenticateAdmin(String(req.body?.password || ''), getRequestClientIp(req) ?? req.ip);
      res.json({ token });
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 401;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/admin/password', requireAdmin, adminAuthLimiter, (req, res) => {
    try {
      adminChangePassword(
        getAdminActor(req),
        String(req.body?.currentPassword || ''),
        String(req.body?.newPassword || ''),
        getRequestClientIp(req) ?? req.ip
      );
      res.json({ ok: true });
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.get('/api/admin/dashboard', requireAdmin, (req, res) => {
    const q = typeof req.query.q === 'string' ? req.query.q : undefined;
    res.json(getAdminDashboardData(q));
  });

  app.put('/api/admin/levels', requireAdmin, (req, res) => {
    try {
      adminUpdateLevels(getAdminActor(req), req.body?.levels, getRequestClientIp(req) ?? req.ip);
      res.json(getAdminDashboardData());
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.put('/api/admin/daily-rewards', requireAdmin, (req, res) => {
    try {
      adminUpdateDailyRewards(getAdminActor(req), req.body?.schedule, getRequestClientIp(req) ?? req.ip);
      res.json(getAdminDashboardData());
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.put('/api/admin/channels', requireAdmin, (req, res) => {
    try {
      adminUpdateChannels(getAdminActor(req), req.body?.channels, getRequestClientIp(req) ?? req.ip);
      res.json(getAdminDashboardData());
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.put('/api/admin/settings', requireAdmin, (req, res) => {
    try {
      adminUpdateGeneralSettings(getAdminActor(req), req.body || {}, getRequestClientIp(req) ?? req.ip);
      res.json(getAdminDashboardData());
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/admin/users/:id/ban', requireAdmin, (req, res) => {
    try {
      adminSetUserBan(
        getAdminActor(req),
        Number(req.params.id),
        Boolean(req.body?.isBanned),
        getRequestClientIp(req) ?? req.ip
      );
      const q = typeof req.query.q === 'string' ? req.query.q : undefined;
      res.json(getAdminDashboardData(q));
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/admin/users/:id/balance', requireAdmin, (req, res) => {
    try {
      adminAdjustUserBalance(
        getAdminActor(req),
        Number(req.params.id),
        {
          mode: req.body?.mode,
          amountBell: Number(req.body?.amountBell),
          reason: req.body?.reason ? String(req.body.reason) : undefined,
        },
        getRequestClientIp(req) ?? req.ip
      );
      const q = typeof req.query.q === 'string' ? req.query.q : undefined;
      res.json(getAdminDashboardData(q));
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/admin/missions', requireAdmin, (req, res) => {
    try {
      adminCreateMission(getAdminActor(req), req.body || {}, getRequestClientIp(req) ?? req.ip);
      res.json(getAdminDashboardData());
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/admin/missions/:id/toggle', requireAdmin, (req, res) => {
    try {
      adminToggleMission(
        getAdminActor(req),
        Number(req.params.id),
        Boolean(req.body?.isActive),
        getRequestClientIp(req) ?? req.ip
      );
      res.json(getAdminDashboardData());
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.delete('/api/admin/missions/:id', requireAdmin, (req, res) => {
    try {
      adminDeleteMission(
        getAdminActor(req),
        Number(req.params.id),
        getRequestClientIp(req) ?? req.ip
      );
      res.json(getAdminDashboardData());
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/admin/withdrawals/:id/review', requireAdmin, async (req, res) => {
    try {
      const withdrawalId = Number(req.params.id);
      if (!Number.isFinite(withdrawalId) || withdrawalId <= 0) {
        res.status(400).json({ error: 'Invalid withdrawal ID.' });
        return;
      }
      const decision = req.body?.decision === 'completed' ? 'completed' : 'rejected';
      const result = await reviewWithdrawal(
        getAdminActor(req),
        withdrawalId,
        decision,
        {
          reason: req.body?.reason ? String(req.body.reason) : undefined,
          txHash: req.body?.txHash ? String(req.body.txHash) : undefined,
        },
        getRequestClientIp(req) ?? req.ip
      );
      res.json({
        review: result,
        dashboard: getAdminDashboardData(),
      });
    } catch (err) {
      const status = err instanceof ServiceError ? err.status : 400;
      res.status(status).json({ error: (err as Error).message });
    }
  });

  app.post('/api/admin/telegram/sync', requireAdmin, async (req, res) => {
    const rawProto = String(req.headers['x-forwarded-proto'] || req.protocol || 'https')
      .split(',')[0]
      .trim();
    const rawHost = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
    const reqOrigin = rawHost ? `${rawProto}://${rawHost}` : undefined;
    const requestedUrl = req.body?.appUrl ? String(req.body.appUrl).trim() : reqOrigin;
    const sync = await syncTelegramBotSetup(requestedUrl);
    res.status(sync.ok ? 200 : 400).json(sync);
  });

  app.get('/api/admin/export/csv', requireAdmin, (req, res) => {
    const csv = adminExportUsersCsv(getAdminActor(req), getRequestClientIp(req) ?? req.ip);
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="bellgram-users-report.csv"');
    res.send(csv);
  });

  app.get('/api/admin/export/json', requireAdmin, (req, res) => {
    const dump = adminExportFullDatabaseJson(getAdminActor(req), getRequestClientIp(req) ?? req.ip);
    const dateTag = new Date().toISOString().slice(0, 10);
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="bellgram-full-backup-${dateTag}.json"`
    );
    res.send(JSON.stringify(dump, null, 2));
  });

  app.get('/api/admin/export/sqlite', requireAdmin, (req, res) => {
    const buffer = adminCreateSqliteBackupBuffer(
      getAdminActor(req),
      getRequestClientIp(req) ?? req.ip
    );
    const dateTag = new Date().toISOString().slice(0, 10);
    res.setHeader('Content-Type', 'application/x-sqlite3');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="bellgram-backup-${dateTag}.db"`
    );
    res.send(buffer);
  });

  // Mount Vite middleware in dev or serve built dist/ in production
  if (config.nodeEnv !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    if (fs.existsSync(distDir)) {
      app.use(express.static(distDir));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distDir, 'index.html'));
      });
    }
  }

  app.listen(config.port, '0.0.0.0', () => {
    console.log(`BELLGRAM server listening on http://0.0.0.0:${config.port}`);
    if (config.botToken && config.appUrl && isPublicWebhookHost(config.appUrl)) {
      void syncTelegramBotSetup(config.appUrl).then((res) => {
        if (res.ok) {
          console.log(`Telegram bot menu & webhook synced to ${res.appUrl}`);
        }
      });
    }
  });
}

startServer().catch((err) => {
  console.error('Failed to start BELLGRAM server:', err);
  process.exit(1);
});
