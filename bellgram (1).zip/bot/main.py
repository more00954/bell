import asyncio
import logging
import os
import sys
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, CommandObject
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
    WebAppInfo,
)

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
_raw_app_url = os.getenv("APP_URL", "").strip().rstrip("/")
MINI_APP_URL = (
    _raw_app_url
    if _raw_app_url and _raw_app_url != "MY_APP_URL"
    else "https://bellgram.ai.studio"
)
REQUIRED_CHANNELS = [
    ch.strip()
    for ch in os.getenv("REQUIRED_CHANNELS", "@bellgram_official,@bellgram_community").split(",")
    if ch.strip()
]

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger("bellgram.bot")

router = Router()


def build_main_keyboard(
    user_id: int,
    start_param: str | None = None,
    tab: str | None = None,
) -> InlineKeyboardMarkup:
    webapp_url = MINI_APP_URL
    params: list[str] = []
    if start_param:
        params.append(f"tgWebAppStartParam={start_param}")
    if tab:
        params.append(f"tab={tab}")
    if params:
        sep = "&" if "?" in webapp_url else "?"
        webapp_url = f"{webapp_url}{sep}{'&'.join(params)}"

    wallet_url = MINI_APP_URL
    wallet_sep = "&" if "?" in wallet_url else "?"
    wallet_url = f"{wallet_url}{wallet_sep}tab=wallet"

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="🔔 Open BELLGRAM",
                    web_app=WebAppInfo(url=webapp_url),
                )
            ],
            [
                InlineKeyboardButton(
                    text="💸 Withdraw | سحب",
                    web_app=WebAppInfo(url=wallet_url),
                )
            ],
            [
                InlineKeyboardButton(
                    text="✅ Check Subscriptions",
                    callback_data="check_channels",
                ),
                InlineKeyboardButton(
                    text="👥 Invite Link",
                    callback_data="my_invite",
                ),
            ],
        ]
    )


async def check_user_channels(bot: Bot, user_id: int) -> tuple[bool, list[str]]:
    missing: list[str] = []
    for ch in REQUIRED_CHANNELS:
        try:
            member = await bot.get_chat_member(chat_id=ch, user_id=user_id)
            if member.status not in ("creator", "administrator", "member", "restricted"):
                missing.append(ch)
        except Exception as exc:
            logger.warning("Channel check failed for %s: %s", ch, exc)
            missing.append(ch)
    return (len(missing) == 0, missing)


@router.message(CommandStart())
async def handle_start(message: Message, command: CommandObject, bot: Bot) -> None:
    user = message.from_user
    if not user:
        return

    args = (command.args or "").strip()
    ref_note = ""
    if args.startswith("ref_"):
        ref_id = args.removeprefix("ref_")
        if ref_id.isdigit() and int(ref_id) != user.id:
            ref_note = "\n🎁 تم ربط رابط الدعوة الخاص بك! افتح التطبيق لتفعيل مكافأة الترحيب."

    welcome_text = (
        f"أهلاً بك يا <b>{user.first_name}</b> في <b>BELLGRAM</b> 🔔\n\n"
        "• عدّن عملة <b>BELL</b> يوميًا داخل التطبيق.\n"
        "• احصل على مكافآت الدخول اليومي لمدة 7 أيام.\n"
        "• ادعُ أصدقاءك واربط محفظة <b>TON</b> واسحب أرباحك.\n"
        "• يمكنك استخدام زر <b>Withdraw | سحب</b> أو إرسال /withdraw."
        f"{ref_note}"
    )

    await message.answer(
        welcome_text,
        reply_markup=build_main_keyboard(user.id, start_param=args or None),
    )


@router.message(F.text == "/withdraw")
async def handle_withdraw_command(message: Message) -> None:
    user = message.from_user
    if not user:
        return
    await message.answer(
        "💸 <b>سحب عملة BELL</b>\n\n"
        "اضغط الزر أدناه لفتح شاشة السحب وإرسال طلبك إلى الإدارة.\n"
        "سيصلك إشعار مباشر هنا في البوت فور مراجعة الطلب (<b>مكتمل</b> أو <b>مرفوض مع السبب</b>):",
        reply_markup=build_main_keyboard(user.id, tab="wallet"),
    )


@router.callback_query(F.data == "check_channels")
async def handle_check_channels(callback: CallbackQuery, bot: Bot) -> None:
    user = callback.from_user
    ok, missing = await check_user_channels(bot, user.id)
    if ok:
        await callback.answer("تم التحقق من اشتراكك في جميع القنوات!", show_alert=True)
        if callback.message:
            await callback.message.answer(
                "✅ جميع الاشتراكات مكتملة! يمكنك الآن فتح BELLGRAM وبدء التعدين:",
                reply_markup=build_main_keyboard(user.id),
            )
    else:
        missing_str = " ، ".join(missing)
        await callback.answer("يرجى الاشتراك في القنوات المطلوبة أولاً.", show_alert=True)
        if callback.message:
            await callback.message.answer(
                f"⚠️ لم يتم التحقق من الاشتراك في:\n{missing_str}\n\n"
                "اشترك ثم اضغط زر التحقق مجددًا.",
                reply_markup=build_main_keyboard(user.id),
            )


@router.callback_query(F.data == "my_invite")
async def handle_my_invite(callback: CallbackQuery, bot: Bot) -> None:
    me = await bot.get_me()
    bot_username = me.username or os.getenv("BOT_USERNAME", "bellgrammbot")
    invite_url = f"https://t.me/{bot_username}?start=ref_{callback.from_user.id}"
    await callback.answer()
    if callback.message:
        await callback.message.answer(
            f"🔗 <b>رابط الدعوة الخاص بك:</b>\n<code>{invite_url}</code>\n\n"
            "شارك هذا الرابط مع أصدقائك ليحصل كل منكما على 50 BELL عند انضمامهم!",
            reply_markup=build_main_keyboard(callback.from_user.id),
        )


async def main() -> None:
    if not BOT_TOKEN:
        logger.error("BOT_TOKEN environment variable is missing. Exiting safely.")
        sys.exit(1)

    bot = Bot(
        token=BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher()
    dp.include_router(router)

    logger.info("Starting BELLGRAM Telegram Bot polling...")
    while True:
        try:
            await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
        except asyncio.CancelledError:
            break
        except Exception as exc:
            logger.exception("Bot polling encountered an error; restarting in 5s: %s", exc)
            await asyncio.sleep(5)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped gracefully.")
